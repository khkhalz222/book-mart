import importlib
import json
import os
import tempfile
import unittest
from io import BytesIO
from unittest.mock import patch

from werkzeug.datastructures import FileStorage


class EmployeeShiftFlowTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        os.environ["BOOK_MART_DATA_DIR"] = self.tempdir.name
        import app as app_module
        self.app_module = importlib.reload(app_module)
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM shifts")
            db.execute("DELETE FROM employees")
            db.execute("DELETE FROM business_days")
            db.execute("DELETE FROM orders")
            db.execute("DELETE FROM payroll_settlements")
            db.execute("DELETE FROM cash_entries")
            db.execute(
                "INSERT INTO employees (username, password_hash, monthly_salary, can_sell, can_manage_expenses, can_manage_purchases, is_active, created_at) VALUES (?, ?, ?, 1, 0, 0, 1, ?)",
                ("cashier1", self.app_module.generate_password_hash("pass123"), 3000, "2026-10-26T00:00:00+00:00"),
            )
            db.execute(
                "INSERT INTO employees (username, password_hash, monthly_salary, can_sell, can_manage_expenses, can_manage_purchases, is_active, created_at) VALUES (?, ?, ?, 1, 0, 0, 1, ?)",
                ("cashier2", self.app_module.generate_password_hash("pass123"), 3500, "2026-10-26T00:00:00+00:00"),
            )
            db.commit()

    def tearDown(self):
        self.tempdir.cleanup()

    def _ensure_open_shift(self, username="cashier1"):
        """Open an employee shift so write endpoints pass the open-shift gate.

        Every recorded action now requires an employee on an open shift; these
        administrative tests therefore sign an employee in first.
        """
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            if db.execute("SELECT id FROM shifts WHERE status = 'open' LIMIT 1").fetchone():
                return
        opener = self.app_module.app.test_client()
        response = opener.post(
            "/api/employee/login", json={"username": username, "password": "pass123"}
        )
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))

    def test_employee_login_starts_shift_and_inserts_order_context(self):
        client = self.app_module.app.test_client()
        login = client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        self.assertEqual(login.status_code, 200, login.get_data(as_text=True))
        payload = login.get_json()
        self.assertIn("employee", payload)
        self.assertIn("shift", payload)
        self.assertEqual(payload["employee"]["username"], "cashier1")

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            employee = db.execute("SELECT id FROM employees WHERE username = ?", ("cashier1",)).fetchone()
            product = db.execute("INSERT INTO drinks (name, sell_price, recipe_json, category) VALUES (?, ?, ?, ?)", ("Test Drink", 25, "[]", "hot")).lastrowid
            db.execute("INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) VALUES (?, ?, ?, ?, ?)", ("Milk", "L", 2, 10, 2))
            db.commit()
            with client.session_transaction() as session:
                session["employee_id"] = employee["id"]
                session["cashier_session"] = True

        order = client.post(
            "/api/orders",
            json={"items": [{"id": product, "kind": "drink", "quantity": 1}]},
        )
        self.assertEqual(order.status_code, 201, order.get_data(as_text=True))
        order_data = order.get_json()
        self.assertEqual(order_data["success"], True)
        self.assertIn("order_id", order_data)

        missing_cash = client.post("/api/employee/shift/close", json={})
        self.assertEqual(missing_cash.status_code, 400)
        invalid_cash = client.post("/api/employee/shift/close", json={"counted_cash": "not-a-number"})
        self.assertEqual(invalid_cash.status_code, 400)
        closed = client.post(
            "/api/employee/shift/close",
            json={"counted_cash": 25, "reason": "manual"},
        )
        self.assertEqual(closed.status_code, 200, closed.get_data(as_text=True))
        closed_data = closed.get_json()
        self.assertGreaterEqual(closed_data["payable_amount"], 0)

    def test_handover_closes_previous_shift_when_new_employee_logs_in(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) VALUES (?, '', '', 'Original', 10, 25, 4)",
                ("Handover Test",),
            ).lastrowid
            db.commit()
        first = client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        self.assertEqual(first.status_code, 200)
        sale = client.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 1}]})
        self.assertEqual(sale.status_code, 201, sale.get_data(as_text=True))

        handover_required = client.post("/api/employee/login", json={"username": "cashier2", "password": "pass123"})
        self.assertEqual(handover_required.status_code, 200, handover_required.get_data(as_text=True))
        self.assertTrue(handover_required.get_json()["handover_required"])

        second = client.post("/api/employee/login", json={"username": "cashier2", "password": "pass123", "counted_cash": 20})
        self.assertEqual(second.status_code, 200)

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            open_shift = db.execute("SELECT COUNT(*) AS count FROM shifts WHERE status = 'open'").fetchone()["count"]
            self.assertEqual(open_shift, 1)
            employee_id = db.execute("SELECT id FROM employees WHERE username = ?", ("cashier2",)).fetchone()["id"]
            incoming_shift = db.execute("SELECT opening_cash FROM shifts WHERE employee_id = ? AND status = 'open'", (employee_id,)).fetchone()
            outgoing_shift = db.execute("SELECT counted_cash, cash_variance FROM shifts WHERE employee_id = (SELECT id FROM employees WHERE username = 'cashier1') ORDER BY id DESC LIMIT 1").fetchone()
            self.assertEqual(incoming_shift["opening_cash"], 20)
            self.assertEqual(outgoing_shift["counted_cash"], 20)
            self.assertEqual(outgoing_shift["cash_variance"], -5)

    def test_admin_employee_and_payroll_endpoints_are_available(self):
        self._ensure_open_shift()
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')", ("admin", self.app_module.generate_password_hash("123456")))
            db.commit()

        admin_login = client.post("/admin/login", data={"username": "admin", "password": "123456"}, follow_redirects=False)
        self.assertEqual(admin_login.status_code, 302, admin_login.get_data(as_text=True))

        employees = client.get("/api/admin/employees")
        self.assertEqual(employees.status_code, 200, employees.get_data(as_text=True))
        employee_payload = employees.get_json()
        self.assertTrue(len(employee_payload) >= 2)

        created = client.post("/api/admin/employees", json={"username": "sales3", "password": "abc123", "monthly_salary": 4000, "can_sell": 1})
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))

        projects = client.get("/api/admin/projects")
        self.assertEqual(projects.status_code, 200, projects.get_data(as_text=True))

        payroll = client.get("/api/admin/payroll")
        self.assertEqual(payroll.status_code, 200, payroll.get_data(as_text=True))

    def test_void_sale_requires_reason_and_reverses_cash(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) VALUES (?, '', '', 'Original', 10, 25, 4)",
                ("Return Test",),
            ).lastrowid
            db.commit()

        login = client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        self.assertEqual(login.status_code, 200, login.get_data(as_text=True))
        order = client.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 1}]})
        self.assertEqual(order.status_code, 201, order.get_data(as_text=True))
        order_id = order.get_json()["order_id"]

        missing_reason = client.post("/api/orders/void-last", json={})
        self.assertEqual(missing_reason.status_code, 400, missing_reason.get_data(as_text=True))

        returned = client.post("/api/orders/void-last", json={"reason": "استرجاع بناء على طلب العميل", "employee_name": "cashier1"})
        self.assertEqual(returned.status_code, 200, returned.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            order_row = db.execute("SELECT status, cancel_reason FROM orders WHERE id = ?", (order_id,)).fetchone()
            stock = db.execute("SELECT stock_quantity FROM books WHERE id = ?", (book_id,)).fetchone()["stock_quantity"]
            cash_total = db.execute(
                "SELECT COALESCE(SUM(amount), 0) AS total FROM cash_entries WHERE reference_type IN ('order', 'order_refund') AND reference_id = ?",
                (order_id,),
            ).fetchone()["total"]
        self.assertEqual(order_row["status"], "cancelled")
        self.assertEqual(order_row["cancel_reason"], "استرجاع بناء على طلب العميل")
        self.assertEqual(stock, 4)
        self.assertEqual(cash_total, 0)

    def test_selected_sale_can_be_returned_instead_of_only_the_latest(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            first_book = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) VALUES (?, '', '', 'Original', 10, 25, 4)",
                ("First Return Test",),
            ).lastrowid
            second_book = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) VALUES (?, '', '', 'Original', 10, 35, 4)",
                ("Second Return Test",),
            ).lastrowid
            db.commit()

        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        first_order = client.post("/api/orders", json={"items": [{"id": first_book, "kind": "book", "quantity": 1}]})
        second_order = client.post("/api/orders", json={"items": [{"id": second_book, "kind": "book", "quantity": 1}]})
        self.assertEqual(first_order.status_code, 201)
        self.assertEqual(second_order.status_code, 201)
        history = client.get("/api/cashier/recent-orders?q=First%20Return")
        self.assertEqual(history.status_code, 200, history.get_data(as_text=True))
        self.assertEqual(history.get_json()[0]["id"], first_order.get_json()["order_id"])

        returned = client.post(
            "/api/orders/{}/void".format(first_order.get_json()["order_id"]),
            json={"reason": "استرجاع الصنف الأول", "employee_name": "cashier1"},
        )
        self.assertEqual(returned.status_code, 200, returned.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            statuses = db.execute(
                "SELECT id, status FROM orders ORDER BY id"
            ).fetchall()
        self.assertEqual(statuses[0]["status"], "cancelled")
        self.assertEqual(statuses[1]["status"], "completed")

    def test_order_applies_per_item_discount_and_rejects_invalid_discount(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) VALUES (?, '', '', 'Original', 10, 25, 4)",
                ("Discount Test",),
            ).lastrowid
            db.commit()
        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})

        discounted = client.post(
            "/api/orders",
            json={"items": [{"id": book_id, "kind": "book", "quantity": 1, "discount_percent": 20}]},
        )
        self.assertEqual(discounted.status_code, 201, discounted.get_data(as_text=True))
        order_payload = discounted.get_json()
        self.assertEqual(order_payload["total_amount"], 20)
        self.assertEqual(order_payload["items"][0]["discount_amount"], 5)
        self.assertEqual(order_payload["items"][0]["line_total"], 20)

        invalid = client.post(
            "/api/orders",
            json={"items": [{"id": book_id, "kind": "book", "quantity": 1, "discount_percent": 101}]},
        )
        self.assertEqual(invalid.status_code, 400, invalid.get_data(as_text=True))
        with self.app_module.app.app_context():
            stock = self.app_module.get_db().execute(
                "SELECT stock_quantity FROM books WHERE id = ?", (book_id,)
            ).fetchone()["stock_quantity"]
        self.assertEqual(stock, 3)

    def test_legacy_xls_import_reads_first_sheet(self):
        rows = [
            ["العنوان", "المؤلف", "النوع", "دار النشر", "سعر التكلفة", "سعر البيع", "الكمية"],
            ["Legacy title", "Writer", "Original", "Press", 10, 20, 3],
        ]

        class FakeSheet:
            nrows = len(rows)

            def row_values(self, row_number):
                return rows[row_number]

        class FakeWorkbook:
            def sheet_by_index(self, index):
                self.asserted_sheet = index
                return FakeSheet()

            def release_resources(self):
                pass

        upload = FileStorage(stream=BytesIO(b"legacy xls bytes"), filename="legacy.xls")
        with patch("xlrd.open_workbook", return_value=FakeWorkbook()) as open_workbook:
            parsed = self.app_module.parse_import_file(upload)
        self.assertEqual(parsed, rows)
        self.assertIn("file_contents", open_workbook.call_args.kwargs)

    def test_inventory_permissions_allow_employee_access_only_when_granted(self):
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("UPDATE employees SET can_manage_inventory = 1 WHERE username = 'cashier1'")
            db.commit()

        manager = self.app_module.app.test_client()
        manager.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        self.assertEqual(manager.get("/api/admin/books").status_code, 200)
        created = manager.post(
            "/api/admin/books",
            json={"title": "Employee Added", "author": "", "publisher": "", "type": "Original", "cost_price": 10, "sell_price": 20, "stock_quantity": 2},
        )
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))

        cashier = self.app_module.app.test_client()
        cashier.post("/api/employee/login", json={"username": "cashier2", "password": "pass123", "counted_cash": 0})
        self.assertEqual(cashier.get("/api/admin/books").status_code, 403)

    def test_employee_can_be_fully_updated_and_safely_deleted(self):
        self._ensure_open_shift()
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')", ("admin", self.app_module.generate_password_hash("123456")))
            cursor = db.execute(
                "INSERT INTO employees (username, password_hash, monthly_salary, created_at) VALUES (?, ?, 1000, ?)",
                ("temporary", self.app_module.generate_password_hash("temp123"), "2026-10-27T00:00:00+00:00"),
            )
            employee_id = cursor.lastrowid
            db.commit()
        client.post("/admin/login", data={"username": "admin", "password": "123456"})
        updated = client.put(
            "/api/admin/employees/{}".format(employee_id),
            json={"username": "renamed", "password": "newpass123", "monthly_salary": 2500, "can_sell": 0, "can_manage_inventory": 1},
        )
        self.assertEqual(updated.status_code, 200, updated.get_data(as_text=True))
        self.assertEqual(updated.get_json()["monthly_salary"], 2500)
        self.assertEqual(updated.get_json()["can_manage_inventory"], 1)
        deleted = client.delete("/api/admin/employees/{}".format(employee_id))
        self.assertEqual(deleted.status_code, 200, deleted.get_data(as_text=True))

        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT INTO orders (timestamp, total_amount, items_json, status, employee_id) VALUES (?, 0, '[]', 'completed', (SELECT id FROM employees WHERE username = 'cashier1'))",
                ("2026-10-27T00:00:00+00:00",),
            )
            db.commit()
        logout = client.post("/admin/logout", follow_redirects=False)
        self.assertEqual(logout.status_code, 302)
        self.assertEqual(logout.headers["Location"], "/")
        self.assertEqual(client.get("/api/admin/employees").status_code, 401)
        client.post("/admin/login", data={"username": "admin", "password": "123456"})
        protected = client.delete("/api/admin/employees/1")
        self.assertEqual(protected.status_code, 409)

    def test_employee_and_admin_can_search_and_open_daily_projects(self):
        employee_client = self.app_module.app.test_client()
        current_state = employee_client.get("/api/employee/current")
        self.assertEqual(current_state.status_code, 200, current_state.get_data(as_text=True))
        self.assertFalse(current_state.get_json()["authenticated"])
        login = employee_client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        self.assertEqual(login.status_code, 200)
        projects = employee_client.get("/api/projects")
        self.assertEqual(projects.status_code, 200, projects.get_data(as_text=True))
        employee_search = employee_client.get("/api/search?q=مشاريع")
        self.assertEqual(employee_search.status_code, 200, employee_search.get_data(as_text=True))
        self.assertIn("projects", [result["view"] for result in employee_search.get_json()])
        self.assertIn("attendance", [result["view"] for result in employee_client.get("/api/search?q=حضور").get_json()])

        admin_client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')", ("admin", self.app_module.generate_password_hash("123456")))
            db.commit()
        admin_client.post("/admin/login", data={"username": "admin", "password": "123456"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) VALUES (?, 'pcs', 1, 10, 2)",
                ("Search Material",),
            )
            db.execute(
                "INSERT INTO expenses (date, category, amount, note) VALUES (?, ?, 15, ?)",
                (self.app_module.date.today().isoformat(), "Search Expense", "Search Expense Note"),
            )
            db.commit()
        settings = admin_client.get("/api/admin/settings").get_json()
        configured = admin_client.put(
            "/api/admin/settings",
            json={"shop_name": settings["shop_name"], "shop_address": settings["shop_address"], "shift_hours": 6.5},
        )
        self.assertEqual(configured.status_code, 200, configured.get_data(as_text=True))
        self.assertEqual(employee_client.get("/api/employee/current").get_json()["shift_hours"], 6.5)
        invalid_hours = admin_client.put(
            "/api/admin/settings",
            json={"shop_name": settings["shop_name"], "shop_address": settings["shop_address"], "shift_hours": 25},
        )
        self.assertEqual(invalid_hours.status_code, 400)
        employee_client.post("/api/employee/logout", json={})
        self.assertEqual(employee_client.get("/api/projects").status_code, 200)
        attendance = admin_client.get("/api/admin/attendance")
        self.assertEqual(attendance.status_code, 200, attendance.get_data(as_text=True))
        admin_search = admin_client.get("/api/search?q=الموظفين")
        self.assertEqual(admin_search.status_code, 200, admin_search.get_data(as_text=True))
        self.assertIn("employees", [result["view"] for result in admin_search.get_json()])
        material_search = admin_client.get("/api/search?q=Search%20Material").get_json()
        self.assertIn("materials", [result["view"] for result in material_search])
        expense_search = admin_client.get("/api/search?q=Search%20Expense").get_json()
        self.assertIn("reports", [result["view"] for result in expense_search])

    # --- Batch 2a: material units (g, ml) and recipe protection ---
    def test_material_units_expand_and_recipe_units_are_protected(self):
        normalize = self.app_module.normalize_material_unit
        self.assertEqual(normalize("g"), "g")
        self.assertEqual(normalize("جرام"), "g")
        self.assertEqual(normalize("غرام"), "g")
        self.assertEqual(normalize("ml"), "ml")
        self.assertEqual(normalize("مل"), "ml")
        self.assertEqual(normalize("مليلتر"), "ml")
        self.assertEqual(normalize("كيلو"), "kg")
        self.assertEqual(normalize("لتر"), "L")
        self.assertIsNone(normalize("غير معروف"))

        self._ensure_open_shift()
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()
        client.post("/admin/login", data={"username": "admin", "password": "123456"})

        created = client.post(
            "/api/admin/materials",
            json={"name": "Sugar", "unit": "جرام", "cost_per_unit": 1, "current_stock": 1000, "reorder_level": 10},
        )
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        material_id = created.get_json()["id"]
        water = client.post(
            "/api/admin/materials",
            json={"name": "Water", "unit": "مل", "cost_per_unit": 1, "current_stock": 5000, "reorder_level": 10},
        )
        self.assertEqual(water.status_code, 201, water.get_data(as_text=True))

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            self.assertEqual(
                db.execute("SELECT unit FROM materials WHERE id = ?", (material_id,)).fetchone()["unit"], "g"
            )
            self.assertEqual(
                db.execute("SELECT unit FROM materials WHERE id = ?", (water.get_json()["id"],)).fetchone()["unit"],
                "ml",
            )
            db.execute(
                "INSERT INTO drinks (name, sell_price, recipe_json, category) VALUES (?, 10, ?, 'hot')",
                ("Sweet", json.dumps([{"material_id": material_id, "qty": 50}])),
            )
            db.commit()

        # Changing the unit of a recipe-referenced material must be refused (kg <-> g would corrupt the recipe).
        blocked = client.put(
            "/api/admin/materials/{}".format(material_id),
            json={"name": "Sugar", "unit": "kg", "cost_per_unit": 1, "current_stock": 1000, "reorder_level": 10},
        )
        self.assertEqual(blocked.status_code, 409, blocked.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            self.assertEqual(
                db.execute("SELECT unit FROM materials WHERE id = ?", (material_id,)).fetchone()["unit"], "g"
            )
            recipe = json.loads(
                db.execute("SELECT recipe_json FROM drinks WHERE name = 'Sweet'").fetchone()["recipe_json"]
            )
        self.assertEqual(recipe[0]["qty"], 50)

        # A material that no recipe references may still change its unit.
        free = client.post(
            "/api/admin/materials",
            json={"name": "Free", "unit": "kg", "cost_per_unit": 1, "current_stock": 1, "reorder_level": 1},
        )
        free_id = free.get_json()["id"]
        changed = client.put(
            "/api/admin/materials/{}".format(free_id),
            json={"name": "Free", "unit": "pcs", "cost_per_unit": 1, "current_stock": 1, "reorder_level": 1},
        )
        self.assertEqual(changed.status_code, 200, changed.get_data(as_text=True))

    # --- Batch 2b: permission matrix ---
    def test_permission_matrix_is_enforced_with_staff_logins(self):
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.execute(
                "UPDATE employees SET can_sell = 0, can_manage_inventory = 0, can_manage_expenses = 0 "
                "WHERE username = 'cashier1'"
            )
            db.execute(
                "UPDATE employees SET can_sell = 1, can_manage_inventory = 1, can_manage_expenses = 0 "
                "WHERE username = 'cashier2'"
            )
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Policy Book', '', '', 'Original', 5, 10, 3)"
            ).lastrowid
            db.commit()

        no_sell = self.app_module.app.test_client()
        no_sell.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        denied_sale = no_sell.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 1}]})
        self.assertEqual(denied_sale.status_code, 403, denied_sale.get_data(as_text=True))

        manager = self.app_module.app.test_client()
        manager.post("/api/employee/login", json={"username": "cashier2", "password": "pass123", "counted_cash": 0})
        self.assertEqual(
            manager.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 1}]}).status_code,
            201,
        )
        self.assertEqual(manager.get("/api/admin/books").status_code, 200)
        self.assertEqual(
            manager.post(
                "/api/admin/expenses",
                json={"date": self.app_module.date.today().isoformat(), "category": "متنوع", "amount": 5, "note": "x"},
            ).status_code,
            403,
        )
        self.assertEqual(
            manager.post("/api/categories", json={"label_ar": "قسم", "scope": "drink", "sort_order": 5}).status_code,
            401,
        )
        for admin_only in ("/api/admin/employees", "/api/admin/payroll", "/api/admin/reports", "/api/admin/settings"):
            self.assertEqual(manager.get(admin_only).status_code, 401, admin_only)

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "UPDATE employees SET can_sell = 0, can_manage_inventory = 0, can_manage_expenses = 1 "
                "WHERE username = 'cashier1'"
            )
            db.commit()
        expenses_only = self.app_module.app.test_client()
        expenses_only.post(
            "/api/employee/login", json={"username": "cashier1", "password": "pass123", "counted_cash": 0}
        )
        self.assertEqual(
            expenses_only.post(
                "/api/admin/expenses",
                json={"date": self.app_module.date.today().isoformat(), "category": "متنوع", "amount": 5, "note": "ok"},
            ).status_code,
            201,
        )
        self.assertEqual(expenses_only.get("/api/admin/books").status_code, 403)

        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        self.assertEqual(
            admin.post("/api/categories", json={"label_ar": "قسم المدير", "scope": "drink", "sort_order": 5}).status_code,
            201,
        )

    # --- Batch 2c: admin session hardening ---
    def test_admin_session_hardens_on_cashier_and_logout_but_survives_subviews(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()
        client.post("/admin/login", data={"username": "admin", "password": "123456"})

        # Preserved between admin sub-views.
        self.assertEqual(client.get("/admin?view=books").status_code, 200)
        self.assertEqual(client.get("/api/admin/employees").status_code, 200)

        # Opening the cashier screen ends the admin session.
        self.assertEqual(client.get("/").status_code, 200)
        self.assertEqual(client.get("/api/admin/employees").status_code, 401)

        # Logout also ends the session.
        client.post("/admin/login", data={"username": "admin", "password": "123456"})
        self.assertEqual(client.get("/api/admin/employees").status_code, 200)
        logout = client.post("/admin/logout", follow_redirects=False)
        self.assertEqual(logout.status_code, 302)
        self.assertEqual(logout.headers["Location"], "/")
        self.assertEqual(client.get("/api/admin/employees").status_code, 401)

    # --- Batch 2d: void/return audit ---
    def test_void_records_operator_and_reason_and_keeps_stock_exact(self):
        client = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Audit Book', '', '', 'Original', 10, 25, 5)"
            ).lastrowid
            db.commit()
        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        order = client.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 2}]})
        self.assertEqual(order.status_code, 201, order.get_data(as_text=True))
        order_id = order.get_json()["order_id"]

        blank_reason = client.post("/api/orders/void-last", json={"reason": "   ", "employee_name": "cashier1"})
        self.assertEqual(blank_reason.status_code, 400, blank_reason.get_data(as_text=True))

        missing_operator = client.post("/api/orders/void-last", json={"reason": "تالف"})
        self.assertEqual(missing_operator.status_code, 400, missing_operator.get_data(as_text=True))

        returned = client.post("/api/orders/{}/void".format(order_id), json={"reason": "تالف", "employee_name": "cashier1"})
        self.assertEqual(returned.status_code, 200, returned.get_data(as_text=True))
        payload = returned.get_json()
        self.assertEqual(payload["performed_by_name"], "cashier1")
        self.assertEqual(payload["performed_by_role"], "employee")

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            row = db.execute(
                "SELECT performed_by, performed_by_name, performed_by_role, cancel_reason FROM orders WHERE id = ?",
                (order_id,),
            ).fetchone()
            stock = db.execute("SELECT stock_quantity FROM books WHERE id = ?", (book_id,)).fetchone()[
                "stock_quantity"
            ]
        self.assertEqual(row["performed_by_name"], "cashier1")
        self.assertEqual(row["performed_by_role"], "employee")
        self.assertEqual(row["cancel_reason"], "تالف")
        self.assertIsNotNone(row["performed_by"])
        self.assertEqual(stock, 5)

        history = client.get("/api/cashier/recent-orders").get_json()
        self.assertEqual(history[0]["performed_by_name"], "cashier1")

    # --- Batch 3a: system purge guardrails + audit trail ---
    def test_purge_requires_typed_confirmation_and_is_audited(self):
        cashier = self.app_module.app.test_client()
        cashier.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        denied = cashier.delete("/api/admin/purge/books", json={"confirm": "الكتب"})
        self.assertEqual(denied.status_code, 401, denied.get_data(as_text=True))

        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        catalog = admin.get("/api/admin/purge/scopes")
        self.assertEqual(catalog.status_code, 200, catalog.get_data(as_text=True))
        self.assertEqual(catalog.get_json()["global_phrase"], "تأكيد نهائي")
        self.assertIn("orders", [scope["key"] for scope in catalog.get_json()["scopes"]])

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM books")
            db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Purge Me', '', '', 'Original', 1, 2, 3)"
            )
            db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Purge Me Too', '', '', 'Original', 1, 2, 3)"
            )
            db.commit()

        self.assertEqual(admin.delete("/api/admin/purge/mystery", json={"confirm": "x"}).status_code, 404)
        wrong = admin.delete("/api/admin/purge/books", json={"confirm": "كتب"})
        self.assertEqual(wrong.status_code, 400, wrong.get_data(as_text=True))
        with self.app_module.app.app_context():
            self.assertEqual(
                self.app_module.get_db().execute("SELECT COUNT(*) AS c FROM books").fetchone()["c"], 2
            )

        purged = admin.delete("/api/admin/purge/books", json={"confirm": "الكتب"})
        self.assertEqual(purged.status_code, 200, purged.get_data(as_text=True))
        self.assertEqual(purged.get_json()["deleted"], 2)
        self.assertEqual(purged.get_json()["scope"], "books")
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM books").fetchone()["c"], 0)
            log = db.execute("SELECT * FROM purge_logs ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(log["scope"], "books")
        self.assertEqual(log["scope_label"], "الكتب")
        self.assertEqual(log["deleted_count"], 2)
        self.assertEqual(log["performed_by_name"], "admin")
        self.assertEqual(log["performed_by_role"], "admin")
        self.assertTrue(log["performed_at"])

    def test_global_purge_reseeds_settings_and_refuses_admin_wipe(self):
        self._ensure_open_shift()
        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM books")
            db.execute("DELETE FROM expenses")
            db.execute("UPDATE settings SET value = 'Custom Shop' WHERE key = 'shop_name'")
            db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Gone', '', '', 'Original', 1, 2, 3)"
            )
            db.execute(
                "INSERT INTO expenses (date, category, amount, note) VALUES (?, 'x', 5, 'n')",
                (self.app_module.date.today().isoformat(),),
            )
            db.commit()

        wrong = admin.delete("/api/admin/purge/all", json={"confirm": "كل الداتا"})
        self.assertEqual(wrong.status_code, 400, wrong.get_data(as_text=True))

        # Guardrail: the users table is never purged, so drop the admin directly and
        # confirm the endpoint refuses and rolls every deletion back.
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            admin_id = db.execute("SELECT id FROM users WHERE role = 'admin'").fetchone()["id"]
            db.execute("DELETE FROM users WHERE role = 'admin'")
            db.commit()
        blocked = admin.delete("/api/admin/purge/all", json={"confirm": "تأكيد نهائي"})
        self.assertEqual(blocked.status_code, 409, blocked.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM books").fetchone()["c"], 1)
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM expenses").fetchone()["c"], 1)
            db.execute(
                "INSERT INTO users (id, username, password_hash, role) VALUES (?, 'admin', ?, 'admin')",
                (admin_id, self.app_module.generate_password_hash("123456")),
            )
            db.commit()

        purged = admin.delete("/api/admin/purge/all", json={"confirm": "تأكيد نهائي"})
        self.assertEqual(purged.status_code, 200, purged.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM books").fetchone()["c"], 0)
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM expenses").fetchone()["c"], 0)
            self.assertEqual(db.execute("SELECT COUNT(*) AS c FROM categories").fetchone()["c"], 0)
            self.assertEqual(
                db.execute("SELECT value FROM settings WHERE key = 'shop_name'").fetchone()["value"],
                self.app_module.DEFAULT_SHOP_NAME,
            )
            self.assertEqual(
                db.execute("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'").fetchone()["c"], 1
            )
            log = db.execute("SELECT * FROM purge_logs ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(log["scope"], "all")
        self.assertEqual(log["performed_by_role"], "admin")

    # --- Batch 3b: Excel export round-trip into a clean database ---
    def _catalog_signature(self, db, resource):
        if resource == "books":
            rows = db.execute(
                "SELECT title, author, type, publisher, cost_price, sell_price, stock_quantity FROM books"
            ).fetchall()
            return sorted(tuple(row) for row in rows)
        if resource == "materials":
            rows = db.execute(
                "SELECT name, unit, cost_per_unit, current_stock, reorder_level FROM materials"
            ).fetchall()
            return sorted(tuple(row) for row in rows)
        if resource == "retail":
            rows = db.execute(
                "SELECT name, category, cost_price, sell_price, stock_quantity FROM retail"
            ).fetchall()
            return sorted(tuple(row) for row in rows)
        material_names = {row["id"]: row["name"] for row in db.execute("SELECT id, name FROM materials")}
        signature = []
        for row in db.execute("SELECT name, category, sell_price, recipe_json FROM drinks").fetchall():
            recipe = json.loads(row["recipe_json"] or "[]")
            ingredients = sorted(
                (material_names.get(item.get("material_id"), ""), float(item.get("qty", 0)))
                for item in recipe
            )
            signature.append((row["name"], row["category"], row["sell_price"], tuple(ingredients)))
        return sorted(signature)

    def test_excel_export_round_trips_into_a_clean_database(self):
        from openpyxl import load_workbook

        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            for table in ("drinks", "retail", "books", "materials"):
                db.execute("DELETE FROM " + table)
            milk = db.execute(
                "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) "
                "VALUES ('حليب', 'L', 25, 12.5, 3)"
            ).lastrowid
            sugar = db.execute(
                "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) "
                "VALUES ('سكر', 'g', 0.5, 5000, 500)"
            ).lastrowid
            db.execute(
                "INSERT INTO retail (name, category, cost_price, sell_price, stock_quantity, unit) "
                "VALUES ('بيبسي', 'softdrink', 5, 10, 7, 'pcs')"
            )
            db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('كتاب اختبار', 'مؤلف', 'دار', 'Original', 10, 20, 4)"
            )
            db.execute(
                "INSERT INTO drinks (name, sell_price, recipe_json, category) VALUES ('شاي لاتيه', 35, ?, 'hot')",
                (json.dumps([{"material_id": milk, "qty": 0.25}, {"material_id": sugar, "qty": 15}]),),
            )
            db.commit()
            source_signature = {
                resource: self._catalog_signature(db, resource)
                for resource in ("books", "materials", "retail", "drinks")
            }

        exported = {}
        for resource in ("books", "materials", "retail", "drinks"):
            response = admin.get("/api/admin/export/" + resource)
            self.assertEqual(response.status_code, 200, "export " + resource + " failed")
            disposition = response.headers.get("Content-Disposition", "")
            self.assertIn("attachment", disposition)
            self.assertIn("bookmart_" + resource + "_", disposition)
            exported[resource] = response.data
            workbook = load_workbook(BytesIO(response.data))
            headers = [cell.value for cell in workbook.active[1]]
            self.assertEqual(headers, self.app_module.IMPORT_HEADERS[resource], resource)

        categories_export = admin.get("/api/admin/export/categories")
        self.assertEqual(categories_export.status_code, 200, "export categories failed")
        category_headers = [cell.value for cell in load_workbook(BytesIO(categories_export.data)).active[1]]
        self.assertEqual(category_headers, ["label_ar", "scope", "sort_order", "is_active"])

        # Re-import every exported file into a freshly initialised database.
        fresh_directory = tempfile.TemporaryDirectory()
        self.addCleanup(fresh_directory.cleanup)
        os.environ["BOOK_MART_DATA_DIR"] = fresh_directory.name
        fresh_module = importlib.reload(self.app_module)
        with fresh_module.app.app_context():
            db = fresh_module.get_db()
            for table in ("drinks", "retail", "books", "materials"):
                db.execute("DELETE FROM " + table)
            db.commit()

        fresh = fresh_module.app.test_client()
        fresh.post("/admin/login", data={"username": "admin", "password": "123456"})
        for resource in ("materials", "books", "retail", "drinks"):
            upload = FileStorage(
                stream=BytesIO(exported[resource]), filename="bookmart_" + resource + ".xlsx"
            )
            imported = fresh.post(
                "/api/admin/import/" + resource,
                data={"file": upload},
                content_type="multipart/form-data",
            )
            self.assertEqual(imported.status_code, 200, imported.get_data(as_text=True))
            self.assertEqual(imported.get_json()["failed"], 0, imported.get_data(as_text=True))

        with fresh_module.app.app_context():
            db = fresh_module.get_db()
            for resource in ("books", "materials", "retail", "drinks"):
                self.assertEqual(
                    self._catalog_signature(db, resource),
                    source_signature[resource],
                    "round-trip mismatch for " + resource,
                )

    # --- Batch 4a: cashier notification feed ---
    def test_cashier_notifications_flag_low_materials_and_unavailable_drinks(self):
        client = self.app_module.app.test_client()
        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM drinks")
            db.execute("DELETE FROM materials")
            empty = db.execute(
                "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) "
                "VALUES ('بن نافد', 'g', 0.2, 0, 100)"
            ).lastrowid
            db.execute(
                "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) "
                "VALUES ('سكر منخفض', 'kg', 30, 0.5, 2)"
            )
            db.execute(
                "INSERT INTO drinks (name, sell_price, recipe_json, category) VALUES ('لاتيه', 30, ?, 'hot')",
                (json.dumps([{"material_id": empty, "qty": 10}]),),
            )
            db.commit()

        response = client.get("/api/cashier/notifications")
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        payload = response.get_json()
        kinds = [alert["kind"] for alert in payload["alerts"]]
        self.assertIn("out_of_stock", kinds)
        self.assertIn("low_stock", kinds)
        self.assertIn("unavailable_drink", kinds)
        self.assertEqual(payload["count"], len(payload["alerts"]))
        self.assertGreaterEqual(payload["danger_count"], 1)
        # Danger alerts must lead the list so cashiers see shortages first.
        self.assertEqual(payload["alerts"][0]["severity"], "danger")

    # --- Batch 4b: expenses mirror into the cash drawer ---
    def test_expense_is_mirrored_in_cash_drawer_and_removed_on_delete(self):
        self._ensure_open_shift()
        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM expenses")
            db.execute("DELETE FROM cash_entries")
            db.commit()

        created = admin.post(
            "/api/admin/expenses",
            json={
                "date": self.app_module.date.today().isoformat(),
                "category": "كهرباء",
                "amount": 150,
                "note": "فاتورة شهرية",
            },
        )
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        expense_id = created.get_json()["id"]

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            entry = db.execute(
                "SELECT * FROM cash_entries WHERE reference_type = 'expense' AND reference_id = ?",
                (expense_id,),
            ).fetchone()
            expense = db.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
        self.assertIsNotNone(entry)
        self.assertEqual(entry["amount"], -150)
        self.assertEqual(entry["entry_type"], "expense")
        self.assertIsNotNone(expense["business_day_id"])

        removed = admin.delete("/api/admin/expenses/" + str(expense_id))
        self.assertEqual(removed.status_code, 200, removed.get_data(as_text=True))
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            remaining = db.execute(
                "SELECT COUNT(*) AS c FROM cash_entries WHERE reference_type = 'expense' AND reference_id = ?",
                (expense_id,),
            ).fetchone()["c"]
            self.assertEqual(remaining, 0)

    # --- Batch 4c: admin dashboard gating by employee permissions ---
    def test_dashboard_access_follows_employee_permissions(self):
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "UPDATE employees SET can_sell = 0, can_manage_expenses = 1, "
                "can_manage_purchases = 0, can_manage_inventory = 0 WHERE username = 'cashier1'"
            )
            db.execute(
                "INSERT INTO employees (username, password_hash, monthly_salary, can_sell, "
                "can_manage_expenses, can_manage_purchases, can_manage_inventory, is_active, created_at) "
                "VALUES ('clerk', ?, 2000, 0, 0, 0, 0, 1, ?)",
                (self.app_module.generate_password_hash("pass123"), "2026-10-26T00:00:00+00:00"),
            )
            db.commit()

        expenses_client = self.app_module.app.test_client()
        login = expenses_client.post(
            "/api/employee/login", json={"username": "cashier1", "password": "pass123"}
        )
        self.assertEqual(login.status_code, 200, login.get_data(as_text=True))
        page = expenses_client.get("/admin")
        self.assertEqual(page.status_code, 200, page.get_data(as_text=True))
        self.assertIn('data-initial-view="expenses"', page.get_data(as_text=True))
        # An expenses-only employee reaches the expense API but not inventory.
        self.assertEqual(expenses_client.get("/api/admin/expenses").status_code, 200)
        self.assertEqual(expenses_client.get("/api/admin/materials").status_code, 403)

        clerk = self.app_module.app.test_client()
        # cashier1's shift is still open, so confirm the drawer handover on login.
        clerk.post(
            "/api/employee/login",
            json={"username": "clerk", "password": "pass123", "counted_cash": 0},
        )
        blocked = clerk.get("/admin")
        self.assertEqual(blocked.status_code, 302)
        self.assertEqual(blocked.headers["Location"], "/")

    # --- Batch 5a: nothing is recorded unless an employee has an open shift ---
    def test_write_actions_are_refused_without_an_open_shift(self):
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()
        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})

        # Employees exist but none has opened a shift, so the write is refused.
        blocked = admin.post(
            "/api/admin/books",
            json={
                "title": "No Shift",
                "author": "",
                "publisher": "",
                "type": "Original",
                "cost_price": 1,
                "sell_price": 2,
                "stock_quantity": 1,
            },
        )
        self.assertEqual(blocked.status_code, 409, blocked.get_data(as_text=True))
        with self.app_module.app.app_context():
            self.assertIsNone(
                self.app_module.get_db().execute(
                    "SELECT id FROM books WHERE title = 'No Shift'"
                ).fetchone()
            )

        # The very same request succeeds once an employee opens a shift.
        self._ensure_open_shift()
        allowed = admin.post(
            "/api/admin/books",
            json={
                "title": "With Shift",
                "author": "",
                "publisher": "",
                "type": "Original",
                "cost_price": 1,
                "sell_price": 2,
                "stock_quantity": 1,
            },
        )
        self.assertEqual(allowed.status_code, 201, allowed.get_data(as_text=True))

    def test_open_shift_gate_is_bypassed_only_for_an_empty_staff_roster(self):
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute("DELETE FROM employees")
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()
        admin = self.app_module.app.test_client()
        admin.post("/admin/login", data={"username": "admin", "password": "123456"})
        bootstrapped = admin.post(
            "/api/admin/books",
            json={
                "title": "Bootstrap",
                "author": "",
                "publisher": "",
                "type": "Original",
                "cost_price": 1,
                "sell_price": 2,
                "stock_quantity": 1,
            },
        )
        self.assertEqual(bootstrapped.status_code, 201, bootstrapped.get_data(as_text=True))

    # --- Batch 5b: the audit trail remembers who did what, automatically ---
    def test_audit_trail_records_the_acting_employee_automatically(self):
        client = self.app_module.app.test_client()
        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            book_id = db.execute(
                "INSERT INTO books (title, author, publisher, type, cost_price, sell_price, stock_quantity) "
                "VALUES ('Audit Trail', '', '', 'Original', 10, 25, 4)"
            ).lastrowid
            db.commit()
        order = client.post("/api/orders", json={"items": [{"id": book_id, "kind": "book", "quantity": 1}]})
        self.assertEqual(order.status_code, 201, order.get_data(as_text=True))

        with self.app_module.app.app_context():
            log = self.app_module.get_db().execute(
                "SELECT * FROM audit_logs ORDER BY id DESC LIMIT 1"
            ).fetchone()
        self.assertIsNotNone(log)
        self.assertEqual(log["actor_name"], "cashier1")
        self.assertEqual(log["actor_role"], "employee")
        self.assertEqual(log["action"], "POST")
        self.assertEqual(log["entity"], "/api/orders")

    # --- Batch 5c: the employee session and shift survive an admin visit ---
    def test_employee_session_survives_admin_visit_and_logout(self):
        client = self.app_module.app.test_client()
        client.post("/api/employee/login", json={"username": "cashier1", "password": "pass123"})
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()

        client.post("/admin/login", data={"username": "admin", "password": "123456"})
        self.assertEqual(client.get("/api/admin/employees").status_code, 200)

        # Opening the cashier screen drops only the admin id, not the employee.
        self.assertEqual(client.get("/").status_code, 200)
        self.assertEqual(client.get("/api/admin/employees").status_code, 401)
        state = client.get("/api/employee/current").get_json()
        self.assertTrue(state["authenticated"])
        self.assertEqual(state["employee"]["username"], "cashier1")
        self.assertIsNotNone(state["shift"])

        # An admin logout also keeps the employee logged in with their shift.
        client.post("/admin/login", data={"username": "admin", "password": "123456"})
        logout = client.post("/admin/logout", follow_redirects=False)
        self.assertEqual(logout.status_code, 302)
        self.assertEqual(logout.headers["Location"], "/")
        after = client.get("/api/employee/current").get_json()
        self.assertTrue(after["authenticated"])
        self.assertEqual(after["employee"]["username"], "cashier1")
        self.assertIsNotNone(after["shift"])

    def test_purchase_intake_requires_mandatory_positive_unit_cost(self):
        self._ensure_open_shift()
        admin = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            item = db.execute("SELECT id, name, current_stock FROM materials LIMIT 1").fetchone()
            if not item:
                db.execute(
                    "INSERT INTO materials (name, unit, cost_per_unit, current_stock, reorder_level) VALUES ('شاي أحمر', 'جرام', 10, 100, 20)"
                )
                item = db.execute("SELECT id, name, current_stock FROM materials WHERE name = 'شاي أحمر'").fetchone()
            db.commit()
            item_id = item["id"]
            initial_stock = item["current_stock"]

        admin.post("/admin/login", data={"username": "admin", "password": "123456"})

        # 1. Reject missing unit_cost
        res_missing = admin.post(
            "/api/purchases",
            json={
                "date": self.app_module.date.today().isoformat(),
                "items": [{"kind": "material", "id": item_id, "quantity": 10}],
            },
        )
        self.assertEqual(res_missing.status_code, 400)
        self.assertIn("مطلوبة وإجبارية", res_missing.get_json()["error"])

        # 2. Reject zero or negative unit_cost
        res_zero = admin.post(
            "/api/purchases",
            json={
                "date": self.app_module.date.today().isoformat(),
                "items": [{"kind": "material", "id": item_id, "quantity": 10, "unit_cost": 0}],
            },
        )
        self.assertEqual(res_zero.status_code, 400)
        self.assertIn("أكبر من صفر", res_zero.get_json()["error"])

        # 3. Accept valid positive unit_cost and verify total is strictly calculated from lines
        res_valid = admin.post(
            "/api/purchases",
            json={
                "date": self.app_module.date.today().isoformat(),
                "amount": 99999,  # Attempt manual override, should be ignored
                "items": [{"kind": "material", "id": item_id, "quantity": 10, "unit_cost": 15.5}],
            },
        )
        self.assertEqual(res_valid.status_code, 201)
        self.assertEqual(res_valid.get_json()["amount"], 155.0)
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            updated = db.execute("SELECT current_stock FROM materials WHERE id = ?", (item_id,)).fetchone()
            self.assertEqual(updated["current_stock"], initial_stock + 10)

    def test_retail_with_fractional_units_like_kg_or_ml_in_stock_and_intake(self):
        self._ensure_open_shift()
        admin = self.app_module.app.test_client()
        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                ("admin", self.app_module.generate_password_hash("123456")),
            )
            db.commit()

        admin.post("/admin/login", data={"username": "admin", "password": "123456"})

        # Create retail item with unit 'كجم' and fractional stock 2.5
        created = admin.post(
            "/api/admin/retail",
            json={
                "name": "بن برازيلي مطحون",
                "category": "softdrink",
                "cost_price": 200,
                "sell_price": 300,
                "stock_quantity": 2.5,
                "unit": "كجم",
            },
        )
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        retail_id = created.get_json()["id"]

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            row = db.execute("SELECT stock_quantity, unit FROM retail WHERE id = ?", (retail_id,)).fetchone()
            self.assertEqual(row["stock_quantity"], 2.5)
            self.assertEqual(row["unit"], "كجم")

        # Register goods intake for retail item with decimal quantity 1.250
        res_intake = admin.post(
            "/api/purchases",
            json={
                "date": self.app_module.date.today().isoformat(),
                "items": [{"kind": "retail", "id": retail_id, "quantity": 1.25, "unit_cost": 210}],
            },
        )
        self.assertEqual(res_intake.status_code, 201, res_intake.get_data(as_text=True))
        self.assertEqual(res_intake.get_json()["amount"], round(1.25 * 210, 2))

        with self.app_module.app.app_context():
            db = self.app_module.get_db()
            row = db.execute("SELECT stock_quantity FROM retail WHERE id = ?", (retail_id,)).fetchone()
            self.assertEqual(row["stock_quantity"], 3.75)


if __name__ == "__main__":
    unittest.main()
