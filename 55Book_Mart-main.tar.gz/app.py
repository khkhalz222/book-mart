"""Local POS application. Build with PyInstaller from a 32-bit Win7 environment."""

import csv
import html
import io
import json
import math
import os
import secrets
import sqlite3
import sys
import threading
import unicodedata
import webbrowser
from datetime import date, datetime, timedelta
from functools import wraps
from html.parser import HTMLParser
from pathlib import Path

from flask import Flask, g, jsonify, redirect, render_template, request, send_file, session, url_for, abort
from werkzeug.security import check_password_hash, generate_password_hash

import qrcode_gen


DEFAULT_SHOP_NAME = "Book Mart"
MAX_IMPORT_BYTES = 5 * 1024 * 1024
MAX_IMPORT_ROWS = 1000
MATERIAL_UNITS = {
    "g": "جرام",
    "kg": "كجم",
    "ml": "مل",
    "L": "لتر",
    "pcs": "قطعة",
}
# Canonical unit scales are used only to protect recipes: every unit belongs to a
# dimension (mass/volume/count) and carries a scale factor within that dimension.
# A material referenced by recipe_json must never be rescaled (e.g. kg <-> g),
# because recipe quantities are stored as raw numbers in the material's own unit.
MATERIAL_UNIT_SCALES = {
    "g": ("mass", 1.0),
    "kg": ("mass", 1000.0),
    "ml": ("volume", 1.0),
    "L": ("volume", 1000.0),
    "pcs": ("count", 1.0),
}
DRINK_CATEGORIES = {
    "hot": "ساخن",
    "espresso": "إسبريسو",
    "juice": "عصائر طازة",
    "frappe": "فريبي/بلند",
    "iced": "مشروبات مثلجة",
    "soda": "موهيتو/صودا",
    "smoothie": "سموذي",
    "milkshake": "ميلك شيك",
    "hotchoc": "ساکولاة ساخنة",
}
RETAIL_CATEGORIES = {
    "softdrink": "مشروبات غازية/جاهزة",
    "cookie": "کوكيز",
    "extra": "إضافات",
}
CATEGORY_SEEDS = [
    (slug, label, "drink", order)
    for order, (slug, label) in enumerate(DRINK_CATEGORIES.items(), 1)
] + [
    (slug, label, "retail", order)
    for order, (slug, label) in enumerate(RETAIL_CATEGORIES.items(), 1)
]
SEEDED_DRINKS = [
    ("شاي", "hot", 30), ("يانسون", "hot", 40), ("أعشاب", "hot", 35),
    ("قهوة تركي", "hot", 50), ("قهوة فرنسي", "hot", 65), ("قهوة بندق", "hot", 70),
    ("سايدر ساخن", "hot", 70),
    ("إسبريسو شوت", "espresso", 75), ("ماكياتو", "espresso", 80),
    ("كورتادو", "espresso", 85), ("فلات وايت", "espresso", 100),
    ("لاتيه", "espresso", 110), ("كابتشينو", "espresso", 110),
    ("موكا", "espresso", 120), ("موكا أبيض", "espresso", 120),
    ("عصير فراولة", "juice", 90), ("عصير مانجو", "juice", 90),
    ("عصير ليمون", "juice", 70), ("عصير برتقال", "juice", 75),
    ("فريبي كلاسيك", "frappe", 130), ("فريبي كراميل", "frappe", 140),
    ("فريبي سولتد كراميل", "frappe", 140), ("فريبي كراميل كريم بروليه", "frappe", 140),
    ("فريبي موكا", "frappe", 140), ("فريبي موكا أبيض", "frappe", 140),
    ("ماتشا بلند", "frappe", 150), ("فريبي فراولة", "frappe", 130),
    ("فريبي خوخ", "frappe", 130), ("فريبي باشن فروت", "frappe", 130),
    ("فريبي بلوبيري", "frappe", 130),
    ("آيس لاتيه", "iced", 110), ("آيس كابتشينو", "iced", 110),
    ("آيس موكا", "iced", 120), ("آيس موكا أبيض", "iced", 120),
    ("آيس ماتشا لاتيه", "iced", 120), ("آيس إسبانيش لاتيه", "iced", 130),
    ("آيس شيكن وايت موكا", "iced", 150),
    ("موهيتو كلاسيك", "soda", 90), ("موهيتو مانجو", "soda", 100),
    ("موهيتو بلوبيري", "soda", 100), ("موهيتو فراولة", "soda", 100),
    ("موهيتو باشن فروت", "soda", 100), ("بلو كوراساو", "soda", 100),
    ("ميكس ريدبول", "soda", 120), ("كريزي بينك", "soda", 130),
    ("سموذي فراولة", "smoothie", 100), ("سموذي خوخ", "smoothie", 100),
    ("سموذي بلوبيري", "smoothie", 100), ("سموذي باشن فروت", "smoothie", 100),
    ("ميلك شيك شوكولاتة", "milkshake", 140), ("ميلك شيك كراميل", "milkshake", 140),
    ("ميلك شيك سولتد كراميل", "milkshake", 140), ("ميلك شيك فانيليا", "milkshake", 140),
    ("ميلك شيك أوريو", "milkshake", 140), ("ميلك شيك خوخ", "milkshake", 140),
    ("ميلك شيك باشن فروت", "milkshake", 140), ("ميلك شيك فراولة", "milkshake", 140),
    ("ميلك شيك بلوبيري", "milkshake", 140), ("ميلك شيك كيوي", "milkshake", 140),
    ("ميلك شيك مانجو", "milkshake", 140),
    ("ساکولاة ساخنة", "hotchoc", 110), ("ساکولاة مارشميلو", "hotchoc", 125),
    ("ساکولاة فراولة", "hotchoc", 130),
]
SEEDED_RETAIL = [
    ("بيبسي", "softdrink", 50), ("ريدبول", "softdrink", 80), ("مية", "softdrink", 15),
    ("كلاسيك كوكيز", "cookie", 50), ("ريد فيلفيت كوكيز", "cookie", 60),
    ("نكهة إضافية", "extra", 30), ("صوص إضافي", "extra", 30),
    ("دريم ويب", "extra", 30), ("شوت إسبريسو", "extra", 40),
]
RETAIL_BOOK_ALIASES = {
    "بيبسي": ("بيبسي", "softdrink", 50),
    "pepsi": ("بيبسي", "softdrink", 50),
    "softdrink": ("بيبسي", "softdrink", 50),
    "ريدبول": ("ريدبول", "softdrink", 80),
    "redbull": ("ريدبول", "softdrink", 80),
    "red bull": ("ريدبول", "softdrink", 80),
    "مية": ("مية", "softdrink", 15),
    "water": ("مية", "softdrink", 15),
    "cookie": ("كلاسيك كوكيز", "cookie", 50),
    "cookies": ("كلاسيك كوكيز", "cookie", 50),
    "كلاسيك كوكيز": ("كلاسيك كوكيز", "cookie", 50),
    "كوكيز": ("كلاسيك كوكيز", "cookie", 50),
    "کوكيز": ("كلاسيك كوكيز", "cookie", 50),
    "ريد فيلفيت كوكيز": ("ريد فيلفيت كوكيز", "cookie", 60),
    "extra": ("نكهة إضافية", "extra", 30),
    "extras": ("نكهة إضافية", "extra", 30),
    "نكهة إضافية": ("نكهة إضافية", "extra", 30),
    "صوص إضافي": ("صوص إضافي", "extra", 30),
    "اضافات": ("نكهة إضافية", "extra", 30),
    "إضافات": ("نكهة إضافية", "extra", 30),
    "دريم ويب": ("دريم ويب", "extra", 30),
    "شوت إسبريسو": ("شوت إسبريسو", "extra", 40),
}
SEEDED_BOOKS = [
    ("موسوعة العلوم", "Original", 80, 110, 39),
    ("رواية الظل", "High Copy", 60, 100, 6),
]

# Every editable piece of text that can appear on a printed receipt. The admin
# replaces any of these from the settings screen; an empty value hides the line.
RECEIPT_SETTING_DEFAULTS = {
    "receipt_tagline": "Art & Gallery \u00b7 \u0641\u0631\u0639 \u0648\u0633\u0637 \u0627\u0644\u0628\u0644\u062f",
    "receipt_invoice_label": "\u0641\u0627\u062a\u0648\u0631\u0629",
    "receipt_cashier_label": "\u0627\u0644\u0643\u0627\u0634\u064a\u0631",
    "receipt_items_header": "\u0628\u0646\u062f \u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629",
    "receipt_items_count_label": "\u0639\u062f\u062f \u0627\u0644\u0623\u0635\u0646\u0627\u0641",
    "receipt_subtotal_label": "\u0627\u0644\u0645\u062c\u0645\u0648\u0639 \u0627\u0644\u0641\u0631\u0639\u064a",
    "receipt_discount_label": "\u0627\u0644\u062e\u0635\u0645",
    "receipt_total_label": "\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a",
    "receipt_payment_label": "\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639",
    "receipt_paid_label": "\u0627\u0644\u0645\u062f\u0641\u0648\u0639",
    "receipt_change_label": "\u0627\u0644\u0628\u0627\u0642\u064a",
    "receipt_thanks": "\u0634\u0643\u0631\u0627\u064b \u0644\u0632\u064a\u0627\u0631\u062a\u0643\u0645",
    "receipt_contact_label": "\u0644\u0644\u0627\u0633\u062a\u0641\u0633\u0627\u0631",
    "receipt_phone": "0100 000 0000",
    "receipt_email": "bookmart@",
    "receipt_policy": "\u0627\u062d\u062a\u0641\u0638 \u0628\u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629 \u2014 \u0627\u0644\u0627\u0633\u062a\u0628\u062f\u0627\u0644 \u062e\u0644\u0627\u0644 3 \u0623\u064a\u0627\u0645",
    "receipt_currency": "\u062c.\u0645",
    "receipt_qr_mode": "none",
    "receipt_qr_value": "",
    "receipt_paper_width": "58",
    "receipt_show_logo": "1",
    "receipt_auto_print": "1",
}
RECEIPT_SETTING_KEYS = tuple(RECEIPT_SETTING_DEFAULTS)
RECEIPT_QR_MODES = ("none", "text", "url", "phone", "whatsapp", "email")
RECEIPT_PAPER_WIDTHS = ("58", "72", "80")
RECEIPT_FLAG_KEYS = ("receipt_show_logo", "receipt_auto_print")
PAYMENT_METHODS = ("\u0646\u0642\u062f\u064a", "\u0643\u0631\u062a", "\u0645\u062d\u0641\u0638\u0629")

# The uploaded brand image lives beside the database so a PyInstaller build can
# never write inside its own bundle.
LOGO_SETTINGS_KEY = "receipt_logo_file"
LOGO_SUFFIXES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}
MAX_LOGO_BYTES = 2 * 1024 * 1024



def resource_path(relative_path):
    """Resolve bundled resources both in development and in a PyInstaller build."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative_path


def data_directory():
    override = os.environ.get("BOOK_MART_DATA_DIR")
    if override:
        location = Path(override)
    elif os.environ.get("LOCALAPPDATA"):
        location = Path(os.environ["LOCALAPPDATA"]) / DEFAULT_SHOP_NAME.replace(" ", "")
    else:
        location = Path(__file__).resolve().parent
    location.mkdir(parents=True, exist_ok=True)
    return location


DATA_DIR = data_directory()
DATABASE = DATA_DIR / "database.db"
app = Flask(
    __name__,
    template_folder=str(resource_path("templates")),
    static_folder=str(resource_path("static")),
)
app.config.update(
    SECRET_KEY=None,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    DATABASE=str(DATABASE),
    MAX_CONTENT_LENGTH=MAX_IMPORT_BYTES + 65536,
)


def get_db():
    if "db" not in g:
        connection = sqlite3.connect(app.config["DATABASE"], timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        g.db = connection
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def seed_catalog(db):
    for name, category, price in SEEDED_DRINKS:
        seed = db.execute(
            "INSERT OR IGNORE INTO catalog_seed_keys(name, kind, category) VALUES (?, 'drink', ?)",
            (name, category),
        )
        if seed.rowcount:
            exists = db.execute(
                "SELECT 1 FROM drinks WHERE name = ? AND category = ? LIMIT 1",
                (name, category),
            ).fetchone()
            if not exists:
                db.execute(
                    "INSERT OR IGNORE INTO drinks(name, sell_price, recipe_json, category) "
                    "VALUES (?, ?, '[]', ?)",
                    (name, price, category),
                )

    for name, category, price in SEEDED_RETAIL:
        seed = db.execute(
            "INSERT OR IGNORE INTO catalog_seed_keys(name, kind, category) VALUES (?, 'retail', ?)",
            (name, category),
        )
        if seed.rowcount:
            db.execute(
                """INSERT OR IGNORE INTO retail
                   (name, category, cost_price, sell_price, stock_quantity, unit)
                   VALUES (?, ?, 0, ?, 0, 'قطعة')""",
                (name, category, price),
            )

    for title, book_type, cost, price, stock in SEEDED_BOOKS:
        seed = db.execute(
            "INSERT OR IGNORE INTO catalog_seed_keys(name, kind, category) VALUES (?, 'book', ?)",
            (title, book_type),
        )
        if seed.rowcount:
            exists = db.execute(
                "SELECT 1 FROM books WHERE title = ? AND type = ? LIMIT 1",
                (title, book_type),
            ).fetchone()
            if not exists:
                db.execute(
                    """INSERT OR IGNORE INTO books
                       (title, author, publisher, type, cost_price, sell_price, stock_quantity)
                       VALUES (?, '', '', ?, ?, ?, ?)""",
                    (title, book_type, cost, price, stock),
                )


def normalized_catalog_name(value):
    text = str(value or "").strip().casefold().replace("ك", "ک").replace("ى", "ي")
    return "".join(character for character in text if character.isalnum())


def migrated_retail_details(title):
    normalized = normalized_catalog_name(title)
    for alias, details in RETAIL_BOOK_ALIASES.items():
        alias_normalized = normalized_catalog_name(alias)
        if alias_normalized == normalized or (
            len(alias_normalized) >= 5 and normalized.startswith(alias_normalized)
        ):
            return details
    if any(
        normalized_catalog_name(keyword) in normalized
        for keyword in ("كوكيز", "کوكيز")
    ):
        return (str(title).strip(), "cookie", 0)
    if any(
        normalized_catalog_name(keyword) in normalized
        for keyword in ("إضافات", "إضافي", "اضافي")
    ):
        return (str(title).strip(), "extra", 0)
    return None


def is_retail_book_collision(title):
    if migrated_retail_details(title) is not None:
        return True
    normalized = normalized_catalog_name(title)
    return any(
        normalized_catalog_name(keyword) in normalized
        for keyword in ("كوكيز", "کوكيز", "إضافات", "إضافي", "اضافي")
    )


def migrate_retail_books(db):
    if db.execute(
        "SELECT 1 FROM settings WHERE key = 'retail_books_migrated_v1'"
    ).fetchone():
        return
    books = db.execute("SELECT id, title, sell_price FROM books ORDER BY id").fetchall()
    for book in books:
        details = migrated_retail_details(book["title"])
        if details is None:
            continue
        retail_name, category, default_price = details
        db.execute(
            """INSERT OR IGNORE INTO retail
               (name, category, cost_price, sell_price, stock_quantity, unit)
               VALUES (?, ?, 0, ?, 0, 'قطعة')""",
            (retail_name, category, book["sell_price"] or default_price),
        )
        db.execute(
            "UPDATE retail SET sell_price = ? WHERE name = ? AND category = ?",
            (book["sell_price"] if book["sell_price"] is not None else default_price, retail_name, category),
        )
        db.execute("DELETE FROM books WHERE id = ?", (book["id"],))
    db.execute(
        "INSERT INTO settings(key, value) VALUES ('retail_books_migrated_v1', 'complete')"
    )


def seed_categories(db):
    for slug, label, scope, sort_order in CATEGORY_SEEDS:
        db.execute(
            """INSERT OR IGNORE INTO categories
               (slug, label_ar, scope, sort_order, is_active, created_at)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (slug, label, scope, sort_order, datetime.now().astimezone().isoformat(timespec="seconds")),
        )
    for table, scope in (("drinks", "drink"), ("retail", "retail")):
        for row in db.execute("SELECT DISTINCT category FROM " + table).fetchall():
            category = str(row["category"] or "").strip()
            if table == "drinks" and category.lower() == "cold":
                category = "iced"
            if not category:
                continue
            existing = db.execute(
                "SELECT scope FROM categories WHERE slug = ?", (category,)
            ).fetchone()
            if existing and existing["scope"] != scope:
                base = scope + "-" + category_slug_base(category)
                candidate = base
                suffix = 2
                while db.execute(
                    "SELECT 1 FROM categories WHERE slug = ?", (candidate,)
                ).fetchone():
                    candidate = base + "-" + str(suffix)
                    suffix += 1
                db.execute(
                    "UPDATE " + table + " SET category = ? WHERE category = ?",
                    (candidate, category),
                )
                category = candidate
            db.execute(
                """INSERT OR IGNORE INTO categories
                   (slug, label_ar, scope, sort_order, is_active, created_at)
                   VALUES (?, ?, ?, 100, 1, ?)""",
                (category, category, scope, datetime.now().astimezone().isoformat(timespec="seconds")),
            )


def initialize_database():
    with app.app_context():
        db = get_db()
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'admin'
            );
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                monthly_salary REAL NOT NULL DEFAULT 0 CHECK(monthly_salary >= 0),
                can_sell INTEGER NOT NULL DEFAULT 1,
                can_manage_expenses INTEGER NOT NULL DEFAULT 0,
                can_manage_purchases INTEGER NOT NULL DEFAULT 0,
                can_manage_inventory INTEGER NOT NULL DEFAULT 0,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS business_days (
                id INTEGER PRIMARY KEY,
                project_date TEXT NOT NULL UNIQUE,
                opening_cash REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL,
                closed_at TEXT,
                expected_cash REAL,
                counted_cash REAL,
                closing_variance REAL
            );
            CREATE TABLE IF NOT EXISTS shifts (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL REFERENCES employees(id),
                business_day_id INTEGER NOT NULL REFERENCES business_days(id),
                started_at TEXT NOT NULL,
                ended_at TEXT,
                status TEXT NOT NULL DEFAULT 'open',
                opening_cash REAL NOT NULL DEFAULT 0,
                expected_cash REAL,
                counted_cash REAL,
                cash_variance REAL,
                worked_seconds INTEGER NOT NULL DEFAULT 0,
                payable_amount REAL NOT NULL DEFAULT 0,
                closure_reason TEXT,
                handover_to INTEGER REFERENCES employees(id)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS one_open_shift_per_employee
                ON shifts(employee_id) WHERE status = 'open';
            CREATE TABLE IF NOT EXISTS cash_entries (
                id INTEGER PRIMARY KEY,
                business_day_id INTEGER NOT NULL REFERENCES business_days(id),
                shift_id INTEGER REFERENCES shifts(id),
                employee_id INTEGER REFERENCES employees(id),
                entry_type TEXT NOT NULL,
                amount REAL NOT NULL,
                category TEXT NOT NULL DEFAULT '',
                reference_type TEXT NOT NULL DEFAULT '',
                reference_id INTEGER,
                description TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                UNIQUE(reference_type, reference_id, entry_type)
            );
            CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY,
                business_day_id INTEGER NOT NULL REFERENCES business_days(id),
                shift_id INTEGER REFERENCES shifts(id),
                employee_id INTEGER REFERENCES employees(id),
                timestamp TEXT NOT NULL,
                supplier TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount >= 0),
                items_json TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS payroll_settlements (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL REFERENCES employees(id),
                month TEXT NOT NULL,
                monthly_salary REAL NOT NULL,
                worked_seconds INTEGER NOT NULL,
                scheduled_seconds INTEGER NOT NULL,
                completed_shifts INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount >= 0),
                paid_at TEXT NOT NULL,
                UNIQUE(employee_id, month)
            );
            CREATE TABLE IF NOT EXISTS materials (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                unit TEXT NOT NULL,
                cost_per_unit REAL NOT NULL CHECK(cost_per_unit >= 0),
                current_stock REAL NOT NULL DEFAULT 0 CHECK(current_stock >= 0),
                reorder_level REAL NOT NULL DEFAULT 5 CHECK(reorder_level >= 0)
            );
            CREATE TABLE IF NOT EXISTS drinks (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                sell_price REAL NOT NULL CHECK(sell_price >= 0),
                recipe_json TEXT NOT NULL DEFAULT '[]',
                category TEXT NOT NULL DEFAULT 'hot' -- NEW COLUMN FOR HOT/COLD CLASSIFICATION
            );
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL DEFAULT '',
                publisher TEXT NOT NULL DEFAULT '',
                type TEXT NOT NULL DEFAULT '', -- ORIGINAL/HIGH COPY
                cost_price REAL NOT NULL CHECK(cost_price >= 0),
                sell_price REAL NOT NULL CHECK(sell_price >= 0),
                stock_quantity INTEGER NOT NULL DEFAULT 0 CHECK(stock_quantity >= 0)
            );
            CREATE TABLE IF NOT EXISTS retail (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                cost_price REAL NOT NULL DEFAULT 0 CHECK(cost_price >= 0),
                sell_price REAL NOT NULL CHECK(sell_price >= 0),
                stock_quantity INTEGER NOT NULL DEFAULT 0 CHECK(stock_quantity >= 0),
                unit TEXT NOT NULL DEFAULT 'قطعة',
                UNIQUE(name, category)
            );
            CREATE TABLE IF NOT EXISTS catalog_seed_keys (
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                category TEXT NOT NULL,
                PRIMARY KEY(name, kind, category)
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY,
                timestamp TEXT NOT NULL,
                total_amount REAL NOT NULL,
                items_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'completed',
                cancelled_at TEXT,
                cancel_reason TEXT NOT NULL DEFAULT '',
                performed_by INTEGER,
                performed_by_name TEXT NOT NULL DEFAULT '',
                performed_by_role TEXT NOT NULL DEFAULT '',
                employee_id INTEGER REFERENCES employees(id),
                shift_id INTEGER REFERENCES shifts(id),
                business_day_id INTEGER REFERENCES business_days(id)
            );
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY,
                date TEXT NOT NULL,
                category TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount >= 0),
                note TEXT NOT NULL DEFAULT '',
                business_day_id INTEGER REFERENCES business_days(id),
                shift_id INTEGER REFERENCES shifts(id),
                employee_id INTEGER REFERENCES employees(id),
                purchase_id INTEGER REFERENCES purchases(id)
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY,
                slug TEXT NOT NULL UNIQUE,
                label_ar TEXT NOT NULL,
                scope TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 100,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS project_log_notes (
                id INTEGER PRIMARY KEY,
                project_date TEXT NOT NULL,
                event_time TEXT NOT NULL,
                title TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                created_by TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS purge_logs (
                id INTEGER PRIMARY KEY,
                scope TEXT NOT NULL,
                scope_label TEXT NOT NULL DEFAULT '',
                deleted_count INTEGER NOT NULL DEFAULT 0,
                performed_by INTEGER,
                performed_by_name TEXT NOT NULL DEFAULT '',
                performed_by_role TEXT NOT NULL DEFAULT '',
                performed_at TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY,
                created_at TEXT NOT NULL,
                actor_id INTEGER,
                actor_name TEXT NOT NULL DEFAULT '',
                actor_role TEXT NOT NULL DEFAULT '',
                action TEXT NOT NULL,
                entity TEXT NOT NULL DEFAULT '',
                entity_id INTEGER,
                details TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS closing_reports (
                id INTEGER PRIMARY KEY,
                period_type TEXT NOT NULL,
                period_key TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'closed',
                payload_json TEXT NOT NULL,
                expected_cash REAL,
                counted_cash REAL,
                closing_variance REAL,
                closed_at TEXT NOT NULL,
                closed_by TEXT NOT NULL DEFAULT '',
                auto_generated INTEGER NOT NULL DEFAULT 0,
                UNIQUE(period_type, period_key)
            );
            """
        )
        
        # Migration Logic: Add columns if they don't exist (for older databases)
        migrations = [
            ("employees", "can_manage_inventory", "INTEGER NOT NULL DEFAULT 0"),
            ("materials", "reorder_level", "REAL NOT NULL DEFAULT 5"),
            ("drinks", "category", "TEXT NOT NULL DEFAULT 'hot'"), # Ensure category exists
            ("books", "publisher", "TEXT NOT NULL DEFAULT ''"),
            ("orders", "cancelled_at", "TEXT"),
            ("orders", "cancel_reason", "TEXT NOT NULL DEFAULT ''"),
            ("orders", "performed_by", "INTEGER"),
            ("orders", "performed_by_name", "TEXT NOT NULL DEFAULT ''"),
            ("orders", "performed_by_role", "TEXT NOT NULL DEFAULT ''"),
            ("orders", "employee_id", "INTEGER REFERENCES employees(id)"),
            ("orders", "shift_id", "INTEGER REFERENCES shifts(id)"),
            ("orders", "business_day_id", "INTEGER REFERENCES business_days(id)"),
            ("expenses", "business_day_id", "INTEGER REFERENCES business_days(id)"),
            ("expenses", "shift_id", "INTEGER REFERENCES shifts(id)"),
            ("expenses", "employee_id", "INTEGER REFERENCES employees(id)"),
            ("expenses", "purchase_id", "INTEGER REFERENCES purchases(id)"),
            ("purchases", "stock_adjusted", "INTEGER NOT NULL DEFAULT 0"),
            ("purchases", "date", "TEXT"),
            ("orders", "payment_method", "TEXT NOT NULL DEFAULT ''"),
            ("orders", "paid_amount", "REAL"),
        ]
        
        for table, column, definition in migrations:
            try:
                cols = {row["name"] for row in db.execute(f"PRAGMA table_info({table})")}
                if column not in cols:
                    db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
                    print(f"Migrated: Added '{column}' to '{table}'")
            except Exception as e:
                print(f"Migration warning for {table}.{column}: {e}")

        # Legacy book reorder_level is intentionally retained in old databases but unused.
        if not db.execute(
            "SELECT 1 FROM settings WHERE key = 'data_normalization_v1'"
        ).fetchone():
            # One-time normalization: Arabic book types and recognizable material units only.
            db.execute(
                "UPDATE books SET type = 'Original' WHERE LOWER(TRIM(type)) IN ('أصلي', 'أصلية')"
            )
            db.execute(
                "UPDATE books SET type = 'High Copy' WHERE LOWER(TRIM(type)) IN ('نسخة عالية', 'نسخة', 'هاي كوبي')"
            )
            for row in db.execute("SELECT id, unit FROM materials").fetchall():
                normalized_unit = normalize_material_unit(row["unit"])
                if normalized_unit:
                    db.execute("UPDATE materials SET unit = ? WHERE id = ?", (normalized_unit, row["id"]))
            db.execute(
                "INSERT INTO settings(key, value) VALUES ('data_normalization_v1', 'complete')"
            )
        if not db.execute(
            "SELECT 1 FROM settings WHERE key = 'drink_categories_v2'"
        ).fetchone():
            db.execute("UPDATE drinks SET category = 'iced' WHERE LOWER(TRIM(category)) = 'cold'")
            db.execute(
                "INSERT INTO settings(key, value) VALUES ('drink_categories_v2', 'complete')"
            )

        seed_categories(db)
        migrate_retail_books(db)
        seed_catalog(db)
        db.execute(
            "INSERT OR IGNORE INTO users(username, password_hash, role) VALUES (?, ?, ?)",
            ("admin", generate_password_hash("123456"), "admin"),
        )
        db.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES ('secret_key', ?)",
            (secrets.token_hex(32),),
        )
        db.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES ('shop_name', ?)",
            (DEFAULT_SHOP_NAME,),
        )
        db.execute("INSERT OR IGNORE INTO settings(key, value) VALUES ('shop_address', '')")
        db.execute("INSERT OR IGNORE INTO settings(key, value) VALUES ('shift_hours', '8')")
        for key, value in RECEIPT_SETTING_DEFAULTS.items():
            db.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (key, value))
        app.config["SECRET_KEY"] = db.execute(
            "SELECT value FROM settings WHERE key = 'secret_key'"
        ).fetchone()["value"]
        db.commit()


def api_error(message, status=400):
    return jsonify({"error": message}), status


@app.errorhandler(413)
def request_too_large(_error):
    return api_error("حجم الملف يتجاوز الحد المسموح للاستيراد.")


def normalize_material_unit(value):
    text = unicodedata.normalize("NFKC", str(value or "")).strip().casefold()
    text = "".join(character for character in text if not unicodedata.combining(character))
    aliases = {
        "g": "g", "جم": "g", "جرام": "g", "غرام": "g", "gram": "g", "grams": "g",
        "gramme": "g", "grammes": "g",
        "kg": "kg", "كيلو": "kg", "كجم": "kg", "كغ": "kg",
        "kilogram": "kg", "kilograms": "kg",
        "ml": "ml", "مل": "ml", "ملي": "ml", "مليلتر": "ml", "ملل": "ml",
        "milliliter": "ml", "milliliters": "ml", "millilitre": "ml", "millilitres": "ml",
        "l": "L", "لتر": "L", "ل": "L", "liter": "L", "litre": "L",
        "liters": "L", "litres": "L",
        "pcs": "pcs", "pc": "pcs", "piece": "pcs", "pieces": "pcs",
        "قطعة": "pcs", "حبة": "pcs",
    }
    return aliases.get(text)


def material_unit_conversion_factor(from_unit, to_unit):
    """Multiplier converting a quantity from one canonical unit to another.

    Returns None when either unit is unknown or the units belong to different
    dimensions (e.g. kg -> pcs), meaning no safe automatic conversion exists.
    """
    from_scale = MATERIAL_UNIT_SCALES.get(from_unit)
    to_scale = MATERIAL_UNIT_SCALES.get(to_unit)
    if from_scale is None or to_scale is None:
        return None
    if from_scale[0] != to_scale[0]:
        return None
    return from_scale[1] / to_scale[1]


def material_recipe_usage(db, material_id):
    """True when the material appears in any drink's recipe_json."""
    for row in db.execute("SELECT recipe_json FROM drinks").fetchall():
        try:
            recipe = json.loads(row["recipe_json"] or "[]")
        except (TypeError, ValueError):
            continue
        if isinstance(recipe, list) and any(
            isinstance(item, dict) and str(item.get("material_id")) == str(material_id)
            for item in recipe
        ):
            return True
    return False


def material_unit_label(value):
    return MATERIAL_UNITS.get(value, value or "")


def normalize_book_type(value):
    normalized = str(value or "").strip().casefold()
    if normalized == "original":
        return "Original"
    if normalized == "high copy":
        return "High Copy"
    raise ValueError("نوع الكتاب يجب أن يكون Original أو High Copy.")


def current_shop_name():
    row = get_db().execute("SELECT value FROM settings WHERE key = 'shop_name'").fetchone()
    return (row["value"].strip() if row and row["value"] else "") or DEFAULT_SHOP_NAME


def shop_name_direction(name):
    return "rtl" if any("\u0600" <= character <= "\u06ff" for character in name) else "ltr"


def shop_template_context():
    name = current_shop_name()
    return {
        "shop_name": name,
        "shop_name_dir": shop_name_direction(name),
        "logo_available": resource_path("static/img/logo.png").is_file(),
    }


EMPLOYEE_PERMISSION_FIELDS = (
    "can_manage_inventory",
    "can_manage_expenses",
    "can_manage_purchases",
    "can_sell",
)


def session_employee():
    """Return the active, logged-in employee row, or None when absent/inactive."""
    employee_id = session.get("employee_id")
    if not employee_id:
        return None
    employee = get_db().execute(
        "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
    ).fetchone()
    if employee is None:
        session.clear()
    return employee


def admin_required(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
        return function(*args, **kwargs)

    return wrapped


def dashboard_access_required(function):
    """Allow admins and any active employee that holds at least one permission.

    Employees keep read access only to the dashboard sections matching their
    granted permissions; the concrete per-view gating happens in the page route.
    """
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get("admin_id"):
            return function(*args, **kwargs)
        employee = session_employee()
        if employee is None:
            return redirect(url_for("admin_login_page"))
        if not any(employee[field] for field in EMPLOYEE_PERMISSION_FIELDS):
            return redirect(url_for("cashier_page"))
        return function(*args, **kwargs)

    return wrapped


def cashier_session_required(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        if not session.get("cashier_session") and not session.get("admin_id") and not session.get("employee_id"):
            return api_error("افتح شاشة الكاشير أولاً.", 401)
        return function(*args, **kwargs)

    return wrapped


def selling_required(function):
    """Selling (and return/void) requires an admin session or an active employee with can_sell."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get("admin_id"):
            return function(*args, **kwargs)
        employee_id = session.get("employee_id")
        if not employee_id:
            return api_error("يرجى تسجيل دخول الكاشير للمتابعة.", 401)
        employee = get_db().execute(
            "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
        ).fetchone()
        if employee is None:
            session.clear()
            return api_error("حساب الموظف غير نشط.", 403)
        if not employee["can_sell"]:
            return api_error("لا تملك صلاحية إتمام عمليات البيع.", 403)
        return function(*args, **kwargs)

    return wrapped


def employee_or_admin_required(permission=None):
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if session.get("admin_id"):
                return function(*args, **kwargs)
            employee_id = session.get("employee_id")
            if not employee_id:
                return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
            employee = get_db().execute(
                "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
            ).fetchone()
            if employee is None:
                session.clear()
                return api_error("حساب الموظف غير نشط.", 403)
            if permission and not employee[permission]:
                return api_error("لا تملك صلاحية تنفيذ هذا الإجراء.", 403)
            return function(*args, **kwargs)

        return wrapped
    return decorate


def inventory_or_expense_manager_required(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get("admin_id"):
            return function(*args, **kwargs)
        employee_id = session.get("employee_id")
        if not employee_id:
            return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
        employee = get_db().execute(
            "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
        ).fetchone()
        if employee is None:
            session.clear()
            return api_error("حساب الموظف غير نشط.", 403)
        permission = "can_manage_expenses" if kwargs.get("resource") == "expenses" else "can_manage_inventory"
        if not employee[permission]:
            return api_error("لا تملك صلاحية إدارة هذا القسم.", 403)
        return function(*args, **kwargs)

    return wrapped


def open_shift_context(db):
    """Return the single open shift row, or None when no shift is open."""
    return db.execute(
        "SELECT * FROM shifts WHERE status = 'open' ORDER BY id DESC LIMIT 1"
    ).fetchone()


def active_employee_count(db):
    return db.execute(
        "SELECT COUNT(*) AS total FROM employees WHERE is_active = 1"
    ).fetchone()["total"]


def open_shift_required(function):
    """Block every recorded operation unless an employee is on an open shift.

    The rule applies to admins and employees alike so that anything written to
    the system is tied to the person on duty for full accountability. The only
    escape hatch is a brand-new system with no active employees at all, which
    would otherwise be impossible to bootstrap.
    """
    @wraps(function)
    def wrapped(*args, **kwargs):
        db = get_db()
        if open_shift_context(db) is None and active_employee_count(db) > 0:
            return api_error(
                "لا يمكن تنفيذ أي عملية بدون موظف فاتح وردية. "
                "على موظف تسجيل الحضور وفتح الوردية أولاً.",
                409,
            )
        return function(*args, **kwargs)

    return wrapped


def ensure_business_day(db, day=None):
    day = day or date.today()
    day_text = day.isoformat() if isinstance(day, date) else str(day)
    row = db.execute(
        "SELECT * FROM business_days WHERE project_date = ?", (day_text,)
    ).fetchone()
    if row:
        return row
    previous = db.execute(
        "SELECT * FROM business_days WHERE project_date < ? ORDER BY project_date DESC LIMIT 1",
        (day_text,),
    ).fetchone()
    opening_cash = 0.0
    if previous:
        keys = previous.keys()
        if previous["status"] == "closed" and "counted_cash" in keys and previous["counted_cash"] is not None:
            # A sealed day hands over the cash that was actually counted, so
            # closing with zero really does start the new day from zero.
            opening_cash = round(float(previous["counted_cash"]), 2)
        else:
            opening_cash = business_day_cash(db, previous["id"])
    cursor = db.execute(
        "INSERT INTO business_days(project_date, opening_cash, status, created_at) VALUES (?, ?, 'open', ?)",
        (day_text, opening_cash, datetime.now().astimezone().isoformat(timespec="seconds")),
    )
    db.commit()
    return db.execute("SELECT * FROM business_days WHERE id = ?", (cursor.lastrowid,)).fetchone()


def business_day_cash(db, business_day_id):
    day = db.execute(
        "SELECT opening_cash FROM business_days WHERE id = ?", (business_day_id,)
    ).fetchone()
    if day is None:
        return 0.0
    entries = db.execute(
        "SELECT COALESCE(SUM(amount), 0) AS balance FROM cash_entries WHERE business_day_id = ?",
        (business_day_id,),
    ).fetchone()["balance"]
    return round(day["opening_cash"] + entries, 2)


def add_cash_entry(db, business_day_id, entry_type, amount, category="", reference_type="", reference_id=None, description="", shift_id=None, employee_id=None):
    db.execute(
        """INSERT INTO cash_entries
           (business_day_id, shift_id, employee_id, entry_type, amount, category,
            reference_type, reference_id, description, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            business_day_id, shift_id, employee_id, entry_type, round(amount, 2),
            category, reference_type, reference_id, description,
            datetime.now().astimezone().isoformat(timespec="seconds"),
        ),
    )


def active_employee_shift(db, employee_id):
    return db.execute(
        "SELECT * FROM shifts WHERE employee_id = ? AND status = 'open' ORDER BY id DESC LIMIT 1",
        (employee_id,),
    ).fetchone()


def configured_shift_seconds(db):
    row = db.execute("SELECT value FROM settings WHERE key = 'shift_hours'").fetchone()
    return int(float(row["value"] if row else 8) * 3600)


def close_employee_shift(db, shift, counted_cash=None, reason="manual", handover_to=None):
    ended_at = datetime.now().astimezone()
    started_at = datetime.fromisoformat(shift["started_at"])
    worked_seconds = max(0, int((ended_at - started_at).total_seconds()))
    employee = db.execute(
        "SELECT monthly_salary FROM employees WHERE id = ?", (shift["employee_id"],)
    ).fetchone()
    scheduled_seconds = configured_shift_seconds(db)
    daily_rate = employee["monthly_salary"] / 30
    payable = round(daily_rate * worked_seconds / scheduled_seconds, 2)
    expected_cash = round(float(business_day_cash(db, shift["business_day_id"])), 2)
    counted = expected_cash if counted_cash is None else round(float(counted_cash), 2)
    cash_variance = round(counted - expected_cash, 2)
    db.execute(
        """UPDATE shifts SET ended_at = ?, status = 'closed', expected_cash = ?,
           counted_cash = ?, cash_variance = ?, worked_seconds = ?, payable_amount = ?,
           closure_reason = ?, handover_to = ? WHERE id = ? AND status = 'open'""",
        (
            ended_at.isoformat(timespec="seconds"), expected_cash, counted,
            cash_variance, worked_seconds, payable, reason, handover_to, shift["id"],
        ),
    )
    db.commit()
    return {
        "shift_id": shift["id"],
        "worked_seconds": worked_seconds,
        "payable_amount": payable,
        "expected_cash": expected_cash,
        "counted_cash": counted,
        "cash_variance": cash_variance,
    }


def ensure_employee_shift(db, employee_id, business_day_id=None, opening_cash=None):
    if business_day_id is None:
        business_day_id = ensure_business_day(db, date.today())["id"]
    existing = active_employee_shift(db, employee_id)
    if existing and existing["status"] == "open":
        return existing

    for open_shift in db.execute(
        "SELECT * FROM shifts WHERE status = 'open' ORDER BY id"
    ).fetchall():
        if open_shift["employee_id"] == employee_id:
            continue
        close_employee_shift(
            db,
            open_shift,
            round(float(business_day_cash(db, open_shift["business_day_id"])), 2),
            "handover",
            handover_to=employee_id,
        )

    now = datetime.now().astimezone()
    drawer_balance = (
        float(business_day_cash(db, business_day_id))
        if opening_cash is None
        else round(float(opening_cash), 2)
    )
    cursor = db.execute(
        """INSERT INTO shifts
           (employee_id, business_day_id, started_at, ended_at, status, opening_cash, expected_cash, counted_cash, cash_variance, worked_seconds, payable_amount, closure_reason, handover_to)
           VALUES (?, ?, ?, NULL, 'open', ?, NULL, NULL, NULL, 0, 0, '', NULL)""",
        (
            employee_id,
            business_day_id,
            now.isoformat(timespec="seconds"),
            drawer_balance,
        ),
    )
    db.commit()
    return db.execute("SELECT * FROM shifts WHERE id = ?", (cursor.lastrowid,)).fetchone()


def employee_public_payload(employee):
    if employee is None:
        return None
    payload = dict(employee)
    payload.pop("password_hash", None)
    return payload


def positive_number(value, label, allow_zero=True):
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(label + " يجب أن يكون رقمًا.")
    if not math.isfinite(number) or number < 0 or (not allow_zero and number == 0):
        raise ValueError(label + (" يجب أن يكون صفرًا أو أكثر." if allow_zero else " يجب أن يكون أكبر من صفر."))
    return number


def product_recipe_cost(db, recipe):
    if not isinstance(recipe, list):
        raise ValueError("يجب أن تكون الوصفة قائمة مكونات صالحة.")
    cost = 0.0
    for ingredient in recipe:
        if not isinstance(ingredient, dict) or "material_id" not in ingredient or "qty" not in ingredient:
            raise ValueError("يجب تحديد المادة والكمية لكل مكوّن.")
        try:
            material_id = int(ingredient["material_id"])
        except (TypeError, ValueError):
            raise ValueError("معرّف المادة في الوصفة غير صالح.")
        quantity = positive_number(ingredient["qty"], "كمية المكوّن", False)
        material = db.execute(
            "SELECT cost_per_unit FROM materials WHERE id = ?", (material_id,)
        ).fetchone()
        if material is None:
            raise ValueError("تشير الوصفة إلى مادة غير موجودة.")
        cost += material["cost_per_unit"] * quantity
    return cost


# --- Routes ---

@app.get("/")
def cashier_page():
    # Opening the cashier screen ends any admin session, so the next admin visit
    # always requires a fresh login (Batch 2c session hardening). The employee
    # session -- and therefore the open shift -- is deliberately preserved so the
    # cashier stays logged in and their shift is not forgotten.
    if session.get("admin_id"):
        session.pop("admin_id", None)
    session["cashier_session"] = True
    return render_template("cashier.html", **shop_template_context())

@app.get("/admin/login")
def admin_login_page():
    if session.get("admin_id"):
        return redirect(url_for("admin_dashboard_page"))
    return render_template("admin_login.html", **shop_template_context())

@app.post("/admin/login")
def admin_login():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    user = get_db().execute(
        "SELECT id, password_hash FROM users WHERE username = ? AND role = 'admin'",
        (username,),
    ).fetchone()
    if user is None or not check_password_hash(user["password_hash"], password):
        return render_template(
            "admin_login.html",
            error="اسم المستخدم أو كلمة المرور غير صحيحة.",
            **shop_template_context(),
        ), 401
    session["admin_id"] = user["id"]
    session["cashier_session"] = True
    return redirect(url_for("admin_dashboard_page"))

@app.post("/admin/logout")
def admin_logout():
    # Leaving the admin panel only drops the admin identity. An employee session
    # (and the shift it owns) is kept so returning to the cashier does not look
    # like the employee was logged out.
    session.pop("admin_id", None)
    if not session.get("employee_id"):
        session.clear()
    session["cashier_session"] = True
    return redirect(url_for("cashier_page"))

@app.get("/admin")
@dashboard_access_required
def admin_dashboard_page():
    is_admin = bool(session.get("admin_id"))
    if is_admin:
        permissions = {"inventory": True, "expenses": True, "purchases": True, "sell": True}
    else:
        employee = session_employee()
        if employee is None:
            return redirect(url_for("admin_login_page"))
        permissions = {
            "inventory": bool(employee["can_manage_inventory"]),
            "expenses": bool(employee["can_manage_expenses"]),
            "purchases": bool(employee["can_manage_purchases"]),
            "sell": bool(employee["can_sell"]),
        }
    allowed = set()
    if permissions["inventory"]:
        allowed.update({"books", "drinks", "materials", "retail", "categories"})
    if permissions["expenses"]:
        allowed.add("expenses")
    if is_admin:
        allowed.update({"dashboard", "employees", "projects", "attendance", "payroll", "settings", "purge"})
    requested = str(request.args.get("view") or "").strip()
    if requested in allowed:
        initial_view = requested
    elif is_admin:
        initial_view = "dashboard"
    elif permissions["inventory"]:
        initial_view = "books"
    elif permissions["expenses"]:
        initial_view = "expenses"
    else:
        initial_view = "books"
    return render_template(
        "admin_dashboard.html",
        is_admin=is_admin,
        permissions=permissions,
        initial_view=initial_view,
        **shop_template_context(),
    )


@app.post("/api/employee/login")
def employee_login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))

    if not username or not password:
        return api_error("اسم المستخدم وكلمة المرور مطلوبان.")

    db = get_db()
    employee = db.execute(
        "SELECT * FROM employees WHERE username = ? AND is_active = 1",
        (username,),
    ).fetchone()
    if employee is None or not check_password_hash(employee["password_hash"], password):
        return api_error("اسم المستخدم أو كلمة المرور غير صحيحة.", 401)

    counted_cash = None
    if data.get("counted_cash") is not None and str(data.get("counted_cash")).strip() != "":
        try:
            counted_cash = float(data["counted_cash"])
        except (TypeError, ValueError):
            return api_error("رصيد الدرج المعدود يجب أن يكون رقمًا.")
        if not math.isfinite(counted_cash) or counted_cash < 0:
            return api_error("رصيد الدرج المعدود يجب أن يكون صفرًا أو أكثر.")

    # Opening a shift is the moment the system checks the calendar: on the 1st
    # the finished months are sealed automatically before anyone records more.
    auto_closed_months = auto_close_finished_months(db)

    business_day = ensure_business_day(db)
    if business_day["status"] == "closed":
        return api_error(
            "تم تقفيل يوم " + format_iso_datetime(business_day["project_date"])
            + "؛ لا يمكن فتح وردية أخرى فيه. انتظر يومًا جديدًا أو اطلب من المدير إعادة فتحه.",
            409,
        )
    outgoing = db.execute(
        """SELECT s.*, e.username AS employee_username
           FROM shifts s JOIN employees e ON e.id = s.employee_id
           WHERE s.status = 'open' AND s.employee_id != ?
           ORDER BY s.id DESC LIMIT 1""",
        (employee["id"],),
    ).fetchone()

    if outgoing is not None and counted_cash is None:
        outgoing_expected = round(float(business_day_cash(db, outgoing["business_day_id"])), 2)
        started_at = datetime.fromisoformat(outgoing["started_at"])
        handover_hours = round(
            max(0.0, (datetime.now().astimezone() - started_at).total_seconds()) / 3600, 2
        )
        return jsonify({
            "success": False,
            "handover_required": True,
            "outgoing_employee": outgoing["employee_username"],
            "expected_cash": outgoing_expected,
            "shift_hours": handover_hours,
            "message": "الوردية الحالية مفتوحة باسم " + outgoing["employee_username"] +
                       ". أدخل رصيد الدرج المعدود لتأكيد الاستلام.",
        })

    if outgoing is not None:
        close_employee_shift(db, outgoing, counted_cash, "handover", handover_to=employee["id"])

    session.clear()
    session["employee_id"] = employee["id"]
    session["cashier_session"] = True
    shift = ensure_employee_shift(
        db,
        employee["id"],
        business_day["id"],
        opening_cash=counted_cash,
    )
    return jsonify({
        "success": True,
        "employee": employee_public_payload(employee),
        "business_day": dict(business_day),
        "shift": dict(shift),
        "shift_hours": configured_shift_seconds(db) / 3600,
        "auto_closed_months": [
            {"key": entry["key"], "closed_at": entry["closed_at"],
             "expected_cash": entry["expected_cash"], "counted_cash": entry["counted_cash"]}
            for entry in auto_closed_months
        ],
    })


@app.post("/api/employee/logout")
def employee_logout():
    session.clear()
    session["cashier_session"] = True
    return jsonify({"ok": True})


@app.get("/api/employee/current")
def employee_current_state():
    employee_id = session.get("employee_id")
    if not employee_id:
        return jsonify({"authenticated": False})

    db = get_db()
    employee = db.execute("SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)).fetchone()
    if employee is None:
        session.clear()
        return api_error("حساب الموظف غير موجود أو غير نشط.", 403)

    shift = active_employee_shift(db, employee_id)
    business_day = None
    if shift is not None:
        business_day = db.execute(
            "SELECT * FROM business_days WHERE id = ?",
            (shift["business_day_id"],),
        ).fetchone()
    return jsonify({
        "authenticated": True,
        "employee": employee_public_payload(employee),
        "shift": dict(shift) if shift else None,
        "business_day": dict(business_day) if business_day else None,
        "cash_drawer": round(float(business_day_cash(db, business_day["id"])) if business_day else 0.0, 2),
        "shift_hours": configured_shift_seconds(db) / 3600,
        # The cashier decides whether to fire the printer straight away.
        "receipt_auto_print": receipt_settings(db)["receipt_auto_print"] == "1",
    })


@app.post("/api/employee/shift/close")
def close_employee_shift_route():
    employee_id = session.get("employee_id")
    if not employee_id:
        return api_error("لم يتم تسجيل دخول موظف في الجلسة الحالية.", 401)

    data = request.get_json(silent=True)
    if data is not None and not isinstance(data, dict):
        return api_error("بيانات إنهاء الوردية غير صالحة.")
    data = data or {}

    raw_counted = data.get("counted_cash")
    if raw_counted is None or str(raw_counted).strip() == "":
        return api_error("رصيد الدرج المعدود مطلوب لإنهاء الوردية.")
    try:
        counted_cash = float(raw_counted)
    except (TypeError, ValueError):
        return api_error("رصيد الدرج المعدود يجب أن يكون رقمًا.")
    if not math.isfinite(counted_cash) or counted_cash < 0:
        return api_error("رصيد الدرج المعدود يجب أن يكون صفرًا أو أكثر.")
    reason = str(data.get("reason", "manual")).strip() or "manual"

    db = get_db()
    shift = active_employee_shift(db, employee_id)
    if shift is None:
        return api_error("لا توجد وردية مفتوحة لهذا الموظف.", 404)

    result = close_employee_shift(db, shift, counted_cash=counted_cash, reason=reason)
    return jsonify(result)


def employee_summary_payload(row):
    if row is None:
        return None
    payload = dict(row)
    payload.pop("password_hash", None)
    return payload


@app.get("/api/admin/employees")
@admin_required
def list_admin_employees():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM employees ORDER BY is_active DESC, id ASC"
    ).fetchall()
    return jsonify([employee_summary_payload(row) for row in rows])


@app.post("/api/admin/employees")
@admin_required
@open_shift_required
def create_admin_employee():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", "")).strip()
    if not username or not password:
        return api_error("اسم المستخدم وكلمة المرور مطلوبان.", 400)
    monthly_salary = positive_number(data.get("monthly_salary", 0), "راتب الموظف", True)
    can_sell = bool(int(data.get("can_sell", 1) or 0))
    can_manage_expenses = bool(int(data.get("can_manage_expenses", 0) or 0))
    can_manage_purchases = bool(int(data.get("can_manage_purchases", 0) or 0))
    can_manage_inventory = bool(int(data.get("can_manage_inventory", 0) or 0))

    db = get_db()
    if db.execute("SELECT 1 FROM employees WHERE username = ?", (username,)).fetchone():
        return api_error("اسم المستخدم موجود بالفعل.", 409)

    cursor = db.execute(
        "INSERT INTO employees (username, password_hash, monthly_salary, can_sell, can_manage_expenses, can_manage_purchases, can_manage_inventory, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)",
        (
            username,
            generate_password_hash(password),
            monthly_salary,
            int(can_sell),
            int(can_manage_expenses),
            int(can_manage_purchases),
            int(can_manage_inventory),
            datetime.now().astimezone().isoformat(timespec="seconds"),
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM employees WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(employee_summary_payload(row)), 201


@app.put("/api/admin/employees/<int:item_id>")
@admin_required
@open_shift_required
def update_admin_employee(item_id):
    data = request.get_json(silent=True) or {}
    db = get_db()
    row = db.execute("SELECT * FROM employees WHERE id = ?", (item_id,)).fetchone()
    if row is None:
        return api_error("الموظف غير موجود.", 404)

    username = str(data.get("username", row["username"])).strip() or row["username"]
    password = str(data.get("password", "")).strip()
    monthly_salary = positive_number(data.get("monthly_salary", row["monthly_salary"]), "راتب الموظف", True)
    can_sell = bool(int(data.get("can_sell", row["can_sell"]) or 0))
    can_manage_expenses = bool(int(data.get("can_manage_expenses", row["can_manage_expenses"]) or 0))
    can_manage_purchases = bool(int(data.get("can_manage_purchases", row["can_manage_purchases"]) or 0))
    can_manage_inventory = bool(int(data.get("can_manage_inventory", row["can_manage_inventory"]) or 0))
    is_active = int(bool(data.get("is_active", row["is_active"])))

    if db.execute("SELECT 1 FROM employees WHERE username = ? AND id != ?", (username, item_id)).fetchone():
        return api_error("اسم المستخدم مستخدم من موظف آخر.", 409)

    values = [
        username,
        generate_password_hash(password) if password else row["password_hash"],
        monthly_salary,
        int(can_sell),
        int(can_manage_expenses),
        int(can_manage_purchases),
        int(can_manage_inventory),
        is_active,
        item_id,
    ]
    db.execute(
        "UPDATE employees SET username = ?, password_hash = ?, monthly_salary = ?, can_sell = ?, can_manage_expenses = ?, can_manage_purchases = ?, can_manage_inventory = ?, is_active = ? WHERE id = ?",
        values,
    )
    db.commit()
    updated = db.execute("SELECT * FROM employees WHERE id = ?", (item_id,)).fetchone()
    return jsonify(employee_summary_payload(updated))


@app.delete("/api/admin/employees/<int:item_id>")
@admin_required
@open_shift_required
def delete_admin_employee(item_id):
    db = get_db()
    if db.execute("SELECT 1 FROM employees WHERE id = ?", (item_id,)).fetchone() is None:
        return api_error("الموظف غير موجود.", 404)
    references = (
        ("shifts", "employee_id"),
        ("orders", "employee_id"),
        ("expenses", "employee_id"),
        ("purchases", "employee_id"),
        ("cash_entries", "employee_id"),
        ("payroll_settlements", "employee_id"),
    )
    for table, column in references:
        if db.execute(
            "SELECT 1 FROM " + table + " WHERE " + column + " = ? LIMIT 1",
            (item_id,),
        ).fetchone():
            return api_error("لا يمكن حذف موظف له سجل ورديات أو مبيعات أو حسابات. أوقف حسابه بدلًا من ذلك.", 409)
    db.execute("DELETE FROM employees WHERE id = ?", (item_id,))
    db.commit()
    return jsonify({"ok": True, "id": item_id})


def format_iso_datetime(value, fmt=None):
    """Convert an ISO timestamp into a simple, readable Arabic-friendly string."""
    if not value:
        return ""
    raw = str(value)
    try:
        parsed = datetime.fromisoformat(raw)
    except (TypeError, ValueError):
        return raw
    if fmt:
        return parsed.strftime(fmt)
    if parsed.hour == 0 and parsed.minute == 0 and parsed.second == 0:
        return parsed.strftime("%d/%m/%Y")
    period = "ص" if parsed.hour < 12 else "م"
    hour12 = parsed.hour % 12 or 12
    return parsed.strftime("%d/%m/%Y") + " · " + "{:02d}:{:02d}".format(hour12, parsed.minute) + " " + period


def local_datetime_for_report(value):
    parsed = datetime.fromisoformat(value) if isinstance(value, str) else value
    return parsed.astimezone()


def business_date_for(value):
    """Map a local timestamp to its 10:00-start business date for reporting."""
    parsed = local_datetime_for_report(value)
    business_date = parsed.date()
    if parsed.hour < 10:
        business_date -= timedelta(days=1)
    return business_date


def today_sales_summary(db, now=None):
    business_date = business_date_for(now or datetime.now().astimezone())
    business_date_text = business_date.isoformat()
    next_date_text = (business_date + timedelta(days=1)).isoformat()
    candidates = db.execute(
        """SELECT id, timestamp, total_amount, items_json
           FROM orders
           WHERE status = 'completed' AND substr(timestamp, 1, 10) IN (?, ?)""",
        (business_date_text, next_date_text),
    ).fetchall()
    completed_orders = [
        order
        for order in candidates
        if business_date_for(order["timestamp"]) == business_date
    ]

    sales = sum(float(order["total_amount"]) for order in completed_orders)
    cogs = sum(
        float(item["unit_cost"]) * float(item["quantity"])
        for order in completed_orders
        for item in json.loads(order["items_json"])
    )
    expenses = db.execute(
        "SELECT COALESCE(SUM(amount), 0) AS value FROM expenses WHERE date = ?",
        (business_date_text,),
    ).fetchone()["value"]
    most_recent = max(
        completed_orders,
        key=lambda order: local_datetime_for_report(order["timestamp"]),
        default=None,
    )
    return {
        "business_date": business_date_text,
        "today_sales": round(sales, 2),
        "today_profit": round(sales - cogs - float(expenses or 0), 2),
        "today_orders_count": len(completed_orders),
        "last_sale": (
            {
                "id": most_recent["id"],
                "timestamp": most_recent["timestamp"],
                "total_amount": round(float(most_recent["total_amount"]), 2),
            }
            if most_recent
            else None
        ),
    }


def project_summary_rows(db):
    ensure_business_day(db)
    rows = db.execute(
        "SELECT * FROM business_days ORDER BY project_date DESC"
    ).fetchall()
    sealed_days = {
        row["period_key"]: row
        for row in db.execute(
            """SELECT period_key, status, expected_cash, counted_cash, closing_variance,
                      closed_at, closed_by, auto_generated
               FROM closing_reports WHERE period_type = 'day'"""
        )
    }
    today = date.today().isoformat()
    result = []
    for row in rows:
        day = dict(row)
        day_id = row["id"]
        sales = db.execute(
            "SELECT COALESCE(SUM(total_amount), 0) AS value FROM orders WHERE substr(timestamp, 1, 10) = ? AND status = 'completed'",
            (row["project_date"],),
        ).fetchone()["value"]
        expenses = db.execute(
            "SELECT COALESCE(SUM(amount), 0) AS value FROM expenses WHERE date = ?",
            (row["project_date"],),
        ).fetchone()["value"]
        cash_balance = round(float(business_day_cash(db, day_id)), 2)
        day["sales"] = round(float(sales or 0), 2)
        day["expenses"] = round(float(expenses or 0), 2)
        day["cash_balance"] = cash_balance
        day["closing_variance"] = round(float(row["closing_variance"] or 0), 2)
        closing = sealed_days.get(row["project_date"])
        # A sealed day is a standalone project: the reports screen lists it with
        # its stored snapshot instead of rebuilding the numbers from live rows.
        day["closing"] = dict(closing) if closing is not None else None
        day["closed"] = row["status"] == "closed" or closing is not None
        day["is_today"] = row["project_date"] == today
        result.append(day)
    return result


@app.get("/api/projects")
@cashier_session_required
def list_projects():
    return jsonify(project_summary_rows(get_db()))


@app.get("/api/admin/projects")
@admin_required
def list_admin_projects():
    return jsonify(project_summary_rows(get_db()))


def report_period_key():
    period = str(request.args.get("period", "day")).strip().lower()
    if period not in ("day", "month"):
        raise ValueError("اختر تقرير اليوم أو تقرير الشهر.")
    if period == "month":
        key = str(request.args.get("month") or date.today().strftime("%Y-%m")).strip()
        datetime.strptime(key, "%Y-%m")
        return period, key
    key = str(request.args.get("date") or date.today().isoformat()).strip()
    datetime.strptime(key, "%Y-%m-%d")
    return period, key


def order_filter_sql(period):
    column = "substr(timestamp, 1, 7)" if period == "month" else "substr(timestamp, 1, 10)"
    return column + " = ?"


def expense_filter_sql(period):
    column = "substr(date, 1, 7)" if period == "month" else "date"
    return column + " = ?"


def build_project_report(db, period, key):
    order_where = order_filter_sql(period)
    expense_where = expense_filter_sql(period)
    orders = db.execute(
        """SELECT o.id, o.timestamp, o.total_amount, o.items_json, o.status, o.cancel_reason,
                  o.cancelled_at, o.shift_id, o.employee_id,
                  e.username AS employee_name, s.started_at AS shift_started_at
           FROM orders o
           LEFT JOIN employees e ON e.id = o.employee_id
           LEFT JOIN shifts s ON s.id = o.shift_id
           WHERE """ + order_where + """
           ORDER BY o.timestamp, o.id""",
        (key,),
    ).fetchall()
    sales = []
    returns = []
    revenue = 0.0
    returns_total = 0.0
    cogs = 0.0
    completed_orders = 0
    consumption = {}
    shift_sales = {}
    shift_returns = {}
    for order in orders:
        items = json.loads(order["items_json"] or "[]")
        line_items = [
            {
                "name": item.get("name") or "",
                "quantity": item.get("quantity") or 0,
                "unit_price": round(float(item.get("unit_price") or 0), 2),
                "discount_amount": round(float(item.get("discount_amount") or 0), 2),
                "line_total": round(float(item.get("line_total") or 0), 2),
            }
            for item in items if isinstance(item, dict)
        ]
        summary = {
            "order_id": order["id"],
            "timestamp": order["timestamp"],
            "timestamp_display": format_iso_datetime(order["timestamp"]),
            "employee_name": order["employee_name"] or "غير مسجل",
            "shift_started_at": order["shift_started_at"],
            "total_amount": round(float(order["total_amount"] or 0), 2),
            "items": line_items,
            "item_names": "، ".join(entry["name"] for entry in line_items),
        }
        if order["status"] == "completed":
            revenue += float(order["total_amount"] or 0)
            completed_orders += 1
            for item in items:
                if not isinstance(item, dict):
                    continue
                cogs += float(item.get("unit_cost") or 0) * float(item.get("quantity") or 0)
                if item.get("kind") == "drink":
                    for used in item.get("materials_used") or []:
                        if not isinstance(used, dict) or used.get("material_id") is None:
                            continue
                        material_id = int(used["material_id"])
                        consumption[material_id] = consumption.get(material_id, 0) + float(used.get("total_qty") or 0)
            sales.append(summary)
            shift_sales.setdefault(order["shift_id"], []).append(summary)
        else:
            returns_total += float(order["total_amount"] or 0)
            summary["reason"] = order["cancel_reason"] or ""
            summary["cancelled_at"] = order["cancelled_at"]
            summary["cancelled_display"] = format_iso_datetime(order["cancelled_at"])
            returns.append(summary)
            shift_returns.setdefault(order["shift_id"], []).append(summary)
    expenses_rows = db.execute(
        "SELECT id, date, category, amount, note FROM expenses WHERE " + expense_where + " ORDER BY id",
        (key,),
    ).fetchall()
    expenses_total = sum(float(row["amount"] or 0) for row in expenses_rows)
    purchase_where = "substr(timestamp, 1, 7) = ?" if period == "month" else "substr(timestamp, 1, 10) = ?"
    purchase_rows = db.execute(
        "SELECT id, timestamp, supplier, category, amount, note FROM purchases WHERE " + purchase_where + " ORDER BY timestamp, id",
        (key,),
    ).fetchall()
    purchases_total = sum(float(row["amount"] or 0) for row in purchase_rows)
    consumption_rows = []
    for material_id in sorted(consumption):
        quantity = consumption[material_id]
        material = db.execute(
            "SELECT name, unit, cost_per_unit FROM materials WHERE id = ?", (material_id,)
        ).fetchone()
        consumption_rows.append({
            "material_id": material_id,
            "name": material["name"] if material else "مادة #" + str(material_id),
            "unit": material["unit"] if material else "",
            "quantity": round(quantity, 4),
            "cost": round(quantity * float(material["cost_per_unit"]), 2) if material else 0.0,
        })
    consumption_cost = round(sum(entry["cost"] for entry in consumption_rows), 2)
    shifts = db.execute(
        """SELECT s.id, e.username, s.started_at, s.ended_at, s.status, s.opening_cash,
                  s.expected_cash, s.worked_seconds, s.payable_amount, s.closure_reason
           FROM shifts s
           JOIN employees e ON e.id = s.employee_id
           JOIN business_days b ON b.id = s.business_day_id
           WHERE """ + ("substr(b.project_date, 1, 7) = ?" if period == "month" else "b.project_date = ?") + """
           ORDER BY s.started_at""",
        (key,),
    ).fetchall()
    notes_sql = "substr(project_date, 1, 7) = ?" if period == "month" else "project_date = ?"
    notes = db.execute(
        "SELECT * FROM project_log_notes WHERE " + notes_sql + " ORDER BY event_time, id",
        (key,),
    ).fetchall()
    log = []
    for shift in shifts:
        log.append({
            "source": "shift",
            "editable": False,
            "event_time": shift["started_at"],
            "title": "تسجيل حضور: " + shift["username"],
            "details": "بداية الوردية · رصيد النظام " + str(round(float(shift["opening_cash"] or 0), 2)),
        })
        if shift["ended_at"]:
            reason = "تسليم لموظف آخر" if shift["closure_reason"] == "handover" else "إنهاء الوردية"
            log.append({
                "source": "shift",
                "editable": False,
                "event_time": shift["ended_at"],
                "title": reason + ": " + shift["username"],
                "details": "المستحق " + str(round(float(shift["payable_amount"] or 0), 2)),
            })
    for order in orders:
        names = "، ".join(str(item.get("name") or "") for item in json.loads(order["items_json"] or "[]"))
        if order["status"] == "cancelled":
            log.append({
                "source": "sale",
                "editable": False,
                "event_time": order["timestamp"],
                "title": "استرجاع عملية بيع #" + str(order["id"]),
                "details": (order["employee_name"] or "غير مسجل") + " · " + names + " · " + (order["cancel_reason"] or ""),
            })
        else:
            log.append({
                "source": "sale",
                "editable": False,
                "event_time": order["timestamp"],
                "title": "بيع #" + str(order["id"]) + " بواسطة " + (order["employee_name"] or "غير مسجل"),
                "details": names + " · الإجمالي " + str(round(float(order["total_amount"] or 0), 2)),
            })
    for row in expenses_rows:
        log.append({
            "source": "expense",
            "editable": False,
            "event_time": row["date"] + "T00:00:00",
            "title": "مصروف: " + row["category"],
            "details": str(round(float(row["amount"] or 0), 2)) + " · " + (row["note"] or ""),
        })
    for row in purchase_rows:
        log.append({
            "source": "purchase",
            "editable": False,
            "event_time": row["timestamp"],
            "title": "مشتريات: " + (row["supplier"] or row["category"] or "توريد"),
            "details": str(round(float(row["amount"] or 0), 2)) + " · " + (row["note"] or ""),
        })
    for row in consumption_rows:
        log.append({
            "source": "consumption",
            "editable": False,
            "event_time": key + ("-01T00:00:00" if period == "month" else "T00:00:00"),
            "title": "استهلاك: " + row["name"],
            "details": str(row["quantity"]) + " " + (row["unit"] or "") + " · التكلفة " + str(row["cost"]),
        })
    for note in notes:
        item = dict(note)
        item["source"] = "note"
        item["editable"] = True
        log.append(item)
    log.sort(key=lambda item: str(item.get("event_time") or ""))
    for entry in log:
        entry["event_time_display"] = format_iso_datetime(entry.get("event_time"))
    shift_breakdown = []
    seen_shifts = set()
    for shift in shifts:
        breakdown = dict(shift)
        breakdown["sales"] = shift_sales.get(shift["id"], [])
        breakdown["returns"] = shift_returns.get(shift["id"], [])
        breakdown["sales_total"] = round(sum(item["total_amount"] for item in breakdown["sales"]), 2)
        breakdown["returns_total"] = round(sum(item["total_amount"] for item in breakdown["returns"]), 2)
        breakdown["orders_count"] = len(breakdown["sales"])
        breakdown["returns_count"] = len(breakdown["returns"])
        breakdown["started_display"] = format_iso_datetime(shift["started_at"])
        breakdown["ended_display"] = format_iso_datetime(shift["ended_at"])
        shift_breakdown.append(breakdown)
        seen_shifts.add(shift["id"])
    unassigned_sales = [item for key_id, values in shift_sales.items() if key_id not in seen_shifts for item in values]
    unassigned_returns = [item for key_id, values in shift_returns.items() if key_id not in seen_shifts for item in values]
    if unassigned_sales or unassigned_returns:
        shift_breakdown.append({
            "id": None,
            "username": "بدون وردية مسجلة",
            "started_at": None,
            "ended_at": None,
            "status": "",
            "opening_cash": None,
            "expected_cash": None,
            "worked_seconds": 0,
            "payable_amount": 0,
            "closure_reason": "",
            "sales": unassigned_sales,
            "returns": unassigned_returns,
            "sales_total": round(sum(item["total_amount"] for item in unassigned_sales), 2),
            "returns_total": round(sum(item["total_amount"] for item in unassigned_returns), 2),
            "orders_count": len(unassigned_sales),
            "returns_count": len(unassigned_returns),
        })
    days = project_summary_rows(db)
    if period == "day":
        days = [row for row in days if row["project_date"] == key]
    else:
        days = [row for row in days if str(row["project_date"]).startswith(key)]
    return {
        "period": period,
        "key": key,
        "revenue": round(revenue, 2),
        "cogs": round(cogs, 2),
        "expenses": round(expenses_total, 2),
        "purchases_total": round(purchases_total, 2),
        "returns_total": round(returns_total, 2),
        "consumption_cost": consumption_cost,
        "profit": round(revenue - cogs - expenses_total, 2),
        "orders": completed_orders,
        "days": days,
        "sales": sales,
        "returns": returns,
        "purchases": [dict(row) for row in purchase_rows],
        "consumption_rows": consumption_rows,
        "expense_rows": [dict(row) for row in expenses_rows],
        "shifts": [dict(row) for row in shifts],
        "shift_breakdown": shift_breakdown,
        "notes": [dict(row) for row in notes],
        "log": log,
    }


# --- DAY & MONTH CLOSING ---------------------------------------------------
# A closing freezes a period: its report is stored verbatim in closing_reports,
# every shift still open on it is ended, and the business day is locked so the
# next day starts from the cash that was actually counted.
CLOSING_PERIOD_LABELS = {"day": "اليوم", "month": "الشهر"}
# Snapshots are kept whole; only an unusually busy month loses its event log.
CLOSING_PAYLOAD_LIMIT = 400000


def closing_snapshot(report):
    """Frozen copy of a period report, trimmed only when it grows too large."""
    payload = dict(report)
    if len(json.dumps(payload, ensure_ascii=False)) > CLOSING_PAYLOAD_LIMIT:
        payload.pop("log", None)
        payload["log_omitted"] = True
    return payload


def closing_record(db, period, key):
    """Metadata of a stored closing without the (possibly large) snapshot."""
    row = db.execute(
        "SELECT * FROM closing_reports WHERE period_type = ? AND period_key = ?",
        (period, key),
    ).fetchone()
    if row is None:
        return None
    return {
        "id": row["id"],
        "period_type": row["period_type"],
        "period_key": row["period_key"],
        "status": row["status"],
        "expected_cash": round(float(row["expected_cash"] or 0), 2),
        "counted_cash": None if row["counted_cash"] is None else round(float(row["counted_cash"]), 2),
        "closing_variance": round(float(row["closing_variance"] or 0), 2),
        "closed_at": row["closed_at"],
        "closed_at_display": format_iso_datetime(row["closed_at"]),
        "closed_by": row["closed_by"],
        "auto_generated": bool(row["auto_generated"]),
    }


def sealed_report(db, period, key):
    """The stored report for a closed period, or None while it stays open."""
    row = db.execute(
        "SELECT * FROM closing_reports WHERE period_type = ? AND period_key = ?",
        (period, key),
    ).fetchone()
    if row is None:
        return None
    try:
        payload = json.loads(row["payload_json"] or "{}")
    except (TypeError, json.JSONDecodeError):
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    payload.update(closing_record(db, period, key) or {})
    payload["sealed"] = True
    payload.setdefault("period", period)
    payload.setdefault("key", key)
    return payload


def closing_summary(db, period, key):
    """Headline numbers for the closing dialog, before anything is stored."""
    sales = returns = 0.0
    orders_count = returns_count = 0
    for row in db.execute(
        "SELECT status, COALESCE(SUM(total_amount), 0) AS value, COUNT(*) AS count FROM orders WHERE "
        + order_filter_sql(period) + " GROUP BY status",
        (key,),
    ):
        if row["status"] == "completed":
            sales, orders_count = float(row["value"]), row["count"]
        else:
            returns, returns_count = float(row["value"]), row["count"]
    expense_row = db.execute(
        "SELECT COALESCE(SUM(amount), 0) AS value, COUNT(*) AS count FROM expenses WHERE "
        + expense_filter_sql(period),
        (key,),
    ).fetchone()
    purchase_column = "substr(timestamp, 1, 7)" if period == "month" else "substr(timestamp, 1, 10)"
    purchase_row = db.execute(
        "SELECT COALESCE(SUM(amount), 0) AS value, COUNT(*) AS count FROM purchases WHERE "
        + purchase_column + " = ?",
        (key,),
    ).fetchone()
    day_column = "substr(project_date, 1, 7) = ?" if period == "month" else "project_date = ?"
    days = db.execute(
        "SELECT * FROM business_days WHERE " + day_column + " ORDER BY project_date",
        (key,),
    ).fetchall()
    drawer = round(float(business_day_cash(db, days[-1]["id"])), 2) if days else 0.0
    return {
        "period": period,
        "key": key,
        "sales": round(sales, 2),
        "orders_count": orders_count,
        "returns": round(returns, 2),
        "returns_count": returns_count,
        "expenses": round(float(expense_row["value"] or 0), 2),
        "expenses_count": expense_row["count"],
        "purchases": round(float(purchase_row["value"] or 0), 2),
        "purchases_count": purchase_row["count"],
        "days_count": len(days),
        "drawer_balance": drawer,
        "day_status": "closed" if days and days[-1]["status"] == "closed" else "open",
    }


def close_period(db, period, key, counted_cash=None, note="", actor_name="", auto_generated=False):
    """Seal a day or a month and hand the counted drawer to the next period."""
    if period not in CLOSING_PERIOD_LABELS:
        raise ValueError("نطاق التقفيل غير صالح.")
    try:
        period_date = datetime.strptime(key, "%Y-%m-%d" if period == "day" else "%Y-%m")
    except (TypeError, ValueError):
        raise ValueError("تاريخ التقفيل غير صالح.")
    if db.execute(
        "SELECT 1 FROM closing_reports WHERE period_type = ? AND period_key = ? LIMIT 1",
        (period, key),
    ).fetchone():
        raise ValueError("تم تقفيل " + CLOSING_PERIOD_LABELS[period] + " " + key + " من قبل.")

    summary = closing_summary(db, period, key)
    # A period that never saw a record has nothing to freeze.
    if not summary["days_count"] and not summary["orders_count"] and not summary["expenses_count"]:
        raise ValueError("لا توجد بيانات " + CLOSING_PERIOD_LABELS[period] + " " + key + " لتقفيلها.")

    day_column = "substr(project_date, 1, 7) = ?" if period == "month" else "project_date = ?"
    day_rows = db.execute(
        "SELECT * FROM business_days WHERE " + day_column + " ORDER BY project_date",
        (key,),
    ).fetchall()
    expected = round(float(summary["drawer_balance"]), 2)
    counted = expected if counted_cash is None else round(float(counted_cash), 2)
    variance = round(counted - expected, 2)
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    closure_reason = "day_close" if period == "day" else "month_close"

    shift_column = "b.project_date = ?" if period == "day" else "substr(b.project_date, 1, 7) = ?"
    open_shifts = db.execute(
        """SELECT s.* FROM shifts s JOIN business_days b ON b.id = s.business_day_id
           WHERE s.status = 'open' AND """ + shift_column + " ORDER BY s.id",
        (key,),
    ).fetchall()
    for shift in open_shifts:
        close_employee_shift(db, shift, reason=closure_reason)

    payload = closing_snapshot(build_project_report(db, period, key))
    payload["closing"] = {
        "expected_cash": expected,
        "counted_cash": counted,
        "closing_variance": variance,
        "closed_at": now,
        "closed_by": actor_name,
        "auto_generated": bool(auto_generated),
        "note": note,
    }
    db.execute(
        """INSERT INTO closing_reports(period_type, period_key, status, payload_json,
               expected_cash, counted_cash, closing_variance, closed_at, closed_by, auto_generated)
           VALUES (?, ?, 'closed', ?, ?, ?, ?, ?, ?, ?)""",
        (
            period, key, json.dumps(payload, ensure_ascii=False), expected, counted,
            variance, now, actor_name, 1 if auto_generated else 0,
        ),
    )
    for index, day in enumerate(day_rows):
        day_expected = round(float(business_day_cash(db, day["id"])), 2)
        # Only the last day of the sealed period carries the counted drawer, so
        # every earlier day keeps a variance of zero against its own balance.
        day_counted = counted if index == len(day_rows) - 1 else day_expected
        db.execute(
            """UPDATE business_days SET status = 'closed', closed_at = ?, expected_cash = ?,
                      counted_cash = ?, closing_variance = ? WHERE id = ?""",
            (
                now, day_expected, day_counted,
                round(day_counted - day_expected, 2), day["id"],
            ),
        )
    next_day = (period_date.date() + timedelta(days=1)).isoformat()
    if period == "day" and key >= date.today().isoformat():
        if db.execute(
            "SELECT 1 FROM business_days WHERE project_date = ? LIMIT 1", (next_day,)
        ).fetchone() is None:
            # This is the reset the button promises: an empty new day whose
            # opening cash is whatever was just counted in the drawer.
            ensure_business_day(db, period_date.date() + timedelta(days=1))
    else:
        next_day = None
    db.commit()
    return {
        "period": period,
        "key": key,
        "status": "closed",
        "expected_cash": expected,
        "counted_cash": counted,
        "closing_variance": variance,
        "closed_at": now,
        "closed_at_display": format_iso_datetime(now),
        "closed_by": actor_name,
        "auto_generated": bool(auto_generated),
        "shifts_closed": [shift["id"] for shift in open_shifts],
        "days_closed": [day["project_date"] for day in day_rows],
        "next_day": next_day,
        "summary": summary,
    }


def reopen_period(db, period, key, actor_name=""):
    """Undo a closing: drop the snapshot and unlock the period's business days."""
    if period not in CLOSING_PERIOD_LABELS:
        raise ValueError("نطاق التقفيل غير صالح.")
    if closing_record(db, period, key) is None:
        raise ValueError(CLOSING_PERIOD_LABELS[period] + " " + key + " غير مقفل.")
    db.execute(
        "DELETE FROM closing_reports WHERE period_type = ? AND period_key = ?",
        (period, key),
    )
    day_column = "substr(project_date, 1, 7) = ?" if period == "month" else "project_date = ?"
    rows = db.execute(
        "SELECT id FROM business_days WHERE " + day_column, (key,)
    ).fetchall()
    for row in rows:
        db.execute(
            """UPDATE business_days SET status = 'open', closed_at = NULL, expected_cash = NULL,
                      counted_cash = NULL, closing_variance = NULL WHERE id = ?""",
            (row["id"],),
        )
    db.commit()
    app.logger.info("Closed period %s %s reopened by %s", period, key, actor_name or "unknown")
    return {"period": period, "key": key, "status": "open", "days_reopened": len(rows)}


def months_awaiting_auto_close(db, current_month=None):
    """Finished months that hold data but have never been sealed."""
    current_month = current_month or date.today().strftime("%Y-%m")
    periods = set()
    for statement in (
        "SELECT DISTINCT substr(timestamp, 1, 7) AS key FROM orders",
        "SELECT DISTINCT substr(date, 1, 7) AS key FROM expenses",
        "SELECT DISTINCT substr(timestamp, 1, 7) AS key FROM purchases",
        "SELECT DISTINCT substr(project_date, 1, 7) AS key FROM business_days",
    ):
        for row in db.execute(statement):
            if row["key"]:
                periods.add(str(row["key"]))
    sealed = {
        row["period_key"]
        for row in db.execute("SELECT period_key FROM closing_reports WHERE period_type = 'month'")
    }
    return sorted(period for period in periods if period < current_month and period not in sealed)


def auto_close_finished_months(db, actor_name="النظام"):
    """On the first of a new month the previous ones close as a shift opens."""
    closed = []
    for month_key in months_awaiting_auto_close(db):
        try:
            closed.append(close_period(
                db, "month", month_key,
                actor_name=actor_name, auto_generated=True,
            ))
        except ValueError:
            # An empty month, or one already sealed, is simply skipped.
            continue
        except Exception:
            db.rollback()
            app.logger.exception("Unexpected error auto-closing month %s", month_key)
    return closed


def day_close_manager_required(function):
    """Closing the day lives beside the expenses screen, so expense rights allow it."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get("admin_id"):
            return function(*args, **kwargs)
        employee_id = session.get("employee_id")
        if not employee_id:
            return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
        employee = get_db().execute(
            "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
        ).fetchone()
        if employee is None:
            session.clear()
            return api_error("حساب الموظف غير نشط.", 403)
        if not employee["can_manage_expenses"]:
            return api_error("لا تملك صلاحية تقفيل اليوم.", 403)
        return function(*args, **kwargs)

    return wrapped


def parse_counted_cash(value):
    if value is None or str(value).strip() == "":
        return None
    try:
        counted = float(value)
    except (TypeError, ValueError):
        raise ValueError("رصيد الدرج المعدود يجب أن يكون رقمًا.")
    if not math.isfinite(counted) or counted < 0:
        raise ValueError("رصيد الدرج المعدود يجب أن يكون صفرًا أو أكثر.")
    return round(counted, 2)


def closing_report_rows(db, limit=120):
    rows = db.execute(
        """SELECT period_type, period_key, status, expected_cash, counted_cash, closing_variance,
                  closed_at, closed_by, auto_generated
           FROM closing_reports ORDER BY period_key DESC, period_type LIMIT ?""",
        (int(limit),),
    ).fetchall()
    reports = []
    for row in rows:
        entry = dict(row)
        entry["closed_at_display"] = format_iso_datetime(row["closed_at"])
        entry["auto_generated"] = bool(row["auto_generated"])
        reports.append(entry)
    return reports


@app.get("/api/closing/state")
@day_close_manager_required
def closing_state():
    """Everything the closing dialog needs: today, the month and past closings."""
    db = get_db()
    today = date.today()
    day_key = today.isoformat()
    month_key = today.strftime("%Y-%m")
    business_day = db.execute(
        "SELECT * FROM business_days WHERE project_date = ?", (day_key,)
    ).fetchone()
    shift = open_shift_context(db)
    shift_payload = None
    if shift is not None:
        person = db.execute(
            "SELECT username FROM employees WHERE id = ?", (shift["employee_id"],)
        ).fetchone()
        shift_payload = {
            "id": shift["id"],
            "username": person["username"] if person else "",
            "started_at": shift["started_at"],
            "business_day_id": shift["business_day_id"],
        }
    return jsonify({
        "today": day_key,
        "month": month_key,
        "business_day": dict(business_day) if business_day else None,
        "day_summary": closing_summary(db, "day", day_key),
        "month_summary": closing_summary(db, "month", month_key),
        "day_closing": closing_record(db, "day", day_key),
        "month_closing": closing_record(db, "month", month_key),
        "open_shift": shift_payload,
        "pending_months": months_awaiting_auto_close(db),
        "reports": closing_report_rows(db),
    })


@app.get("/api/closing/reports")
@dashboard_access_required
def closing_reports_list():
    db = get_db()
    period = str(request.args.get("period") or "").strip().lower()
    if period in CLOSING_PERIOD_LABELS:
        rows = db.execute(
            """SELECT period_type, period_key, status, expected_cash, counted_cash, closing_variance,
                      closed_at, closed_by, auto_generated
               FROM closing_reports WHERE period_type = ?
               ORDER BY period_key DESC LIMIT ?""",
            (period, int(request.args.get("limit") or 120)),
        ).fetchall()
        reports = []
        for row in rows:
            entry = dict(row)
            entry["closed_at_display"] = format_iso_datetime(row["closed_at"])
            entry["auto_generated"] = bool(row["auto_generated"])
            reports.append(entry)
        return jsonify({"period": period, "reports": reports})
    return jsonify({"reports": closing_report_rows(db)})


@app.post("/api/day-close")
@day_close_manager_required
def close_day():
    """The day-close button: freeze today as its own report and reset the day."""
    body = request.get_json(silent=True)
    if body is not None and not isinstance(body, dict):
        return api_error("بيانات التقفيل غير صالحة.")
    body = body or {}
    db = get_db()
    key = str(body.get("date") or date.today().isoformat()).strip()
    try:
        counted = parse_counted_cash(body.get("counted_cash"))
    except ValueError as error:
        return api_error(str(error))
    note = str(body.get("note") or "").strip()[:300]
    _actor_id, actor_name, _role = current_actor_identity(db)
    try:
        result = close_period(
            db, "day", key, counted_cash=counted, note=note, actor_name=actor_name
        )
    except ValueError as error:
        db.rollback()
        return api_error(str(error), 409)
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error closing the day")
        return api_error("حدث خطأ أثناء تقفيل اليوم.", 500)
    app.logger.info("Day %s closed by %s", key, actor_name or "unknown")
    return jsonify(result)


@app.post("/api/month-close")
@admin_required
def close_month_route():
    """Close one finished month, or catch up on every month still waiting."""
    body = request.get_json(silent=True)
    if body is not None and not isinstance(body, dict):
        return api_error("بيانات التقفيل غير صالحة.")
    body = body or {}
    db = get_db()
    _actor_id, actor_name, _role = current_actor_identity(db)
    month = str(body.get("month") or "").strip()
    if month:
        try:
            return jsonify(close_period(db, "month", month, actor_name=actor_name))
        except ValueError as error:
            db.rollback()
            return api_error(str(error), 409)
        except Exception:
            db.rollback()
            app.logger.exception("Unexpected error closing month %s", month)
            return api_error("حدث خطأ أثناء تقفيل الشهر.", 500)
    try:
        return jsonify({"closed": auto_close_finished_months(db, actor_name)})
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error catching up on month closings")
        return api_error("حدث خطأ أثناء تقفيل الأشهر.", 500)


@app.post("/api/closing/reopen")
@day_close_manager_required
def reopen_closing_route():
    """Unlock a sealed period again; only an admin may reopen a whole month."""
    body = request.get_json(silent=True)
    if body is not None and not isinstance(body, dict):
        return api_error("بيانات إعادة الفتح غير صالحة.")
    body = body or {}
    period = str(body.get("period") or "day").strip().lower()
    key = str(body.get("date") or body.get("month") or "").strip()
    if period not in CLOSING_PERIOD_LABELS:
        return api_error("نطاق التقفيل غير صالح.")
    if period == "month" and not session.get("admin_id"):
        return api_error("إعادة فتح الشهر متاحة للمدير فقط.", 403)
    if not key:
        return api_error("حدد الفترة المطلوب إعادة فتحها.")
    db = get_db()
    _actor_id, actor_name, _role = current_actor_identity(db)
    try:
        return jsonify(reopen_period(db, period, key, actor_name))
    except ValueError as error:
        return api_error(str(error), 409)
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error reopening period %s %s", period, key)
        return api_error("حدث خطأ أثناء إعادة فتح الفترة.", 500)


@app.get("/api/projects/report")
@cashier_session_required
def cashier_project_report():
    try:
        period, key = report_period_key()
    except ValueError:
        return api_error("تاريخ التقرير غير صالح.")
    db = get_db()
    return jsonify(sealed_report(db, period, key) or build_project_report(db, period, key))


@app.get("/api/admin/projects/report")
@admin_required
def admin_project_report():
    try:
        period, key = report_period_key()
    except ValueError:
        return api_error("تاريخ التقرير غير صالح.")
    db = get_db()
    return jsonify(sealed_report(db, period, key) or build_project_report(db, period, key))


@app.post("/api/admin/project-notes")
@admin_required
@open_shift_required
def create_project_note():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    details = str(data.get("details", "")).strip()
    project_date = str(data.get("project_date") or date.today().isoformat()).strip()
    try:
        datetime.strptime(project_date, "%Y-%m-%d")
    except ValueError:
        return api_error("تاريخ السجل يجب أن يكون يومًا صالحًا.")
    if not title:
        return api_error("عنوان الحدث مطلوب.")
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    db = get_db()
    cursor = db.execute(
        """INSERT INTO project_log_notes(project_date, event_time, title, details, created_by, updated_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (project_date, now, title, details, "admin", now),
    )
    db.commit()
    row = db.execute("SELECT * FROM project_log_notes WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.put("/api/admin/project-notes/<int:note_id>")
@admin_required
@open_shift_required
def update_project_note(note_id):
    data = request.get_json(silent=True) or {}
    db = get_db()
    row = db.execute("SELECT * FROM project_log_notes WHERE id = ?", (note_id,)).fetchone()
    if row is None:
        return api_error("السجل غير موجود.", 404)
    title = str(data.get("title", row["title"])).strip() or row["title"]
    details = str(data.get("details", row["details"]))
    project_date = str(data.get("project_date", row["project_date"])).strip()
    try:
        datetime.strptime(project_date, "%Y-%m-%d")
    except ValueError:
        return api_error("تاريخ السجل يجب أن يكون يومًا صالحًا.")
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    db.execute(
        "UPDATE project_log_notes SET project_date = ?, title = ?, details = ?, updated_at = ? WHERE id = ?",
        (project_date, title, details, now, note_id),
    )
    db.commit()
    return jsonify(dict(db.execute("SELECT * FROM project_log_notes WHERE id = ?", (note_id,)).fetchone()))


@app.delete("/api/admin/project-notes/<int:note_id>")
@admin_required
@open_shift_required
def delete_project_note(note_id):
    db = get_db()
    if db.execute("SELECT 1 FROM project_log_notes WHERE id = ?", (note_id,)).fetchone() is None:
        return api_error("السجل غير موجود.", 404)
    db.execute("DELETE FROM project_log_notes WHERE id = ?", (note_id,))
    db.commit()
    return jsonify({"ok": True, "id": note_id})


@app.get("/api/admin/attendance")
@admin_required
def list_admin_attendance():
    db = get_db()
    rows = db.execute(
        """SELECT s.id, s.employee_id, e.username, s.business_day_id,
                  b.project_date, s.started_at, s.status, s.opening_cash,
                  s.worked_seconds, s.payable_amount
           FROM shifts s JOIN employees e ON e.id = s.employee_id
           JOIN business_days b ON b.id = s.business_day_id
           WHERE substr(s.started_at, 1, 10) = ?
           ORDER BY s.started_at DESC""",
        (date.today().isoformat(),),
    ).fetchall()
    return jsonify({
        "shift_hours": configured_shift_seconds(db) / 3600,
        "shifts": [dict(row) for row in rows],
    })


@app.get("/api/search")
@cashier_session_required
def search_system():
    query = str(request.args.get("q", "")).strip().casefold()
    scope = str(request.args.get("scope", "")).strip().lower()
    if not query:
        return jsonify([])

    is_admin = bool(session.get("admin_id"))
    db = get_db()
    employee = None
    if session.get("employee_id"):
        employee = db.execute(
            "SELECT * FROM employees WHERE id = ? AND is_active = 1",
            (session["employee_id"],),
        ).fetchone()
    can_inventory = is_admin or bool(employee and employee["can_manage_inventory"])
    can_expenses = is_admin or bool(employee and employee["can_manage_expenses"])
    can_sell = is_admin or bool(employee and employee["can_sell"])

    if scope == "cashier":
        results = []
        catalog = (
            ("books", "title", "author", "الكتب"),
            ("drinks", "name", None, "المشروبات"),
            ("retail", "name", None, "المنتجات الجاهزة"),
        )
        for table, name_column, detail_column, path in catalog:
            columns = "id, " + name_column
            if detail_column:
                columns += ", " + detail_column
            rows = db.execute("SELECT " + columns + " FROM " + table + " ORDER BY id DESC LIMIT 500").fetchall()
            for row in rows:
                label = str(row[name_column] or "")
                detail = str(row[detail_column] or "") if detail_column else ""
                if query not in (label + " " + detail).casefold():
                    continue
                results.append({
                    "type": "product",
                    "label": label,
                    "path": "نقطة البيع / " + path,
                    "view": "pos",
                    "query": label,
                })
                if len(results) >= 20:
                    return jsonify(results)
        return jsonify(results)

    if scope == "admin":
        admin_pages = []
        if is_admin:
            admin_pages = [
                ("لوحة المعلومات", "الإدارة / لوحة المعلومات", "dashboard", "الرئيسية مؤشرات"),
                ("الكتب", "الإدارة / الكتب", "books", "مخزون كتب"),
                ("المشروبات", "الإدارة / المشروبات", "drinks", "مشروب"),
                ("المواد الخام", "الإدارة / المواد الخام", "materials", "مواد خام مخزون"),
                ("منتجات جاهزة", "الإدارة / منتجات جاهزة", "retail", "منتجات"),
                ("الأقسام والتصنيفات", "الإدارة / الأقسام والتصنيفات", "categories", "تصنيف فئة قسم"),
                ("الموظفون", "الإدارة / الموظفين", "employees", "الموظفين موظف عامل"),
                ("الحضور والورديات", "الإدارة / الحضور والورديات", "attendance", "حضور وردية دوام"),
                ("الرواتب", "الإدارة / الرواتب", "payroll", "راتب أجور"),
                ("تقرير المشاريع", "الإدارة / تقرير المشاريع", "projects", "تقرير أرباح مبيعات يوم شهر سجل"),
                ("الإعدادات", "الإدارة / الإعدادات", "settings", "كلمة مرور متجر"),
            ]
        else:
            if can_inventory:
                admin_pages.extend([
                    ("الكتب", "الإدارة / الكتب", "books", "مخزون كتب"),
                    ("المشروبات", "الإدارة / المشروبات", "drinks", "مشروب"),
                    ("المواد الخام", "الإدارة / المواد الخام", "materials", "مواد خام مخزون"),
                    ("منتجات جاهزة", "الإدارة / منتجات جاهزة", "retail", "منتجات"),
                    ("الأقسام والتصنيفات", "الإدارة / الأقسام والتصنيفات", "categories", "تصنيف فئة قسم"),
                ])
            if can_expenses:
                admin_pages.append(("المصروفات", "الإدارة / المصروفات", "reports", "مصروفات فواتير"))

        results = [
            {"type": "page", "label": label, "path": path, "view": view}
            for label, path, view, keywords in admin_pages
            if query in (label + " " + keywords).casefold()
        ]

        catalog = (
            ("books", "title", "author", "الكتب"),
            ("drinks", "name", None, "المشروبات"),
            ("retail", "name", None, "المنتجات الجاهزة"),
        )
        if can_inventory:
            catalog += (("materials", "name", None, "المواد الخام"),)
        for table, name_column, detail_column, path in catalog:
            columns = "id, " + name_column
            if detail_column:
                columns += ", " + detail_column
            rows = db.execute("SELECT " + columns + " FROM " + table + " ORDER BY id DESC LIMIT 500").fetchall()
            for row in rows:
                label = str(row[name_column] or "")
                detail = str(row[detail_column] or "") if detail_column else ""
                if query not in (label + " " + detail).casefold():
                    continue
                results.append({
                    "type": "product",
                    "label": label,
                    "path": "الإدارة / " + path,
                    "view": table,
                    "query": label,
                })
                if len(results) >= 20:
                    return jsonify(results)

        if can_inventory:
            categories = db.execute(
                "SELECT slug, label_ar FROM categories WHERE label_ar LIKE ? OR slug LIKE ? ORDER BY sort_order LIMIT 10",
                ("%" + query + "%", "%" + query + "%"),
            ).fetchall()
            results.extend({
                "type": "category",
                "label": row["label_ar"],
                "path": "الإدارة / التصنيفات",
                "view": "categories",
            } for row in categories)

        pattern = "%" + query + "%"
        if can_expenses:
            expenses = db.execute(
                "SELECT id, date, category, note FROM expenses WHERE date LIKE ? OR category LIKE ? OR note LIKE ? ORDER BY date DESC, id DESC LIMIT 10",
                (pattern, pattern, pattern),
            ).fetchall()
            results.extend({
                "type": "expense",
                "label": "مصروف " + row["category"] + " · " + row["date"],
                "path": "الإدارة / تقرير المشاريع",
                "view": "reports",
            } for row in expenses)
            purchases = db.execute(
                "SELECT id, timestamp, supplier, category, note FROM purchases WHERE timestamp LIKE ? OR supplier LIKE ? OR category LIKE ? OR note LIKE ? ORDER BY timestamp DESC, id DESC LIMIT 10",
                (pattern, pattern, pattern, pattern),
            ).fetchall()
            results.extend({
                "type": "purchase",
                "label": "مشتريات " + (row["supplier"] or row["category"]) + " · " + row["timestamp"][:10],
                "path": "الإدارة / تقرير المشاريع",
                "view": "reports",
            } for row in purchases)

        if is_admin:
            rows = db.execute(
                "SELECT id, username FROM employees WHERE username LIKE ? ORDER BY username LIMIT 10",
                ("%" + query + "%",),
            ).fetchall()
            results.extend({
                "type": "employee",
                "label": row["username"],
                "path": "الإدارة / الموظفون",
                "view": "employees",
            } for row in rows)

        if can_sell or is_admin:
            if query.isdigit():
                rows = db.execute(
                    "SELECT id, status FROM orders WHERE id = ? LIMIT 5", (int(query),)
                ).fetchall()
                results.extend({
                    "type": "order",
                    "label": "عملية بيع #" + str(row["id"]),
                    "path": "الإدارة / تقرير المشاريع",
                    "view": "projects",
                } for row in rows)

        return jsonify(results[:20])

    pages = [
        ("نقطة البيع", "نقطة البيع", "pos", "بيع منتجات الكاشير"),
        ("تقرير المشاريع", "نقطة البيع / تقرير المشاريع", "projects", "يوم العمل الدرج المبيعات المصروفات تقرير الشهر"),
        ("تسجيل حضور الموظفين", "نقطة البيع / الحضور", "attendance", "موظف وردية حضور تسليم"),
        ("تقرير مبيعات اليوم", "نقطة البيع / تقرير مبيعات اليوم", "sales", "مبيعات فاتورة خصم موظف"),
    ]
    if can_inventory:
        pages.extend([
            ("الكتب", "الإدارة / الكتب", "books", "مخزون كتب"),
            ("المشروبات", "الإدارة / المشروبات", "drinks", "مشروب"),
            ("المواد الخام", "الإدارة / المواد الخام", "materials", "مواد خام مخزون"),
            ("منتجات جاهزة", "الإدارة / منتجات جاهزة", "retail", "منتجات"),
            ("الأقسام والتصنيفات", "الإدارة / الأقسام والتصنيفات", "categories", "تصنيف فئة قسم"),
        ])
    if is_admin:
        pages.extend([
            ("لوحة المعلومات", "الإدارة / لوحة المعلومات", "dashboard", "الرئيسية مؤشرات"),
            ("الموظفون", "الإدارة / الموظفين", "employees", "الموظفين موظف عامل"),
            ("الحضور والورديات", "الإدارة / الحضور والورديات", "attendance", "حضور وردية دوام"),
            ("الرواتب", "الإدارة / الرواتب", "payroll", "راتب أجور"),
            ("تقرير المشاريع", "الإدارة / تقرير المشاريع", "projects", "تقرير أرباح مبيعات يوم شهر سجل"),
            ("الإعدادات", "الإدارة / الإعدادات", "settings", "كلمة مرور متجر"),
        ])

    results = [
        {"type": "page", "label": label, "path": path, "view": view}
        for label, path, view, keywords in pages
        if query in (label + " " + keywords).casefold()
    ]
    catalog = (
        ("books", "title", "author", "الكتب"),
        ("drinks", "name", None, "المشروبات"),
        ("retail", "name", None, "المنتجات الجاهزة"),
    )
    if can_inventory:
        catalog += (("materials", "name", None, "المواد الخام"),)
    for table, name_column, detail_column, path in catalog:
        columns = "id, " + name_column
        if detail_column:
            columns += ", " + detail_column
        rows = db.execute("SELECT " + columns + " FROM " + table + " ORDER BY id DESC LIMIT 500").fetchall()
        for row in rows:
            label = str(row[name_column] or "")
            detail = str(row[detail_column] or "") if detail_column else ""
            if query not in (label + " " + detail).casefold():
                continue
            view = table if can_inventory else "pos"
            results.append({
                "type": "product",
                "label": label,
                "path": ("الإدارة / " if can_inventory else "نقطة البيع / ") + path,
                "view": view if can_inventory else "pos",
                "query": label,
            })
            if len(results) >= 20:
                return jsonify(results)

    if is_admin:
        categories = db.execute(
            "SELECT slug, label_ar FROM categories WHERE label_ar LIKE ? OR slug LIKE ? ORDER BY sort_order LIMIT 10",
            ("%" + query + "%", "%" + query + "%"),
        ).fetchall()
        results.extend({
            "type": "category",
            "label": row["label_ar"],
            "path": "الإدارة / التصنيفات",
            "view": "categories",
        } for row in categories)
        pattern = "%" + query + "%"
        expenses = db.execute(
            "SELECT id, date, category, note FROM expenses WHERE date LIKE ? OR category LIKE ? OR note LIKE ? ORDER BY date DESC, id DESC LIMIT 10",
            (pattern, pattern, pattern),
        ).fetchall()
        results.extend({
            "type": "expense",
            "label": "مصروف " + row["category"] + " · " + row["date"],
            "path": "الإدارة / تقرير المشاريع",
            "view": "reports",
        } for row in expenses)
        purchases = db.execute(
            "SELECT id, timestamp, supplier, category, note FROM purchases WHERE timestamp LIKE ? OR supplier LIKE ? OR category LIKE ? OR note LIKE ? ORDER BY timestamp DESC, id DESC LIMIT 10",
            (pattern, pattern, pattern, pattern),
        ).fetchall()
        results.extend({
            "type": "purchase",
            "label": "مشتريات " + (row["supplier"] or row["category"]) + " · " + row["timestamp"][:10],
            "path": "الإدارة / تقرير المشاريع",
            "view": "reports",
        } for row in purchases)
        rows = db.execute(
            "SELECT id, username FROM employees WHERE username LIKE ? ORDER BY username LIMIT 10",
            ("%" + query + "%",),
        ).fetchall()
        results.extend({
            "type": "employee",
            "label": row["username"],
            "path": "الإدارة / الموظفون",
            "view": "employees",
        } for row in rows)
        if query.isdigit():
            rows = db.execute(
                "SELECT id, status FROM orders WHERE id = ? LIMIT 5", (int(query),)
            ).fetchall()
            results.extend({
                "type": "order",
                "label": "عملية بيع #" + str(row["id"]),
                "path": "الإدارة / تقرير المشاريع",
                "view": "projects",
            } for row in rows)
    return jsonify(results[:20])


def monthly_payroll_entries(db, month):
    rows = db.execute(
        "SELECT s.employee_id, e.username, e.monthly_salary, SUM(s.worked_seconds) AS worked_seconds, COUNT(*) AS completed_shifts, SUM(s.payable_amount) AS amount FROM shifts s JOIN employees e ON e.id = s.employee_id WHERE s.status = 'closed' AND substr(s.started_at, 1, 7) = ? GROUP BY s.employee_id, e.username, e.monthly_salary ORDER BY s.employee_id",
        (month,),
    ).fetchall()
    entries = []
    for row in rows:
        entries.append({
            "employee_id": row["employee_id"],
            "username": row["username"],
            "monthly_salary": round(float(row["monthly_salary"] or 0), 2),
            "worked_seconds": int(row["worked_seconds"] or 0),
            "completed_shifts": int(row["completed_shifts"] or 0),
            "amount": round(float(row["amount"] or 0), 2),
        })
    return entries


@app.get("/api/admin/payroll")
@admin_required
def admin_payroll_summary():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    db = get_db()
    entries = monthly_payroll_entries(db, month)
    total = round(sum(item["amount"] for item in entries), 2)
    return jsonify({"month": month, "entries": entries, "total": total})


@app.post("/api/admin/payroll/settle")
@admin_required
@open_shift_required
def admin_payroll_settle():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    db = get_db()
    entries = monthly_payroll_entries(db, month)
    for item in entries:
        db.execute(
            "INSERT INTO payroll_settlements (employee_id, month, monthly_salary, worked_seconds, scheduled_seconds, completed_shifts, amount, paid_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(employee_id, month) DO UPDATE SET monthly_salary = excluded.monthly_salary, worked_seconds = excluded.worked_seconds, scheduled_seconds = excluded.scheduled_seconds, completed_shifts = excluded.completed_shifts, amount = excluded.amount, paid_at = excluded.paid_at",
            (
                item["employee_id"],
                month,
                item["monthly_salary"],
                item["worked_seconds"],
                configured_shift_seconds(db),
                item["completed_shifts"],
                item["amount"],
                datetime.now().astimezone().isoformat(timespec="seconds"),
            ),
        )
    db.commit()
    return jsonify({"ok": True, "month": month, "entries": entries})


# --- API Endpoints ---

@app.get("/api/products")
def product_list():
    """Unified endpoint for Cashier Grid - Includes Type & Category"""
    query = request.args.get("q", "").strip().lower()
    db = get_db()
    category_labels = {
        row["slug"]: row["label_ar"]
        for row in db.execute("SELECT slug, label_ar FROM categories")
    }
    
    # Fetch Books - Include 'type'
    books_sql = "SELECT id, title AS name, author, publisher, sell_price, stock_quantity AS stock, 'book' AS kind, type FROM books"
    
    # Fetch Drinks - Include 'category'
    drinks_sql = "SELECT id, name, sell_price, recipe_json, NULL AS stock, 'drink' AS kind, category FROM drinks"
    retail_sql = (
        "SELECT id, name, sell_price, stock_quantity AS stock, cost_price, unit, "
        "'retail' AS kind, category FROM retail"
    )
    
    params_books = ()
    params_drinks = ()
    
    if query:
        # Search by Name, Author, Type (Books) or Name, Category (Drinks)
        books_sql += " WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ? OR LOWER(type) LIKE ?"
        drinks_sql += " WHERE LOWER(name) LIKE ? OR LOWER(category) LIKE ?"
        retail_sql += " WHERE LOWER(name) LIKE ? OR LOWER(category) LIKE ?"
        
        like_q = f"%{query}%"
        params_books = (like_q, like_q, like_q)
        params_drinks = (like_q, like_q)
        params_retail = (like_q, like_q)
    else:
        params_retail = ()
        
    books_sql += " ORDER BY title LIMIT 100"
    drinks_sql += " ORDER BY name LIMIT 100"
    retail_sql += " ORDER BY name LIMIT 100"

    books = [dict(r) for r in db.execute(books_sql, params_books)]
    for book in books:
        book["max_sellable_qty"] = max(0, int(book["stock"] or 0))

    material_rows = db.execute(
        "SELECT id, name, current_stock FROM materials"
    ).fetchall()
    materials = {row["id"]: dict(row) for row in material_rows}
    drinks = []
    for row in db.execute(drinks_sql, params_drinks):
        drink = dict(row)
        if str(drink.get("category", "")).strip().lower() == "cold":
            drink["category"] = "iced"
        drink["category_label"] = category_labels.get(
            drink["category"], drink["category"]
        )
        recipe_is_valid = True
        try:
            raw_recipe = json.loads(drink.pop("recipe_json"))
        except (TypeError, json.JSONDecodeError):
            raw_recipe = []
            recipe_is_valid = False
        if not isinstance(raw_recipe, list):
            raw_recipe = []
            recipe_is_valid = False

        recipe_by_material = {}
        for ingredient in raw_recipe:
            if not isinstance(ingredient, dict):
                recipe_is_valid = False
                continue
            try:
                material_id = int(ingredient["material_id"])
                amount = positive_number(ingredient["qty"], "Recipe quantity", False)
            except (KeyError, TypeError, ValueError):
                recipe_is_valid = False
                continue
            material = materials.get(material_id)
            if material is None:
                recipe_is_valid = False
                continue
            if material_id in recipe_by_material:
                recipe_by_material[material_id]["qty"] += amount
            else:
                recipe_by_material[material_id] = {
                    "material_id": material_id,
                    "qty": amount,
                    "current_stock": material["current_stock"],
                    "material_name": material["name"],
                }

        recipe = list(recipe_by_material.values())
        drink["recipe"] = recipe
        if not recipe_is_valid:
            drink["max_sellable_qty"] = 0
        elif not recipe:
            # A recipe-free drink has no material-based inventory cap.
            drink["max_sellable_qty"] = None
        else:
            drink["max_sellable_qty"] = min(
                int(math.floor(item["current_stock"] / item["qty"] + 0.000000001))
                for item in recipe
            )
        drinks.append(drink)

    retail_products = []
    for row in db.execute(retail_sql, params_retail):
        product = dict(row)
        product["max_sellable_qty"] = max(0, int(product["stock"] or 0))
        product["category_label"] = category_labels.get(
            product["category"], product["category"]
        )
        retail_products.append(product)
    
    # Combine and sort alphabetically by name
    all_products = books + drinks + retail_products
    all_products.sort(key=lambda x: x['name'].lower())
    
    return jsonify(all_products)


@app.post("/api/orders")
@selling_required
@open_shift_required
def create_order():
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return api_error("بيانات الطلب غير صالحة.")
    items = body.get("items")
    if not isinstance(items, list) or not items:
        return api_error("السلة فارغة.")
    if len(items) > 100:
        return api_error("عدد المنتجات في الطلب أكبر من المسموح.")
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        snapshots = []
        material_use = {}
        total = 0.0
        for entry in items:
            if not isinstance(entry, dict):
                raise ValueError("أحد عناصر السلة غير صالح.")
            kind = entry.get("kind")
            try:
                product_id = int(entry.get("id"))
                quantity = int(entry.get("quantity"))
            except (TypeError, ValueError):
                raise ValueError("المنتج أو الكمية غير صالحين.")
            if quantity < 1 or quantity > 10000:
                raise ValueError("يجب أن تكون الكمية بين 1 و10,000.")
            discount_percent = positive_number(
                entry.get("discount_percent", 0), "نسبة الخصم", True
            )
            if discount_percent > 100:
                raise ValueError("نسبة الخصم يجب أن تكون بين 0 و100٪.")
            
            if kind == "book":
                product = db.execute(
                    "SELECT id, title, cost_price, sell_price, stock_quantity FROM books WHERE id = ?",
                    (product_id,),
                ).fetchone()
                if product is None:
                    raise ValueError("أحد الكتب في السلة لم يعد موجودًا.")
                if product["stock_quantity"] < quantity:
                    raise ValueError("المخزون غير كافٍ من الكتاب: " + product["title"] + ".")
                db.execute(
                    "UPDATE books SET stock_quantity = stock_quantity - ? WHERE id = ?",
                    (quantity, product_id),
                )
                name, price = product["title"], product["sell_price"]
                unit_cost = product["cost_price"]
            elif kind == "retail":
                product = db.execute(
                    """SELECT id, name, cost_price, sell_price, stock_quantity, unit
                       FROM retail WHERE id = ?""",
                    (product_id,),
                ).fetchone()
                if product is None:
                    raise ValueError("أحد المنتجات الجاهزة في السلة لم يعد موجودًا.")
                if product["stock_quantity"] < quantity:
                    raise ValueError("المخزون غير كافٍ من المنتج: " + product["name"] + ".")
                db.execute(
                    "UPDATE retail SET stock_quantity = stock_quantity - ? WHERE id = ?",
                    (quantity, product_id),
                )
                name, price = product["name"], product["sell_price"]
                unit_cost = product["cost_price"]
            elif kind == "drink":
                product = db.execute("SELECT * FROM drinks WHERE id = ?", (product_id,)).fetchone()
                if product is None:
                    raise ValueError("أحد المشروبات في السلة لم يعد موجودًا.")
                try:
                    recipe = json.loads(product["recipe_json"])
                except json.JSONDecodeError:
                    raise ValueError("وصفة المشروب " + product["name"] + " غير صالحة.")
                if not isinstance(recipe, list):
                    raise ValueError("وصفة المشروب " + product["name"] + " غير صالحة.")
                unit_cost = product_recipe_cost(db, recipe)
                line_materials = {}
                for ingredient in recipe:
                    try:
                        material_id = int(ingredient["material_id"])
                        amount = positive_number(ingredient["qty"], "Recipe quantity", False)
                    except (KeyError, TypeError, ValueError) as error:
                        raise ValueError("وصفة المشروب " + product["name"] + " غير صالحة: " + str(error))
                    material_use[material_id] = material_use.get(material_id, 0) + amount * quantity
                    line_materials[material_id] = line_materials.get(material_id, 0) + amount * quantity
                name, price = product["name"], product["sell_price"]
            else:
                raise ValueError("نوع المنتج غير معروف.")
            
            gross_total = round(price * quantity, 2)
            discount_amount = round(gross_total * discount_percent / 100, 2)
            line_total = round(gross_total - discount_amount, 2)
            total += line_total
            snapshot = {
                "id": product_id,
                "kind": kind,
                "name": name,
                "quantity": quantity,
                "unit_price": price,
                "unit_cost": unit_cost,
                "gross_total": gross_total,
                "discount_percent": round(discount_percent, 2),
                "discount_amount": discount_amount,
                "line_total": line_total,
            }
            if kind == "drink":
                snapshot["materials_used"] = [
                    {"material_id": material_id, "total_qty": amount}
                    for material_id, amount in line_materials.items()
                ]
            snapshots.append(snapshot)
        
        # Deduct Materials Stock
        for material_id, amount in material_use.items():
            material = db.execute(
                "SELECT name, current_stock FROM materials WHERE id = ?", (material_id,)
            ).fetchone()
            if material is None:
                raise ValueError("تشير وصفة أحد المشروبات إلى مادة غير موجودة.")
            if material["current_stock"] + 1e-9 < amount:
                raise ValueError("المخزون غير كافٍ من المادة: " + material["name"] + ".")
            db.execute(
                "UPDATE materials SET current_stock = MAX(0, current_stock - ?) WHERE id = ?",
                (amount, material_id),
            )
            
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        # The receipt prints tender details when the cashier captured them; both
        # stay optional so an untouched sale still records cleanly.
        payment_method = str(body.get("payment_method", "")).strip()
        if payment_method and payment_method not in PAYMENT_METHODS:
            raise ValueError("طريقة الدفع غير معروفة.")
        if not payment_method:
            payment_method = PAYMENT_METHODS[0]
        paid_amount = None
        if body.get("paid_amount") not in (None, ""):
            paid_amount = round(positive_number(body.get("paid_amount"), "المبلغ المدفوع"), 2)
            if paid_amount + 0.009 < round(total, 2):
                raise ValueError("المبلغ المدفوع أقل من إجمالي الفاتورة.")
        shop_settings = dict(db.execute(
            "SELECT key, value FROM settings WHERE key IN ('shop_name', 'shop_address')"
        ))

        # Every sale is attributed to the employee holding the open shift, so
        # receipts and reports always carry a real operator name. The gate
        # decorator guarantees a shift exists (or the system has no employees).
        shift = open_shift_context(db)
        if shift is None:
            raise ValueError("لا يمكن تسجيل البيع بدون موظف فاتح وردية.")
        employee_id = shift["employee_id"]
        shift_id = shift["id"]
        business_day_id = shift["business_day_id"]

        cursor = db.execute(
            """INSERT INTO orders(timestamp, total_amount, items_json, status, employee_id, shift_id, business_day_id,
                                  payment_method, paid_amount)
               VALUES (?, ?, ?, 'completed', ?, ?, ?, ?, ?)""",
            (
                now, round(total, 2), json.dumps(snapshots, ensure_ascii=False),
                employee_id, shift_id, business_day_id, payment_method, paid_amount,
            ),
        )
        order_id = cursor.lastrowid

        if business_day_id is not None:
            add_cash_entry(
                db,
                business_day_id,
                "sale",
                round(total, 2),
                "مبيعات",
                "order",
                order_id,
                "إيراد بيع",
                shift_id=shift_id,
                employee_id=employee_id,
            )
        db.commit()

        return jsonify({
            "success": True,
            "order_id": order_id,
            "timestamp": now,
            "total_amount": round(total, 2),
            "payment_method": payment_method,
            "paid_amount": paid_amount,
            "items": snapshots,
            "shop": shop_settings,
            "employee_id": employee_id,
            "shift_id": shift_id,
            "business_day_id": business_day_id,
        }), 201
        
    except ValueError as error:
        db.rollback()
        return api_error(str(error))
    except Exception as e:
        db.rollback()
        app.logger.exception("Unexpected error saving order")
        return api_error("حدث خطأ أثناء حفظ الطلب. يرجى المحاولة مرة أخرى.", 500)


def current_actor_identity(db):
    """Whoever triggered a cashier/admin action as (id, name, role).

    Admins are resolved from the users table, employees from the employees table,
    so void/return actions can always be attributed to a real operator.
    """
    admin_id = session.get("admin_id")
    if admin_id:
        row = db.execute("SELECT username FROM users WHERE id = ?", (admin_id,)).fetchone()
        return admin_id, (row["username"] if row else "admin"), "admin"
    employee_id = session.get("employee_id")
    if employee_id:
        row = db.execute("SELECT username FROM employees WHERE id = ?", (employee_id,)).fetchone()
        return employee_id, (row["username"] if row else ""), "employee"
    return None, "", ""


AUDIT_EXEMPT_PATHS = {
    "/admin/login",
    "/admin/logout",
    "/api/employee/login",
    "/api/employee/logout",
    "/api/employee/shift/close",
}


@app.after_request
def record_audit_trail(response):
    """Write every successful mutating request to the audit trail with its actor.

    Any action recorded in the system therefore carries the name of the employee
    (or admin) who performed it, resolved from the current session.
    """
    if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
        return response
    if request.path in AUDIT_EXEMPT_PATHS or response.status_code >= 400:
        return response
    try:
        db = get_db()
        actor_id, actor_name, actor_role = current_actor_identity(db)
        if not actor_name:
            return response
        db.execute(
            "INSERT INTO audit_logs(created_at, actor_id, actor_name, actor_role, "
            "action, entity, entity_id, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                datetime.now().astimezone().isoformat(timespec="seconds"),
                actor_id,
                actor_name,
                actor_role,
                request.method,
                request.path,
                None,
                "تمت العملية بنجاح",
            ),
        )
        db.commit()
    except Exception:
        app.logger.exception("Failed to record audit trail")
    return response


@app.post("/api/orders/void-last")
@app.post("/api/orders/<int:order_id>/void")
@selling_required
@open_shift_required
def void_last_order(order_id=None):
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return api_error("بيانات الاسترجاع غير صالحة.")
    reason = str(body.get("reason", "")).strip()
    if not reason:
        return api_error("سبب الاسترجاع مطلوب.")
    if len(reason) > 500:
        return api_error("سبب الاسترجاع يجب ألا يتجاوز 500 حرف.")
    employee_name = str(body.get("employee_name", "")).strip()
    if not employee_name:
        return api_error("اسم الموظف مطلوب لتوثيق الاسترجاع.")
    if len(employee_name) > 100:
        return api_error("اسم الموظف يجب ألا يتجاوز 100 حرف.")

    db = get_db()
    # Cashier voids must be tied to an open shift so the operator is accountable.
    if not session.get("admin_id"):
        open_shift = active_employee_shift(db, session.get("employee_id"))
        if open_shift is None:
            return api_error("يجب استلام وردية موظف قبل تنفيذ الاسترجاع.", 409)
    try:
        db.execute("BEGIN IMMEDIATE")
        order_query = (
            "SELECT id, items_json, total_amount, business_day_id, shift_id, employee_id "
            "FROM orders WHERE status = 'completed'"
        )
        if order_id is None:
            order_query += " ORDER BY id DESC LIMIT 1"
            order = db.execute(order_query).fetchone()
        else:
            order = db.execute(order_query + " AND id = ?", (order_id,)).fetchone()
        if order is None:
            db.rollback()
            return api_error("لا توجد عملية بيع لإلغائها.", 404)

        try:
            items = json.loads(order["items_json"])
        except (TypeError, json.JSONDecodeError):
            raise ValueError("تعذر قراءة تفاصيل آخر عملية بيع؛ لم يتم تغيير المخزون.")
        if not isinstance(items, list):
            raise ValueError("تفاصيل آخر عملية بيع غير صالحة؛ لم يتم تغيير المخزون.")

        for item in items:
            if not isinstance(item, dict):
                raise ValueError("تفاصيل أحد المنتجات غير صالحة؛ لم يتم تغيير المخزون.")
            try:
                product_id = int(item["id"])
                quantity = int(item["quantity"])
            except (KeyError, TypeError, ValueError):
                raise ValueError("بيانات مخزون أحد المنتجات غير صالحة؛ لم يتم تغيير المخزون.")
            if product_id < 1 or quantity < 1:
                raise ValueError("بيانات مخزون أحد المنتجات غير صالحة؛ لم يتم تغيير المخزون.")

            kind = item.get("kind")
            if kind in ("book", "retail"):
                table = "books" if kind == "book" else "retail"
                cursor = db.execute(
                    "UPDATE " + table + " SET stock_quantity = stock_quantity + ? WHERE id = ?",
                    (quantity, product_id),
                )
                if cursor.rowcount != 1:
                    raise ValueError("تعذر العثور على منتج لإرجاع مخزونه؛ لم يتم إلغاء العملية.")
            elif kind == "drink":
                materials_used = item.get("materials_used")
                if not isinstance(materials_used, list):
                    raise ValueError(
                        "هذه عملية بيع قديمة ولا تحتوي على تفاصيل المواد اللازمة لإرجاع المخزون."
                    )
                for used in materials_used:
                    if not isinstance(used, dict):
                        raise ValueError("تفاصيل المواد المستهلكة غير صالحة؛ لم يتم إلغاء العملية.")
                    try:
                        material_id = int(used["material_id"])
                        total_qty = positive_number(used["total_qty"], "كمية المادة", False)
                    except (KeyError, TypeError, ValueError) as error:
                        raise ValueError("تفاصيل المواد المستهلكة غير صالحة: " + str(error))
                    cursor = db.execute(
                        "UPDATE materials SET current_stock = current_stock + ? WHERE id = ?",
                        (total_qty, material_id),
                    )
                    if cursor.rowcount != 1:
                        raise ValueError("تعذر العثور على مادة لإرجاع مخزونها؛ لم يتم إلغاء العملية.")
            else:
                raise ValueError("نوع منتج غير معروف في آخر عملية بيع؛ لم يتم إلغاؤها.")

        performed_by, _actor_name, performed_by_role = current_actor_identity(db)
        # The typed operator name is recorded verbatim as required by the refund policy.
        performed_by_name = employee_name
        cancelled_at = datetime.now().astimezone().isoformat(timespec="seconds")
        cursor = db.execute(
            "UPDATE orders SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?, "
            "performed_by = ?, performed_by_name = ?, performed_by_role = ? "
            "WHERE id = ? AND status = 'completed'",
            (cancelled_at, reason, performed_by, performed_by_name, performed_by_role, order["id"]),
        )
        if cursor.rowcount != 1:
            raise ValueError("تم تغيير حالة العملية بالفعل؛ لم يتم إلغاء العملية مرة أخرى.")
        if order["business_day_id"] is not None:
            add_cash_entry(
                db,
                order["business_day_id"],
                "refund",
                -float(order["total_amount"]),
                "استرجاع مبيعات",
                "order_refund",
                order["id"],
                reason,
                shift_id=order["shift_id"],
                employee_id=order["employee_id"],
            )
        db.commit()
        app.logger.info("Order %s voided and stock restored by %s", order["id"], performed_by_name or "unknown")
        return jsonify({
            "ok": True,
            "order_id": order["id"],
            "cancelled_at": cancelled_at,
            "reason": reason,
            "performed_by": performed_by,
            "performed_by_name": performed_by_name,
            "performed_by_role": performed_by_role,
        })
    except ValueError as error:
        db.rollback()
        return api_error(str(error), 409)
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error voiding the latest order")
        return api_error("حدث خطأ أثناء إلغاء العملية؛ لم يتم تغيير حالة الطلب.", 500)


# --- NEW: Server-Side Receipt Generation for Printing ---
def receipt_settings(db):
    """Every receipt knob merged over its default so old databases stay valid."""
    values = dict(RECEIPT_SETTING_DEFAULTS)
    placeholders = ",".join("?" for _ in RECEIPT_SETTING_KEYS)
    for row in db.execute(
        "SELECT key, value FROM settings WHERE key IN (" + placeholders + ")",
        RECEIPT_SETTING_KEYS,
    ):
        values[row["key"]] = row["value"]
    if str(values["receipt_paper_width"]) not in RECEIPT_PAPER_WIDTHS:
        values["receipt_paper_width"] = "58"
    if values["receipt_qr_mode"] not in RECEIPT_QR_MODES:
        values["receipt_qr_mode"] = "none"
    return values


def logo_file_name(value):
    """Accept only names this app generated, never an arbitrary path."""
    name = str(value or "").strip()
    if not name or Path(name).name != name or not name.startswith("receipt_logo_"):
        return None
    if Path(name).suffix.lower() not in LOGO_SUFFIXES:
        return None
    return name


def current_logo_path(db=None):
    """The uploaded brand image when present, otherwise the bundled logo."""
    connection = db or get_db()
    stored = connection.execute(
        "SELECT value FROM settings WHERE key = ?", (LOGO_SETTINGS_KEY,)
    ).fetchone()
    name = logo_file_name(stored["value"] if stored else "")
    if name:
        candidate = DATA_DIR / name
        if candidate.is_file():
            return candidate
    bundled = resource_path("static/img/logo.png")
    return bundled if bundled.is_file() else None


def receipt_qr_payload(settings, order):
    """Build the text encoded in the receipt QR from the admin's choice."""
    mode = settings.get("receipt_qr_mode") or "none"
    if mode == "none":
        return ""
    value = str(settings.get("receipt_qr_value") or "").strip()
    if mode in ("text", "url"):
        return value
    if mode == "phone":
        digits = "".join(character for character in (value or settings["receipt_phone"]) if character.isdigit())
        return "tel:" + digits if digits else ""
    if mode == "whatsapp":
        digits = "".join(character for character in (value or settings["receipt_phone"]) if character.isdigit())
        return "https://wa.me/" + digits.lstrip("0") if digits else ""
    if mode == "email":
        address = value or settings["receipt_email"]
        return "mailto:" + address if address.strip() else ""
    return ""


def receipt_qr_html(payload, paper_width):
    """Size the code to roughly two thirds of the roll so it stays scannable."""
    try:
        matrix = qrcode_gen.quiet_zone(qrcode_gen.make_qr_matrix(payload))
    except ValueError:
        return ""
    cells = len(matrix)
    # 1 CSS pixel is 25.4/96 mm on a printed page.
    module_mm = (float(paper_width) * 0.62) / cells
    cell_px = max(2, min(7, int(round(module_mm * 96 / 25.4))))
    return qrcode_gen.qr_html_table(payload, cell_px=cell_px)


def receipt_line(label, value, bold=False):
    if not str(label or "").strip() and not str(value or "").strip():
        return ""
    weight = "font-weight:bold;" if bold else ""
    return (
        '<div class="line" style="%s"><span>%s</span><span class="value">%s</span></div>'
        % (weight, label, value)
    )


def sample_receipt_order(db):
    """A real recent invoice, or a stand-in so the preview never needs data."""
    row = db.execute(
        "SELECT * FROM orders WHERE status = 'completed' ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if row is not None:
        return row
    sample_items = [
        {"name": "قهوة تركي", "quantity": 1, "unit_price": 50.0, "gross_total": 50.0, "line_total": 50.0},
        {"name": "كلاسيك كوكيز", "quantity": 2, "unit_price": 50.0, "gross_total": 100.0, "line_total": 100.0},
    ]
    return {
        "id": 1,
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "employee_id": None,
        "performed_by_name": "معاينة",
        "total_amount": 150.0,
        "payment_method": PAYMENT_METHODS[0],
        "paid_amount": 200.0,
        "items_json": json.dumps(sample_items, ensure_ascii=False),
    }


def render_receipt_html(order, db, preview=False):
    """Renders the receipt exactly as the shop configured it.

    Everything the layout shows comes from the settings table: the wording of
    every line, the QR payload, the logo and the roll width. ``preview`` keeps
    the page on screen without firing the printer, which is what the cashier
    preview and the admin settings screen both use.
    """
    settings = receipt_settings(db)
    shop = dict(db.execute("SELECT key, value FROM settings WHERE key IN ('shop_name', 'shop_address')"))
    shop_name = (shop.get("shop_name") or "").strip() or DEFAULT_SHOP_NAME
    cashier = ""
    if order["employee_id"]:
        row = db.execute("SELECT username FROM employees WHERE id = ?", (order["employee_id"],)).fetchone()
        cashier = row["username"] if row else ""
    cashier = cashier or (order["performed_by_name"] if "performed_by_name" in order.keys() else "")

    items = []
    try:
        parsed = json.loads(order["items_json"] or "[]")
    except (TypeError, json.JSONDecodeError):
        parsed = []
    subtotal = 0.0
    discounted = 0.0
    for entry in parsed:
        if not isinstance(entry, dict):
            continue
        quantity = float(entry.get("quantity") or 0)
        unit_price = float(entry.get("unit_price") or 0)
        gross = float(entry.get("gross_total") if entry.get("gross_total") is not None else unit_price * quantity)
        line_total = float(entry.get("line_total") if entry.get("line_total") is not None else gross)
        subtotal += gross
        discounted += gross - line_total
        items.append(
            (
                html.escape(str(entry.get("name") or ""))[:40],
                quantity,
                unit_price,
                line_total,
            )
        )
    total = float(order["total_amount"] or 0)
    currency = settings["receipt_currency"]
    paid = None
    if "paid_amount" in order.keys() and order["paid_amount"] is not None:
        paid = float(order["paid_amount"])
    payment_method = (order["payment_method"] if "payment_method" in order.keys() else "") or PAYMENT_METHODS[0]

    try:
        receipt_datetime = datetime.fromisoformat(order["timestamp"])
    except (TypeError, ValueError):
        receipt_datetime = datetime.now()
    stamp = receipt_datetime.strftime("%Y/%m/%d %I:%M %p").replace("AM", "\u0635").replace("PM", "\u0645")

    paper = str(settings["receipt_paper_width"])
    paper_mm = float(paper)
    base_font = max(9.0, min(15.0, round(paper_mm * 0.21, 1)))

    rows = "".join(
        '<tr><td class="item">{name}</td><td class="num">{quantity:g}\u00d7{price:.2f}</td>'
        '<td class="num">{total:.2f}</td></tr>'.format(
            name=name,
            quantity=quantity,
            price=unit_price,
            total=line_total,
        )
        for name, quantity, unit_price, line_total in items
    )

    logo_html = ""
    if str(settings["receipt_show_logo"]) == "1" and current_logo_path(db) is not None:
        logo_html = '<img class="logo" src="/branding/logo" alt="">'

    qr_html = ""
    qr_payload = receipt_qr_payload(settings, order)
    if qr_payload:
        qr_html = '<div class="qr">' + receipt_qr_html(qr_payload, paper) + "</div>"

    def text(value):
        return html.escape(str(value or ""))

    amount = lambda value: text("%.2f %s" % (value, currency)) if currency else text("%.2f" % value)

    header_lines = "".join(
        '<div class="muted">%s</div>' % text(value)
        for value in (settings["receipt_tagline"], shop.get("shop_address", ""))
        if str(value or "").strip()
    )
    meta_lines = "".join(
        receipt_line(text(label), text(value))
        for label, value in (
            (settings["receipt_invoice_label"], "#" + str(order["id"])),
            ("", stamp),
            (settings["receipt_cashier_label"], cashier),
        )
        if label or value
    )
    totals_lines = "".join(
        part
        for part in (
            receipt_line(settings["receipt_items_count_label"], text("%g" % sum(q for _n, q, _p, _t in items))),
            receipt_line(settings["receipt_subtotal_label"], amount(subtotal)) if subtotal else "",
            receipt_line(settings["receipt_discount_label"], amount(discounted)) if discounted else "",
            receipt_line(settings["receipt_total_label"], amount(total), bold=True),
            receipt_line(settings["receipt_payment_label"], payment_method),
            receipt_line(settings["receipt_paid_label"], amount(paid)) if paid is not None else "",
            receipt_line(settings["receipt_change_label"], amount(paid - total)) if paid is not None else "",
        )
        if part
    )
    footer_lines = "".join(
        '<div class="muted">%s</div>' % text(value)
        for value in (
            settings["receipt_thanks"],
            " ".join(part for part in (settings["receipt_contact_label"], settings["receipt_phone"]) if part.strip()),
            settings["receipt_email"],
            settings["receipt_policy"],
        )
        if str(value or "").strip()
    )

    preview = bool(preview) or request.args.get("keep") == "1"
    auto_print = str(settings["receipt_auto_print"]) == "1" and not preview

    return """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>فاتورة %(invoice)s</title>
<style>
    @page { size: %(paper)smm auto; margin: 0; }
    * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    html, body { margin: 0; padding: 0; background: #fff; }
    body { width: %(paper)smm; margin: 0 auto; padding: 4mm 2mm 6mm; color: #000; font-family: Tahoma, Arial, 'Segoe UI', sans-serif; font-size: %(font)spx; line-height: 1.35; }
    .receipt { text-align: center; }
    .logo { max-width: 60%%; max-height: %(logo_height)spx; display: block; margin: 0 auto 4px; }
    .shop { font-weight: bold; font-size: %(title)spx; }
    .muted { font-size: %(small)spx; }
    .rule { border-top: 1px dashed #000; margin: 4px 0; }
    .rule.solid { border-top: 1px solid #000; }
    table { width: 100%%; border-collapse: collapse; }
    th { font-size: %(small)spx; text-align: right; border-bottom: 1px solid #000; padding: 2px 0; }
    th.num, td.num { text-align: left; direction: ltr; unicode-bidi: isolate; white-space: nowrap; }
    td.item { padding: 2px 0; }
    td { font-size: %(font)spx; vertical-align: top; }
    .line { display: flex; justify-content: space-between; font-size: %(font)spx; padding: 1px 0; }
    .line .value { direction: ltr; unicode-bidi: isolate; white-space: nowrap; }
    .qr { text-align: center; margin-top: 6px; }
    .qr table { width: auto; margin: 0 auto; }
    .toolbar { position: sticky; top: 0; background: #f6f1e7; padding: 6px; text-align: center; }
    .toolbar button { font: inherit; padding: 6px 14px; margin: 0 4px; cursor: pointer; }
    @media print { .toolbar { display: none !important; } body { width: %(paper)smm; padding: 0 2mm; } }
</style>
</head>
<body>
<div class="toolbar no-print"><button type="button" onclick="window.print()">🖨️ طباعة</button></div>
<div class="receipt">
    %(logo)s
    <div class="shop">%(shop)s</div>
    %(header)s
    <div class="rule"></div>
    %(meta)s
    <div class="rule"></div>
    <table><thead><tr><th>%(items_header)s</th><th class="num">%(qty)s</th><th class="num">%(total_label)s</th></tr></thead>
    <tbody>%(rows)s</tbody></table>
    <div class="rule solid"></div>
    %(totals)s
    <div class="rule"></div>
    %(qr)s
    %(footer)s
</div>
<script>
%(autoprint)s
</script>
</body>
</html>""" % {
        "invoice": html.escape(str(order["id"])),
        "paper": paper,
        "font": base_font,
        "small": round(base_font * 0.82, 1),
        "title": round(base_font * 1.25, 1),
        "logo_height": max(28, int(base_font * 4)),
        "logo": logo_html,
        "shop": '<bdi dir="%s">%s</bdi>' % (shop_name_direction(shop_name), text(shop_name)),
        "header": header_lines,
        "meta": meta_lines,
        "items_header": text(settings["receipt_items_header"] or "الصنف"),
        "qty": text("كمية × سعر"),
        "total_label": text("الإجمالي"),
        "rows": rows or '<tr><td colspan="3">لا توجد أصناف.</td></tr>',
        "totals": totals_lines,
        "qr": qr_html,
        "footer": footer_lines,
        "autoprint": "window.addEventListener('load', function () { window.print(); });" if auto_print else "",
    }


@app.get("/api/print-receipt/<int:order_id>")
def print_receipt_view(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        abort(404)
    return render_receipt_html(order, db, preview=request.args.get("preview") == "1")


@app.get("/api/receipt-preview")
@admin_required
def receipt_preview_view():
    """Live sample used by the settings screen: shows edits before any printing."""
    db = get_db()
    return render_receipt_html(sample_receipt_order(db), db, preview=True)


@app.get("/branding/logo")
def branding_logo():
    path = current_logo_path()
    if path is None:
        abort(404)
    return send_file(str(path))


def print_report_html(report):
    shop_name = current_shop_name()
    period_title = "تقرير اليوم " + report["key"] if report["period"] == "day" else "تقرير الشهر " + report["key"]
    rows_html = ""
    for sale in report.get("sales", []):
        for item in sale.get("items") or []:
            rows_html += (
                "<tr><td dir='ltr'>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>"
                "<td dir='ltr'>{}</td><td dir='ltr'>{:.2f}</td></tr>"
            ).format(
                html.escape(str(sale.get("timestamp_display") or sale["timestamp"])),
                html.escape(str(sale["employee_name"])),
                sale["order_id"],
                html.escape(str(item["name"])),
                item["quantity"],
                item["discount_amount"],
                float(item["line_total"] or 0),
            )
    log_html = ""
    for entry in report["log"]:
        log_html += "<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            html.escape(str(entry.get("event_time_display") or entry.get("event_time") or "")),
            html.escape(str(entry.get("title") or "")),
            html.escape(str(entry.get("details") or "")),
        )
    return """<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
    <title>{title}</title>
    <style>
      body {{ font-family: Tahoma, Arial, sans-serif; padding: 16px; color: #2b2118; }}
      h1 {{ font-size: 20px; }}
      table {{ width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12px; }}
      th, td {{ border: 1px solid #ccc; padding: 6px; text-align: right; }}
      .metrics span {{ display: inline-block; margin-left: 18px; }}
      @media print {{ .no-print {{ display: none; }} }}
    </style>
    </head><body onload="window.print()">
    <button class="no-print" onclick="window.print()">طباعة</button>
    <h1>{shop} — {title}</h1>
    <p class="metrics">
      <span>المبيعات: {revenue:.2f}</span>
      <span>التكلفة: {cogs:.2f}</span>
      <span>المصروفات: {expenses:.2f}</span>
      <span>صافي الربح: {profit:.2f}</span>
      <span>عدد العمليات: {orders}</span>
    </p>
    <h2>المبيعات</h2>
    <table><thead><tr><th>الوقت والتاريخ</th><th>الموظف</th><th>رقم العملية</th><th>الصنف</th><th>الكمية</th><th>خصم %</th><th>الإجمالي</th></tr></thead>
    <tbody>{rows}</tbody></table>
    <h2>سجل ما حدث</h2>
    <table><thead><tr><th>الوقت</th><th>الحدث</th><th>التفاصيل</th></tr></thead>
    <tbody>{log}</tbody></table>
    </body></html>""".format(
        shop=html.escape(shop_name),
        title=html.escape(period_title),
        revenue=report["revenue"],
        cogs=report["cogs"],
        expenses=report["expenses"],
        profit=report["profit"],
        orders=report["orders"],
        rows=rows_html or "<tr><td colspan='7'>لا توجد مبيعات.</td></tr>",
        log=log_html or "<tr><td colspan='3'>لا يوجد سجل.</td></tr>",
    )


@app.get("/api/print-report")
@cashier_session_required
def print_project_report():
    try:
        period, key = report_period_key()
    except ValueError:
        return api_error("تاريخ التقرير غير صالح.")
    if not session.get("admin_id") and period == "month" and not session.get("employee_id"):
        return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
    return print_report_html(build_project_report(get_db(), period, key))


@app.get("/api/cashier/sales-report")
@cashier_session_required
def cashier_sales_report():
    day = str(request.args.get("date") or date.today().isoformat()).strip()
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        return api_error("تاريخ التقرير غير صالح.")
    report = build_project_report(get_db(), "day", day)
    return jsonify(report)


@app.get("/api/cashier/recent-orders")
@cashier_session_required
def get_recent_orders_for_cashier():
    db = get_db()
    query = str(request.args.get("q", "")).strip().lower()
    day = str(request.args.get("date", "")).strip()
    status = str(request.args.get("status", "")).strip().lower()
    employee = str(request.args.get("employee", "")).strip()

    sql = """SELECT o.id, o.total_amount, o.timestamp, o.items_json, o.status, o.cancel_reason,
                    o.performed_by_name, o.performed_by_role,
                    e.username AS employee_name, s.started_at AS shift_started_at
             FROM orders o
             LEFT JOIN employees e ON e.id = o.employee_id
             LEFT JOIN shifts s ON s.id = o.shift_id
             WHERE 1 = 1"""
    params = []
    if day:
        try:
            datetime.strptime(day, "%Y-%m-%d")
        except ValueError:
            return api_error("تاريخ البحث غير صالح.")
        sql += " AND substr(o.timestamp, 1, 10) = ?"
        params.append(day)
    if status in ("completed", "cancelled"):
        sql += " AND o.status = ?"
        params.append(status)
    if employee:
        sql += " AND IFNULL(e.username, '') LIKE ?"
        params.append("%" + employee + "%")
    sql += " ORDER BY o.timestamp DESC, o.id DESC LIMIT 500"
    rows = db.execute(sql, params).fetchall()

    results = []
    for row in rows:
        try:
            items = json.loads(row["items_json"] or "[]")
        except (TypeError, ValueError):
            items = []
        names = [str(item.get("name") or "") for item in items if isinstance(item, dict)]
        names_text = "، ".join(name for name in names if name)
        units = 0
        for item in items:
            if not isinstance(item, dict):
                continue
            try:
                units += int(float(item.get("quantity") or 0))
            except (TypeError, ValueError):
                continue
        entry = {
            "id": row["id"],
            "total_amount": round(float(row["total_amount"] or 0), 2),
            "timestamp": row["timestamp"],
            "status": row["status"],
            "employee_name": row["employee_name"] or "غير مسجل",
            "shift_started_at": row["shift_started_at"],
            "cancel_reason": row["cancel_reason"] or "",
            "performed_by_name": row["performed_by_name"] or "",
            "performed_by_role": row["performed_by_role"] or "",
            "items": names_text,
            "items_count": units,
        }
        if query:
            haystack = " ".join([
                str(entry["id"]),
                entry["employee_name"],
                names_text,
                str(entry["total_amount"]),
                entry["cancel_reason"],
                entry["performed_by_name"],
                str(entry["timestamp"]),
                format_iso_datetime(row["timestamp"]),
                format_iso_datetime(row["timestamp"], "%d/%m/%Y"),
            ]).lower()
            if query not in haystack:
                continue
        results.append(entry)
    return jsonify(results)


def category_product_count(db, category):
    if category["scope"] == "drink":
        return db.execute(
            "SELECT COUNT(*) AS count FROM drinks WHERE category = ?", (category["slug"],)
        ).fetchone()["count"]
    if category["scope"] == "retail":
        return db.execute(
            "SELECT COUNT(*) AS count FROM retail WHERE category = ?", (category["slug"],)
        ).fetchone()["count"]
    return 0


def category_rows(db, active_only=False):
    where = "WHERE c.is_active = 1" if active_only else ""
    rows = db.execute(
        """SELECT c.id, c.slug, c.label_ar, c.scope, c.sort_order, c.is_active, c.created_at
           FROM categories c """ + where + " ORDER BY c.scope, c.sort_order, c.id"
    ).fetchall()
    results = []
    for row in rows:
        item = dict(row)
        item["is_active"] = bool(item["is_active"])
        item["product_count"] = category_product_count(db, item)
        results.append(item)
    return results


def category_slug_base(label):
    normalized = unicodedata.normalize("NFKD", label)
    characters = []
    separator = False
    for character in normalized:
        if unicodedata.combining(character):
            continue
        if character.isalnum():
            characters.append(character.lower())
            separator = False
        elif characters and not separator:
            characters.append("-")
            separator = True
    slug = "".join(characters).strip("-")
    return slug or "category"


@app.get("/api/categories/active")
def active_categories():
    return jsonify(category_rows(get_db(), True))


@app.get("/api/categories")
@admin_required
def list_categories():
    return jsonify(category_rows(get_db()))


@app.post("/api/categories")
@admin_required
@open_shift_required
def create_category():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return api_error("بيانات التصنيف غير صالحة.")
    label = str(data.get("label_ar", "")).strip()
    scope = str(data.get("scope", "")).strip().lower()
    if not label:
        return api_error("اسم التصنيف مطلوب.")
    if scope not in ("drink", "retail", "book"):
        return api_error("نوع المنتج غير صالح. اختر مشروبات أو منتجات جاهزة أو كتب.")
    try:
        sort_order = int(data.get("sort_order", 100))
    except (TypeError, ValueError):
        return api_error("ترتيب التصنيف يجب أن يكون عددًا صحيحًا.")
    db = get_db()
    base = category_slug_base(label)
    slug = base
    suffix = 2
    while db.execute("SELECT 1 FROM categories WHERE slug = ?", (slug,)).fetchone():
        slug = base + "-" + str(suffix)
        suffix += 1
    try:
        cursor = db.execute(
            """INSERT INTO categories
               (slug, label_ar, scope, sort_order, is_active, created_at)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (slug, label, scope, sort_order, datetime.now().astimezone().isoformat(timespec="seconds")),
        )
        db.commit()
        item = dict(db.execute(
            "SELECT id, slug, label_ar, scope, sort_order, is_active, created_at "
            "FROM categories WHERE id = ?", (cursor.lastrowid,)
        ).fetchone())
        item["is_active"] = bool(item["is_active"])
        item["product_count"] = 0
        return jsonify(item), 201
    except sqlite3.IntegrityError:
        db.rollback()
        return api_error("تعذر إنشاء التصنيف بسبب تعارض في البيانات.")


@app.put("/api/categories/<int:category_id>")
@admin_required
@open_shift_required
def update_category(category_id):
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return api_error("بيانات التصنيف غير صالحة.")
    # Product rows reference slug; only the display label and category metadata may change.
    if "slug" in data:
        return api_error("المعرّف الداخلي للتصنيف لا يمكن تغييره.")
    label = str(data.get("label_ar", "")).strip()
    scope = str(data.get("scope", "")).strip().lower()
    if not label:
        return api_error("اسم التصنيف مطلوب.")
    if scope not in ("drink", "retail", "book"):
        return api_error("نوع المنتج غير صالح. اختر مشروبات أو منتجات جاهزة أو كتب.")
    try:
        sort_order = int(data.get("sort_order", 100))
    except (TypeError, ValueError):
        return api_error("ترتيب التصنيف يجب أن يكون عددًا صحيحًا.")
    active_value = data.get("is_active", True)
    if active_value not in (True, False, 0, 1):
        return api_error("حالة التصنيف غير صالحة.")
    db = get_db()
    category = db.execute("SELECT * FROM categories WHERE id = ?", (category_id,)).fetchone()
    if category is None:
        return api_error("التصنيف غير موجود.", 404)
    if scope != category["scope"] and category_product_count(db, category):
        return api_error("لا يمكن تغيير نوع المنتج لتصنيف عليه منتجات.", 409)
    try:
        db.execute(
            """UPDATE categories SET label_ar = ?, scope = ?, sort_order = ?, is_active = ?
               WHERE id = ?""",
            (label, scope, sort_order, int(bool(active_value)), category_id),
        )
        db.commit()
        return jsonify({"ok": True})
    except sqlite3.IntegrityError:
        db.rollback()
        return api_error("تعذر تحديث التصنيف.")


@app.delete("/api/categories/<int:category_id>")
@admin_required
@open_shift_required
def delete_category(category_id):
    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    category = db.execute("SELECT * FROM categories WHERE id = ?", (category_id,)).fetchone()
    if category is None:
        db.rollback()
        return api_error("التصنيف غير موجود.", 404)
    count = category_product_count(db, category)
    reassign_to = request.args.get("reassign_to", "").strip()
    if count and not reassign_to:
        db.rollback()
        return api_error(
            "التصنيف عليه " + str(count) +
            " منتج. انقل المنتجات لتصنيف آخر أو عطّله بدل الحذف.", 409
        )
    try:
        if count:
            target = db.execute(
                "SELECT * FROM categories WHERE slug = ? AND scope = ? AND is_active = 1",
                (reassign_to, category["scope"]),
            ).fetchone()
            if target is None or target["id"] == category_id:
                raise ValueError("اختر تصنيفًا نشطًا آخر من نفس نوع المنتج لإعادة التعيين.")
            table = "drinks" if category["scope"] == "drink" else "retail"
            db.execute(
                "UPDATE " + table + " SET category = ? WHERE category = ?",
                (target["slug"], category["slug"]),
            )
        db.execute("DELETE FROM categories WHERE id = ?", (category_id,))
        db.commit()
        return jsonify({"ok": True, "reassigned": count})
    except ValueError as error:
        db.rollback()
        return api_error(str(error), 409)
    except sqlite3.Error:
        db.rollback()
        app.logger.exception("Unable to delete category %s", category_id)
        return api_error("تعذر حذف التصنيف؛ لم يتم نقل المنتجات.", 500)


@app.post("/api/categories/<int:category_id>/move")
@admin_required
@open_shift_required
def move_category(category_id):
    data = request.get_json(silent=True) or {}
    direction = data.get("direction") if isinstance(data, dict) else None
    if direction not in ("up", "down"):
        return api_error("اتجاه النقل غير صالح.")
    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    try:
        category = db.execute("SELECT * FROM categories WHERE id = ?", (category_id,)).fetchone()
        if category is None:
            db.rollback()
            return api_error("التصنيف غير موجود.", 404)
        rows = db.execute(
            "SELECT id FROM categories WHERE scope = ? ORDER BY sort_order, id",
            (category["scope"],),
        ).fetchall()
        ids = [row["id"] for row in rows]
        index = ids.index(category_id)
        neighbor_index = index - 1 if direction == "up" else index + 1
        if neighbor_index < 0 or neighbor_index >= len(ids):
            db.rollback()
            return jsonify({"ok": True, "moved": False})
        ids[index], ids[neighbor_index] = ids[neighbor_index], ids[index]
        for position, item_id in enumerate(ids, 1):
            db.execute(
                "UPDATE categories SET sort_order = ? WHERE id = ?",
                (position * 10, item_id),
            )
        db.commit()
        return jsonify({"ok": True, "moved": True})
    except sqlite3.Error:
        db.rollback()
        app.logger.exception("Unable to reorder category %s", category_id)
        return api_error("تعذر تغيير ترتيب التصنيف.", 500)


# --- Admin APIs ---
@app.get("/api/admin/dashboard")
@admin_required
def dashboard_metrics():
    db = get_db()
    sales_summary = today_sales_summary(db)
    
    # Low Stock Alerts - Including Type/Category info
    low_materials = db.execute(
        "SELECT name, current_stock AS stock, unit FROM materials WHERE current_stock <= reorder_level ORDER BY name"
    ).fetchall()
    # Books are excluded from restock by design.
    low_stock = [
        dict(row, unit=material_unit_label(row["unit"]))
        for row in low_materials
    ]
    
    settings = dict(db.execute("SELECT key, value FROM settings WHERE key IN ('shop_name', 'shop_address')"))
    return jsonify({
        **sales_summary,
        "low_stock": low_stock,
        "shop": settings,
    })


@app.get("/api/cashier/today-sales")
def cashier_today_sales():
    summary = today_sales_summary(get_db())
    return jsonify({"today_sales": summary["today_sales"]})


def plain_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if number.is_integer():
        return str(int(number))
    return ("%.4f" % number).rstrip("0").rstrip(".")


def drink_is_available(recipe_json, stock_map):
    """True when every recipe material has enough stock for a single unit."""
    try:
        recipe = json.loads(recipe_json or "[]")
    except (TypeError, ValueError):
        return False
    if not isinstance(recipe, list):
        return False
    for ingredient in recipe:
        if not isinstance(ingredient, dict):
            return False
        material_id = ingredient.get("material_id")
        if material_id not in stock_map:
            return False
        try:
            quantity = float(ingredient.get("qty") or 0)
        except (TypeError, ValueError):
            return False
        if stock_map[material_id] < quantity:
            return False
    return True


@app.get("/api/cashier/notifications")
@cashier_session_required
def cashier_notifications():
    """Cashier-facing alerts: low/empty materials and non-buildable drinks."""
    db = get_db()
    alerts = []
    materials = db.execute(
        "SELECT id, name, current_stock, reorder_level, unit FROM materials ORDER BY name"
    ).fetchall()
    stock_map = {}
    for row in materials:
        stock = float(row["current_stock"] or 0)
        stock_map[row["id"]] = stock
        unit = material_unit_label(row["unit"])
        reorder = float(row["reorder_level"] or 0)
        if stock <= 0:
            alerts.append({
                "kind": "out_of_stock",
                "severity": "danger",
                "title": "نفدت المادة: " + row["name"],
                "detail": "المخزون الحالي 0 " + unit,
            })
        elif stock <= reorder:
            alerts.append({
                "kind": "low_stock",
                "severity": "warning",
                "title": "مخزون منخفض: " + row["name"],
                "detail": "المتبقي " + plain_number(stock) + " " + unit +
                          " من حد التنبيه " + plain_number(reorder) + " " + unit,
            })
    for drink in db.execute("SELECT id, name, recipe_json FROM drinks ORDER BY name").fetchall():
        if not drink_is_available(drink["recipe_json"], stock_map):
            alerts.append({
                "kind": "unavailable_drink",
                "severity": "warning",
                "title": "مشروب غير متاح: " + drink["name"],
                "detail": "نقص في مكونات الوصفة أو في مخزون المواد.",
            })
    alerts.sort(key=lambda item: 0 if item["severity"] == "danger" else 1)
    return jsonify({
        "alerts": alerts,
        "count": len(alerts),
        "danger_count": len([item for item in alerts if item["severity"] == "danger"]),
    })


def inventory_rows(table):
    db = get_db()
    columns = {
        "books": "id, title, author, publisher, type, cost_price, sell_price, stock_quantity",
        "drinks": "id, name, sell_price, recipe_json, category", # Added category here
        "materials": "id, name, unit, cost_per_unit, current_stock, reorder_level",
        "retail": "id, name, category, cost_price, sell_price, stock_quantity, unit",
    }
    rows = [dict(row) for row in db.execute("SELECT " + columns[table] + " FROM " + table + " ORDER BY id DESC")]
    if table == "materials":
        for row in rows:
            row["unit_label"] = material_unit_label(row["unit"])
            row["unit_needs_review"] = normalize_material_unit(row["unit"]) is None
    elif table == "drinks":
        labels = {
            row["slug"]: row["label_ar"]
            for row in db.execute("SELECT slug, label_ar FROM categories")
        }
        for row in rows:
            category = "iced" if row["category"] == "cold" else row["category"]
            row["category_label"] = labels.get(category, category)
    elif table == "retail":
        labels = {
            row["slug"]: row["label_ar"]
            for row in db.execute("SELECT slug, label_ar FROM categories")
        }
        for row in rows:
            row["category_label"] = labels.get(
                row["category"], row["category"]
            )
    return rows

@app.get("/api/admin/<resource>")
@inventory_or_expense_manager_required
def list_admin_resource(resource):
    if resource not in ("books", "drinks", "materials", "retail", "expenses"):
        return api_error("المورد المطلوب غير معروف.", 404)
    if resource == "expenses":
        return jsonify([dict(row) for row in get_db().execute(
            """SELECT x.id, x.date, x.category, x.amount, x.note,
                      COALESCE(e.username, '') AS employee_name,
                      p.id AS purchase_id, p.items_json AS purchase_items
               FROM expenses x
               LEFT JOIN employees e ON e.id = x.employee_id
               LEFT JOIN purchases p ON p.id = x.purchase_id
               ORDER BY x.date DESC, x.id DESC LIMIT 500"""
        )])
    return jsonify(inventory_rows(resource))

def resource_values(resource, data):
    if not isinstance(data, dict):
        raise ValueError("بيانات الطلب غير صالحة.")
    if resource == "books":
        title = str(data.get("title", "")).strip()
        author = str(data.get("author", "")).strip()
        publisher = str(data.get("publisher", "")).strip()
        kind = normalize_book_type(data.get("type", ""))
        if not title:
            raise ValueError("عنوان الكتاب مطلوب.")
        normalized_title = normalized_catalog_name(title)
        retail_names = [
            row["name"] for row in get_db().execute("SELECT name FROM retail")
        ]
        retail_names.extend(RETAIL_BOOK_ALIASES.keys())
        if is_retail_book_collision(title) or any(
            normalized_catalog_name(name) == normalized_title for name in retail_names
        ):
            raise ValueError("هذا منتج جاهز، أضِفه من شاشة منتجات جاهزة لا الكتب.")
        cost = positive_number(data.get("cost_price"), "سعر التكلفة")
        price = positive_number(data.get("sell_price"), "سعر البيع")
        stock_value = positive_number(data.get("stock_quantity"), "كمية المخزون")
        if not stock_value.is_integer():
            raise ValueError("يجب أن تكون كمية المخزون عددًا صحيحًا.")
        stock = int(stock_value)
        return (title, author, publisher, kind, cost, price, stock)
    
    if resource == "drinks":
        name = str(data.get("name", "")).strip()
        if not name:
            raise ValueError("اسم المشروب مطلوب.")
        price = positive_number(data.get("sell_price"), "سعر البيع")
        
        category = str(data.get("category", "hot")).strip().lower()
        if category == "cold":
            category = "iced"
        if get_db().execute(
            "SELECT 1 FROM categories WHERE slug = ? AND scope = 'drink' AND is_active = 1",
            (category,),
        ).fetchone() is None:
            raise ValueError("اختر تصنيفًا صحيحًا للمشروب.")
            
        raw = data.get("recipe_json", "[]")
        recipe = json.loads(raw) if isinstance(raw, str) else raw
        if not isinstance(recipe, list):
            raise ValueError("صيغة وصفة المشروب غير صالحة.")
        normalized = []
        for ingredient in recipe:
            if not isinstance(ingredient, dict):
                raise ValueError("يجب تحديد المادة والكمية لكل مكوّن.")
            material_id = int(ingredient["material_id"])
            quantity = positive_number(ingredient["qty"], "كمية المكوّن", False)
            normalized.append({"material_id": material_id, "qty": quantity})
        product_recipe_cost(get_db(), normalized)
        
        # Return tuple includes category now
        return (name, price, json.dumps(normalized), category)
    
    if resource == "materials":
        name = str(data.get("name", "")).strip()
        unit = normalize_material_unit(data.get("unit", ""))
        if not name:
            raise ValueError("اسم المادة مطلوب.")
        if not unit:
            raise ValueError("اختر وحدة صحيحة: جرام أو كجم أو مل أو لتر أو قطعة.")
        cost = positive_number(data.get("cost_per_unit"), "تكلفة الوحدة")
        stock = positive_number(data.get("current_stock"), "المخزون الحالي")
        reorder = positive_number(data.get("reorder_level", 5), "حد التنبيه")
        return (name, unit, cost, stock, reorder)

    if resource == "retail":
        name = str(data.get("name", "")).strip()
        category = str(data.get("category", "")).strip()
        if not name:
            raise ValueError("اسم المنتج الجاهز مطلوب.")
        if not category or get_db().execute(
            "SELECT 1 FROM categories WHERE slug = ? AND scope = 'retail' AND is_active = 1",
            (category,),
        ).fetchone() is None:
            raise ValueError("اختر تصنيفًا نشطًا صحيحًا للمنتج الجاهز.")
        normalized_name = normalized_catalog_name(name)
        book_names = [row["title"] for row in get_db().execute("SELECT title FROM books")]
        book_names.extend(title for title, _, _, _, _ in SEEDED_BOOKS)
        if any(normalized_catalog_name(title) == normalized_name for title in book_names):
            raise ValueError("هذا عنوان كتاب، أضِفه من شاشة الكتب لا المنتجات الجاهزة.")
        cost = positive_number(data.get("cost_price"), "سعر التكلفة")
        price = positive_number(data.get("sell_price"), "سعر البيع")
        unit_val = data.get("unit") or "قطعة"
        norm_unit = normalize_material_unit(unit_val)
        unit_label = material_unit_label(norm_unit) if norm_unit else unit_val
        is_fractional = norm_unit in ("g", "kg", "ml", "L")
        stock_value = positive_number(data.get("stock_quantity"), "كمية المخزون")
        if not is_fractional and not stock_value.is_integer():
            raise ValueError("يجب أن تكون كمية المنتجات الجاهزة عددًا صحيحًا.")
        stock = round(stock_value, 3) if is_fractional else int(stock_value)
        return (name, category, cost, price, stock, unit_label)
    
    if resource == "expenses":
        expense_date = str(data.get("date", date.today().isoformat()))
        try:
            date.fromisoformat(expense_date)
        except ValueError:
            raise ValueError("يجب إدخال التاريخ بالصيغة سنة-شهر-يوم.")
        category = str(data.get("category", "")).strip()
        if not category:
            raise ValueError("تصنيف المصروف مطلوب.")
        amount = positive_number(data.get("amount"), "المبلغ")
        note = str(data.get("note", "")).strip()
        return (expense_date, category, amount, note)
    raise ValueError("المورد المطلوب غير معروف.")

def record_expense_shift_link(db, expense_id, expense_date, category, amount, note):
    """Tie an expense to the open shift and pull the cash out of the live drawer.

    The expense keeps its own accounting date, but the money physically leaves
    the drawer of the day that is currently open. Booking the cash entry against
    a back-dated business day would leave today's drawer untouched, which is the
    drawer mismatch this link exists to prevent.
    """
    day = ensure_business_day(db, date.fromisoformat(expense_date))
    employee_id = session.get("employee_id")
    shift = active_employee_shift(db, employee_id) if employee_id else None
    if shift is None:
        # An admin acting under the on-duty shift still gets a real operator name.
        shift = open_shift_context(db)
        if shift is not None and not employee_id:
            employee_id = shift["employee_id"]
    shift_id = shift["id"] if shift else None
    cash_day_id = shift["business_day_id"] if shift else day["id"]
    db.execute(
        "UPDATE expenses SET business_day_id = ?, shift_id = ?, employee_id = ? WHERE id = ?",
        (day["id"], shift_id, employee_id, expense_id),
    )
    db.execute(
        "DELETE FROM cash_entries WHERE reference_type = 'expense' AND reference_id = ?",
        (expense_id,),
    )
    add_cash_entry(
        db, cash_day_id, "expense", -float(amount), category or "مصروف",
        "expense", expense_id, note or "", shift_id=shift_id, employee_id=employee_id,
    )


# --- Stock intake (تسجيل البضاعة في مكانها) ---------------------------------
# The four buckets the shop stocks. An intake line points at one catalog entry;
# the engine knows which column holds that entry's quantity, and drinks simply
# have no quantity of their own because they are built from materials.
STOCK_BUCKETS = {
    "material": {
        "label": "خامات",
        "table": "materials",
        "name_column": "name",
        "stock_column": "current_stock",
        "cost_column": "cost_per_unit",
        "unit_column": "unit",
        "integer_quantity": False,
    },
    "retail": {
        "label": "منتجات جاهزة",
        "table": "retail",
        "name_column": "name",
        "stock_column": "stock_quantity",
        "cost_column": "cost_price",
        "unit_column": "unit",
        "integer_quantity": True,
    },
    "book": {
        "label": "كتب",
        "table": "books",
        "name_column": "title",
        "stock_column": "stock_quantity",
        "cost_column": "cost_price",
        "unit_column": None,
        "integer_quantity": True,
    },
    "drink": {
        "label": "مشروبات",
        "table": "drinks",
        "name_column": "name",
        "stock_column": None,
        "cost_column": None,
        "unit_column": None,
        "integer_quantity": True,
    },
}


def stock_bucket(kind):
    spec = STOCK_BUCKETS.get(str(kind or "").strip().lower())
    if spec is None:
        raise ValueError("نوع الصنف غير معروف؛ اختر من الخامات أو المنتجات الجاهزة أو المشروبات أو الكتب.")
    return spec


def lookup_stock_item(db, kind, item_id):
    spec = stock_bucket(kind)
    columns = "id, " + spec["name_column"] + " AS name"
    if spec["stock_column"]:
        columns += ", " + spec["stock_column"] + " AS stock"
    else:
        columns += ", NULL AS stock"
    if spec["cost_column"]:
        columns += ", " + spec["cost_column"] + " AS unit_cost"
    else:
        columns += ", NULL AS unit_cost"
    if spec["unit_column"]:
        columns += ", " + spec["unit_column"] + " AS unit"
    else:
        columns += ", 'قطعة' AS unit"
    row = db.execute(
        "SELECT " + columns + " FROM " + spec["table"] + " WHERE id = ?", (item_id,)
    ).fetchone()
    if row is None:
        raise ValueError("الصنف المختار لم يعد موجودًا في " + spec["label"] + ".")
    payload = dict(row)
    payload["kind"] = kind
    payload["label"] = spec["label"]
    payload["affects_stock"] = bool(spec["stock_column"])
    if kind == "drink":
        recipe_row = db.execute("SELECT recipe_json FROM drinks WHERE id = ?", (item_id,)).fetchone()
        try:
            recipe = json.loads(recipe_row["recipe_json"]) if recipe_row else []
        except (TypeError, json.JSONDecodeError):
            recipe = []
        payload["unit_cost"] = round(product_recipe_cost(db, recipe), 2) if isinstance(recipe, list) else 0.0
    return payload


def normalize_intake_line(db, entry):
    if not isinstance(entry, dict):
        raise ValueError("أحد أصناف البضاعة غير صالح.")
    try:
        item_id = int(entry.get("id"))
    except (TypeError, ValueError):
        raise ValueError("معرّف الصنف غير صالح.")
    item = lookup_stock_item(db, entry.get("kind"), item_id)
    spec = STOCK_BUCKETS[item["kind"]]
    try:
        quantity = positive_number(entry.get("quantity"), "كمية " + item["name"], False)
    except ValueError:
        raise ValueError("كمية " + item["name"] + " يجب أن تكون رقمًا أكبر من صفر.")
    norm_unit = normalize_material_unit(item.get("unit"))
    is_fractional = norm_unit in ("g", "kg", "ml", "L")
    if spec["integer_quantity"] and not is_fractional and not quantity.is_integer():
        raise ValueError("كمية " + item["name"] + " يجب أن تكون عددًا صحيحًا.")
    raw_cost = entry.get("unit_cost")
    if raw_cost in (None, ""):
        raw_cost = entry.get("cost_price")
    if raw_cost in (None, ""):
        raw_cost = entry.get("cost_per_unit")
    if raw_cost in (None, ""):
        raise ValueError("تكلفة وحدة " + item["name"] + " مطلوبة وإجبارية.")
    unit_cost = round(positive_number(raw_cost, "تكلفة وحدة " + item["name"], False), 2)
    return {
        "kind": item["kind"],
        "kind_label": item["label"],
        "id": item_id,
        "name": item["name"],
        "unit": item["unit"] or "",
        "quantity": quantity,
        "unit_cost": unit_cost,
        "line_total": round(quantity * unit_cost, 2),
        "affects_stock": item["affects_stock"],
    }


def apply_intake_lines(db, lines, sign=1):
    """Move catalog stock by the intake quantities, reversed when sign is -1."""
    for line in lines:
        spec = stock_bucket(line["kind"])
        if not spec["stock_column"]:
            continue
        quantity = float(line["quantity"]) * sign
        norm_unit = normalize_material_unit(line.get("unit"))
        is_fractional = norm_unit in ("g", "kg", "ml", "L")
        if spec["integer_quantity"] and not is_fractional:
            quantity = int(round(quantity))
        cursor = db.execute(
            "UPDATE " + spec["table"] + " SET " + spec["stock_column"] +
            " = MAX(0, " + spec["stock_column"] + " + ?) WHERE id = ?",
            (quantity, int(line["id"])),
        )
        if cursor.rowcount != 1:
            raise ValueError("تعذر تحديث مخزون " + str(line.get("name") or "الصنف") + ".")


def load_intake_lines(db, items_json):
    try:
        lines = json.loads(items_json or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    return [line for line in lines if isinstance(line, dict)]


def create_purchase_record(db, payload, lines, amount, paid_from_drawer):
    """Persist one intake: raise stock, then optionally book the cash outflow."""
    intake_date = str(payload.get("date") or date.today().isoformat()).strip()
    try:
        date.fromisoformat(intake_date)
    except ValueError:
        raise ValueError("يجب إدخال التاريخ بالصيغة سنة-شهر-يوم.")
    supplier = str(payload.get("supplier", "")).strip()
    note = str(payload.get("note", "")).strip()
    category = str(payload.get("category", "")).strip() or (lines[0]["name"] if lines else "توريد")
    day = ensure_business_day(db, date.fromisoformat(intake_date))
    employee_id = session.get("employee_id")
    shift = active_employee_shift(db, employee_id) if employee_id else None
    if shift is None:
        shift = open_shift_context(db)
        if shift is not None and not employee_id:
            employee_id = shift["employee_id"]
    shift_id = shift["id"] if shift else None
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    cursor = db.execute(
        """INSERT INTO purchases
           (business_day_id, shift_id, employee_id, timestamp, supplier, category,
            amount, items_json, note, stock_adjusted, date)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)""",
        (
            day["id"], shift_id, employee_id, now, supplier, category,
            round(float(amount), 2), json.dumps(lines, ensure_ascii=False), note, intake_date,
        ),
    )
    purchase_id = cursor.lastrowid
    apply_intake_lines(db, lines, 1)
    expense_id = None
    if paid_from_drawer and amount > 0:
        expense_cursor = db.execute(
            """INSERT INTO expenses(date, category, amount, note, business_day_id, shift_id, employee_id, purchase_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                intake_date, "مشتريات: " + category, round(float(amount), 2),
                note or supplier or "", day["id"], shift_id, employee_id, purchase_id,
            ),
        )
        expense_id = expense_cursor.lastrowid
        cash_day_id = shift["business_day_id"] if shift else day["id"]
        add_cash_entry(
            db, cash_day_id, "expense", -float(amount), "مشتريات",
            "expense", expense_id, note or category, shift_id=shift_id, employee_id=employee_id,
        )
    return purchase_id, expense_id


def sync_expense_intake(db, expense_id, expense_date, category, amount, note, stock_item):
    """Attach, refresh, or drop the stock movement that an expense stands for."""
    expense = db.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
    if expense is None:
        return None
    existing_id = expense["purchase_id"]
    if existing_id:
        existing = db.execute("SELECT * FROM purchases WHERE id = ?", (existing_id,)).fetchone()
        if existing is not None:
            apply_intake_lines(db, load_intake_lines(db, existing["items_json"]), -1)
            db.execute("DELETE FROM purchases WHERE id = ?", (existing_id,))
        db.execute("UPDATE expenses SET purchase_id = NULL WHERE id = ?", (expense_id,))
    if not isinstance(stock_item, dict) or stock_item.get("id") in (None, ""):
        return None
    lines = [normalize_intake_line(db, stock_item)]
    if not lines[0]["affects_stock"]:
        # A drink has no quantity of its own; the expense stays a plain expense.
        return None
    cursor = db.execute(
        """INSERT INTO purchases
           (business_day_id, shift_id, employee_id, timestamp, supplier, category,
            amount, items_json, note, stock_adjusted, date)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)""",
        (
            expense["business_day_id"], expense["shift_id"], expense["employee_id"],
            datetime.now().astimezone().isoformat(timespec="seconds"),
            "", lines[0]["name"], round(float(amount), 2),
            json.dumps(lines, ensure_ascii=False), note or category, str(expense_date),
        ),
    )
    apply_intake_lines(db, lines, 1)
    db.execute("UPDATE expenses SET purchase_id = ? WHERE id = ?", (cursor.lastrowid, expense_id))
    return cursor.lastrowid


def drop_purchase_record(db, purchase_id):
    """Undo an intake: put stock back, then remove any expense it paid for."""
    purchase = db.execute("SELECT * FROM purchases WHERE id = ?", (purchase_id,)).fetchone()
    if purchase is None:
        return False
    if purchase["stock_adjusted"]:
        apply_intake_lines(db, load_intake_lines(db, purchase["items_json"]), -1)
    linked = db.execute("SELECT id FROM expenses WHERE purchase_id = ?", (purchase_id,)).fetchall()
    for expense in linked:
        db.execute(
            "DELETE FROM cash_entries WHERE reference_type = 'expense' AND reference_id = ?",
            (expense["id"],),
        )
        db.execute("DELETE FROM expenses WHERE id = ?", (expense["id"],))
    db.execute("DELETE FROM purchases WHERE id = ?", (purchase_id,))
    return True


def intake_manager_required(function):
    """Goods intake follows the same staff rights as expenses and purchases."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        if session.get("admin_id"):
            return function(*args, **kwargs)
        employee_id = session.get("employee_id")
        if not employee_id:
            return api_error("يرجى تسجيل الدخول للمتابعة.", 401)
        employee = get_db().execute(
            "SELECT * FROM employees WHERE id = ? AND is_active = 1", (employee_id,)
        ).fetchone()
        if employee is None:
            session.clear()
            return api_error("حساب الموظف غير نشط.", 403)
        if not (employee["can_manage_purchases"] or employee["can_manage_expenses"]):
            return api_error("لا تملك صلاحية تسجيل البضاعة.", 403)
        return function(*args, **kwargs)

    return wrapped


@app.get("/api/stock-suggestions")
@cashier_session_required
def stock_suggestions():
    """Suggest which catalog entry a typed name refers to, across all four buckets."""
    query = str(request.args.get("q", "")).strip().casefold()
    db = get_db()
    starts, contains = [], []
    for kind, spec in STOCK_BUCKETS.items():
        rows = db.execute(
            "SELECT id, " + spec["name_column"] + " AS name FROM " + spec["table"] + " ORDER BY id DESC LIMIT 400"
        ).fetchall()
        for row in rows:
            name = str(row["name"] or "")
            normalized = name.casefold()
            if query and query not in normalized:
                continue
            try:
                item = lookup_stock_item(db, kind, row["id"])
            except ValueError:
                continue
                entry = {
                "kind": kind,
                "kind_label": item["label"],
                "id": item["id"],
                "name": item["name"],
                "unit": material_unit_label(normalize_material_unit(item["unit"])) if normalize_material_unit(item["unit"]) else (item["unit"] or "قطعة"),
                "stock": round(float(item["stock"] or 0), 3) if item["stock"] is not None else None,
                "unit_cost": round(float(item["unit_cost"] or 0), 2),
                "affects_stock": item["affects_stock"],
            }
            if normalized.casefold().startswith(query) if query else True:
                starts.append(entry)
            else:
                contains.append(entry)
    return jsonify((starts + contains)[:25])


@app.get("/api/purchases")
@cashier_session_required
def list_purchases():
    db = get_db()
    day = str(request.args.get("date") or "").strip()
    statement = """SELECT p.*, COALESCE(e.username, '') AS employee_name,
                          (SELECT id FROM expenses x WHERE x.purchase_id = p.id LIMIT 1) AS expense_id
                   FROM purchases p LEFT JOIN employees e ON e.id = p.employee_id"""
    arguments = []
    if day:
        statement += " WHERE substr(p.timestamp, 1, 10) = ?"
        arguments.append(day)
    statement += " ORDER BY p.timestamp DESC, p.id DESC LIMIT 200"
    rows = db.execute(statement, arguments).fetchall()
    payload = []
    for row in rows:
        item = dict(row)
        item["items"] = load_intake_lines(db, item.pop("items_json", "[]"))
        payload.append(item)
    return jsonify(payload)


@app.post("/api/purchases")
@intake_manager_required
@open_shift_required
def create_purchase():
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return api_error("بيانات تسجيل البضاعة غير صالحة.")
    raw_items = body.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return api_error("اختر صنفًا واحدًا على الأقل لتسجيله.")
    if len(raw_items) > 50:
        return api_error("عدد الأصناف في التسجيل أكبر من المسموح.")
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        lines = [normalize_intake_line(db, entry) for entry in raw_items]
        amount = round(sum(line["line_total"] for line in lines), 2)
        paid_from_drawer = bool(body.get("paid_from_drawer"))
        purchase_id, expense_id = create_purchase_record(db, body, lines, amount, paid_from_drawer)
        db.commit()
        return jsonify({"id": purchase_id, "expense_id": expense_id, "amount": amount}), 201
    except ValueError as error:
        db.rollback()
        return api_error(str(error))
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error saving a purchase record")
        return api_error("حدث خطأ أثناء تسجيل البضاعة.", 500)


@app.delete("/api/purchases/<int:purchase_id>")
@intake_manager_required
@open_shift_required
def delete_purchase(purchase_id):
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        if not drop_purchase_record(db, purchase_id):
            db.rollback()
            return api_error("السجل غير موجود.", 404)
        db.commit()
        return jsonify({"ok": True})
    except ValueError as error:
        db.rollback()
        return api_error(str(error))
    except Exception:
        db.rollback()
        app.logger.exception("Unexpected error deleting a purchase record")
        return api_error("حدث خطأ أثناء حذف تسجيل البضاعة.", 500)


@app.post("/api/admin/<resource>")
@inventory_or_expense_manager_required
@open_shift_required
def create_admin_resource(resource):
    if resource not in ("books", "drinks", "materials", "retail", "expenses"):
        return api_error("المورد المطلوب غير معروف.", 404)
    db = get_db()
    try:
        payload = request.get_json(silent=True) or {}
        values = resource_values(resource, payload)
        fields = {
            "books": "title, author, publisher, type, cost_price, sell_price, stock_quantity",
            "drinks": "name, sell_price, recipe_json, category", # Updated fields
            "materials": "name, unit, cost_per_unit, current_stock, reorder_level",
            "retail": "name, category, cost_price, sell_price, stock_quantity, unit",
            "expenses": "date, category, amount, note",
        }[resource]
        placeholders = ", ".join("?" for _ in values)
        cursor = db.execute(
            "INSERT INTO " + resource + "(" + fields + ") VALUES (" + placeholders + ")", values
        )
        purchase_id = None
        if resource == "expenses":
            record_expense_shift_link(db, cursor.lastrowid, *values)
            if "stock_item" in payload:
                purchase_id = sync_expense_intake(db, cursor.lastrowid, *values, payload.get("stock_item"))
        db.commit()
        return jsonify({"id": cursor.lastrowid, "purchase_id": purchase_id}), 201
    except (ValueError, TypeError, KeyError, json.JSONDecodeError, sqlite3.IntegrityError) as error:
        db.rollback()
        return api_error(str(error))

@app.route("/api/admin/<resource>/<int:item_id>", methods=["PUT", "DELETE"])
@inventory_or_expense_manager_required
@open_shift_required
def edit_admin_resource(resource, item_id):
    if resource not in ("books", "drinks", "materials", "retail", "expenses"):
        return api_error("المورد المطلوب غير معروف.", 404)
    db = get_db()
    if request.method == "DELETE":
        try:
            if resource == "materials":
                recipes = db.execute("SELECT recipe_json FROM drinks").fetchall()
                for row in recipes:
                    try:
                        recipe = json.loads(row["recipe_json"])
                    except json.JSONDecodeError:
                        continue
                    if isinstance(recipe, list) and any(
                        isinstance(item, dict) and str(item.get("material_id")) == str(item_id)
                        for item in recipe
                    ):
                        return api_error("لا يمكن حذف هذه المادة لأنها مستخدمة في وصفة مشروب.", 409)
            expense_purchase_id = None
            expense_purchase_items = "[]"
            if resource == "expenses":
                linked = db.execute(
                    """SELECT p.id, p.items_json FROM purchases p
                       JOIN expenses x ON x.purchase_id = p.id WHERE x.id = ?""",
                    (item_id,),
                ).fetchone()
                if linked is not None:
                    expense_purchase_id, expense_purchase_items = linked["id"], linked["items_json"]
            cursor = db.execute("DELETE FROM " + resource + " WHERE id = ?", (item_id,))
            if cursor.rowcount == 0:
                return api_error("السجل غير موجود.", 404)
            if resource == "expenses":
                if expense_purchase_id:
                    apply_intake_lines(
                        db,
                        load_intake_lines(db, expense_purchase_items),
                        -1,
                    )
                    db.execute("DELETE FROM purchases WHERE id = ?", (expense_purchase_id,))
                db.execute(
                    "DELETE FROM cash_entries WHERE reference_type = 'expense' AND reference_id = ?",
                    (item_id,),
                )
            db.commit()
            return jsonify({"ok": True})
        except sqlite3.IntegrityError:
            db.rollback()
            return api_error("لا يمكن حذف هذه المادة لأنها مستخدمة في وصفة مشروب.", 409)
    try:
        payload = request.get_json(silent=True) or {}
        values = resource_values(resource, payload)
        if resource == "materials":
            current = db.execute("SELECT unit FROM materials WHERE id = ?", (item_id,)).fetchone()
            if current is not None and current["unit"] != values[1]:
                factor = material_unit_conversion_factor(current["unit"], values[1])
                if material_recipe_usage(db, item_id) and (factor is None or abs(factor - 1.0) > 1e-9):
                    return api_error(
                        "لا يمكن تغيير وحدة هذه المادة لأنها مستخدمة في وصفة مشروب؛ "
                        "سيؤدي ذلك إلى تغيير مقادير الوصفة. أنشئ مادة جديدة بالوحدة المطلوبة.",
                        409,
                    )
        fields = {
            "books": "title, author, publisher, type, cost_price, sell_price, stock_quantity",
            "drinks": "name, sell_price, recipe_json, category", # Updated fields
            "materials": "name, unit, cost_per_unit, current_stock, reorder_level",
            "retail": "name, category, cost_price, sell_price, stock_quantity, unit",
            "expenses": "date, category, amount, note",
        }[resource].split(", ")
        assignments = ", ".join(field + " = ?" for field in fields)
        cursor = db.execute(
            "UPDATE " + resource + " SET " + assignments + " WHERE id = ?", values + (item_id,)
        )
        if cursor.rowcount == 0:
            return api_error("السجل غير موجود.", 404)
        if resource == "expenses":
            record_expense_shift_link(db, item_id, *values)
            if "stock_item" in payload:
                sync_expense_intake(db, item_id, *values, payload.get("stock_item"))
        db.commit()
        return jsonify({"ok": True})
    except (ValueError, TypeError, KeyError, json.JSONDecodeError, sqlite3.IntegrityError) as error:
        db.rollback()
        return api_error(str(error))


IMPORT_HEADERS = {
    "books": ["العنوان", "المؤلف", "النوع", "دار النشر", "سعر التكلفة", "سعر البيع", "الكمية"],
    "materials": ["الاسم", "الوحدة", "سعر التكلفة للوحدة", "المخزون الحالي", "حد التنبيه"],
    "drinks": ["الاسم", "التصنيف", "سعر البيع", "الوصفة"],
    "retail": ["الاسم", "التصنيف", "سعر التكلفة", "سعر البيع", "الكمية"],
}


def import_book_type(value):
    normalized = str(value or "").strip().casefold()
    if normalized in ("أصلي", "أصلية"):
        return "Original"
    if normalized in ("نسخة عالية", "نسخة", "هاي كوبي"):
        return "High Copy"
    return normalize_book_type(value)


def import_category(value, scope="drink"):
    normalized = str(value or "").strip().casefold()
    categories = get_db().execute(
        "SELECT slug, label_ar FROM categories WHERE scope = ? AND is_active = 1",
        (scope,),
    ).fetchall()
    aliases = {}
    for category in categories:
        aliases[category["slug"].casefold()] = category["slug"]
        aliases[category["label_ar"].casefold()] = category["slug"]
    if scope == "drink":
        aliases.update({"بارد": "iced", "cold": "iced"})
    if normalized not in aliases:
        raise ValueError("التصنيف غير معروف أو غير نشط.")
    return aliases[normalized]


class HtmlTableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables = []
        self._table = None
        self._row = None
        self._cell = None
        self._capture = False

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []
            self._capture = True

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._row is not None:
            self._row.append("".join(self._cell).strip())
            self._cell = None
            self._capture = False
        elif tag == "tr" and self._table is not None and self._row is not None:
            self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None

    def handle_data(self, data):
        if self._capture:
            self._cell.append(data)


def decode_import_text(content):
    for encoding in ("utf-8-sig", "cp1256", "latin-1"):
        try:
            return content.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError("تعذر قراءة ترميز الملف.")


def parse_csv_bytes(content):
    text = decode_import_text(content)
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    return list(csv.reader(io.StringIO(text), dialect))


def parse_html_table_bytes(content):
    parser = HtmlTableParser()
    parser.feed(decode_import_text(content))
    if not parser.tables:
        raise ValueError("لا يوجد جدول داخل ملف Excel القديم.")
    return parser.tables[0]


def parse_xls_bytes(content):
    try:
        import xlrd
    except ImportError:
        raise ValueError("استيراد ملفات Excel القديمة يتطلب تثبيت xlrd.")
    workbook = None
    try:
        workbook = xlrd.open_workbook(file_contents=content, formatting_info=False)
        worksheet = workbook.sheet_by_index(0)
        if worksheet.nrows > MAX_IMPORT_ROWS + 1:
            raise ValueError("الحد الأقصى للاستيراد " + str(MAX_IMPORT_ROWS) + " صف.")
        return [worksheet.row_values(index) for index in range(worksheet.nrows)]
    finally:
        if workbook is not None:
            workbook.release_resources()


def parse_xlsx_bytes(content):
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise ValueError("استيراد XLSX غير متاح. ثبّت متطلبات التطبيق ثم أعد المحاولة.")
    workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        if worksheet.max_row and worksheet.max_row > MAX_IMPORT_ROWS + 1:
            raise ValueError("الحد الأقصى للاستيراد " + str(MAX_IMPORT_ROWS) + " صف.")
        rows = []
        for index, row in enumerate(worksheet.iter_rows(values_only=True)):
            if index > MAX_IMPORT_ROWS:
                break
            rows.append(list(row))
        return rows
    finally:
        workbook.close()


def parse_xlsb_bytes(content):
    try:
        from pyxlsb import open_workbook
    except ImportError:
        raise ValueError("استيراد XLSB يتطلب تثبيت pyxlsb.")
    rows = []
    with open_workbook(io.BytesIO(content)) as workbook:
        with workbook.get_sheet(1) as worksheet:
            for index, row in enumerate(worksheet.rows()):
                if index > MAX_IMPORT_ROWS:
                    raise ValueError("الحد الأقصى للاستيراد " + str(MAX_IMPORT_ROWS) + " صف.")
                rows.append([cell.v for cell in row])
    return rows


def detect_spreadsheet_kind(filename, content):
    name = (filename or "").lower()
    head = content[:16]
    sample = content[:4096].lstrip().lower()
    if head.startswith(b"\xd0\xcf\x11\xe0"):
        return "xls"
    if head.startswith(b"PK"):
        if name.endswith(".xlsb"):
            return "xlsb"
        return "xlsx"
    if b"<html" in sample or b"<table" in sample or b"<worksheet" in sample:
        return "html"
    if name.endswith(".xlsb"):
        return "xlsb"
    if name.endswith((".xlsx", ".xlsm")):
        return "xlsx"
    if name.endswith(".xls"):
        return "xls"
    if name.endswith(".csv") or b"," in content[:200] or b";" in content[:200]:
        return "csv"
    return "unknown"


def parse_import_file(upload):
    filename = (upload.filename or "").lower()
    content = upload.read(MAX_IMPORT_BYTES + 1)
    if not content:
        raise ValueError("الملف فارغ.")
    if len(content) > MAX_IMPORT_BYTES:
        raise ValueError("حجم الملف يتجاوز الحد المسموح (5 ميجابايت).")
    kind = detect_spreadsheet_kind(filename, content)
    errors = []
    attempts = []
    if kind == "xls":
        attempts = [("xls", parse_xls_bytes), ("html", parse_html_table_bytes), ("csv", parse_csv_bytes)]
    elif kind == "xlsx":
        attempts = [("xlsx", parse_xlsx_bytes), ("xlsb", parse_xlsb_bytes)]
    elif kind == "xlsb":
        attempts = [("xlsb", parse_xlsb_bytes)]
    elif kind == "html":
        attempts = [("html", parse_html_table_bytes), ("csv", parse_csv_bytes)]
    elif kind == "csv":
        attempts = [("csv", parse_csv_bytes)]
    else:
        attempts = [
            ("xls", parse_xls_bytes),
            ("xlsx", parse_xlsx_bytes),
            ("html", parse_html_table_bytes),
            ("csv", parse_csv_bytes),
        ]
    for label, parser in attempts:
        try:
            rows = parser(content)
            if rows:
                return rows
        except ValueError as error:
            if str(error).startswith("الحد الأقصى"):
                raise
            errors.append(label + ": " + str(error))
        except Exception as error:
            errors.append(label + ": " + str(error))
    raise ValueError(
        "تعذر قراءة ملف Excel. يدعم النظام الملفات القديمة والحديثة (XLS و XLSX و XLSM و XLSB و CSV). "
        + (" التفاصيل: " + " | ".join(errors) if errors else "")
    )


def clean_import_value(value):
    return "" if value is None else str(value).strip()


def import_row_values(resource, header_indexes, row, material_names):
    def value(header, optional=False):
        index = header_indexes.get(header)
        raw = clean_import_value(row[index]) if index is not None and index < len(row) else ""
        if not raw and not optional:
            raise ValueError("الحقل «" + header + "» مطلوب.")
        return raw

    if resource == "books":
        return resource_values("books", {
            "title": value("العنوان"),
            "author": value("المؤلف", True),
            "type": import_book_type(value("النوع")),
            "publisher": value("دار النشر", True),
            "cost_price": value("سعر التكلفة"),
            "sell_price": value("سعر البيع"),
            "stock_quantity": value("الكمية"),
        })
    if resource == "materials":
        unit = normalize_material_unit(value("الوحدة"))
        if not unit:
            raise ValueError("الوحدة غير صحيحة؛ استخدم جرام أو كجم أو مل أو لتر أو قطعة.")
        return resource_values("materials", {
            "name": value("الاسم"),
            "unit": unit,
            "cost_per_unit": value("سعر التكلفة للوحدة"),
            "current_stock": value("المخزون الحالي"),
            "reorder_level": value("حد التنبيه", True) or 5,
        })
    if resource == "retail":
        return resource_values("retail", {
            "name": value("الاسم"),
            "category": import_category(value("التصنيف"), "retail"),
            "cost_price": value("سعر التكلفة"),
            "sell_price": value("سعر البيع"),
            "stock_quantity": value("الكمية"),
            "unit": value("الوحدة", True) or "قطعة",
        })
    recipe_text = value("الوصفة", True)
    recipe = []
    if recipe_text:
        for ingredient_text in recipe_text.split(";"):
            ingredient_text = ingredient_text.strip()
            if not ingredient_text:
                continue
            if "=" not in ingredient_text:
                raise ValueError("صيغة الوصفة يجب أن تكون اسم المادة=الكمية.")
            material_name, quantity_text = ingredient_text.rsplit("=", 1)
            material_name = material_name.strip()
            material_matches = material_names.get(material_name.casefold(), [])
            if not material_matches:
                raise ValueError("المادة غير مسجلة: " + material_name + ". أضفها من صفحة المواد الخام أولاً.")
            if len(material_matches) > 1:
                raise ValueError("اسم المادة مكرر ولا يمكن تحديده: " + material_name + ".")
            recipe.append({
                "material_id": material_matches[0]["id"],
                "qty": positive_number(quantity_text.strip(), "كمية المكوّن", False),
            })
    category_header = (
        "التصنيف" if "التصنيف" in header_indexes else "النوع(ساخن/بارد)"
    )
    category = import_category(value(category_header), "drink")
    return resource_values("drinks", {
        "name": value("الاسم"),
        "category": category,
        "sell_price": value("سعر البيع"),
        "recipe_json": json.dumps(recipe, ensure_ascii=False),
    })


@app.get("/api/admin/templates/<resource>")
@inventory_or_expense_manager_required
def download_import_template(resource):
    if resource not in IMPORT_HEADERS:
        return api_error("القالب المطلوب غير معروف.", 404)
    try:
        from openpyxl import Workbook
        from openpyxl.worksheet.datavalidation import DataValidation
    except ImportError:
        return api_error("تنزيل قوالب XLSX يتطلب تثبيت متطلبات التطبيق.", 500)
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = {
        "books": "الكتب",
        "materials": "المواد",
        "drinks": "المشروبات",
        "retail": "منتجات جاهزة",
    }[resource]
    worksheet.sheet_view.rightToLeft = True
    worksheet.append(IMPORT_HEADERS[resource])
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions
    for column in worksheet.columns:
        worksheet.column_dimensions[column[0].column_letter].width = max(
            18, min(32, len(str(column[0].value or "")) + 5)
        )
    if resource == "books":
        validation = DataValidation(type="list", formula1='"Original,High Copy"', allow_blank=False)
        worksheet.add_data_validation(validation)
        validation.add("C2:C1001")
    elif resource == "materials":
        validation = DataValidation(type="list", formula1='"جرام,كجم,مل,لتر,قطعة"', allow_blank=False)
        worksheet.add_data_validation(validation)
        validation.add("B2:B1001")
    elif resource == "drinks":
        category_labels = ",".join(
            row["label_ar"] for row in get_db().execute(
                "SELECT label_ar FROM categories WHERE scope = 'drink' AND is_active = 1 "
                "ORDER BY sort_order, id"
            )
        )
        validation = DataValidation(
            type="list", formula1='"' + category_labels + '"', allow_blank=False
        )
        worksheet.add_data_validation(validation)
        validation.add("B2:B1001")
    else:
        category_labels = ",".join(
            row["label_ar"] for row in get_db().execute(
                "SELECT label_ar FROM categories WHERE scope = 'retail' AND is_active = 1 "
                "ORDER BY sort_order, id"
            )
        )
        validation = DataValidation(
            type="list", formula1='"' + category_labels + '"', allow_blank=False
        )
        worksheet.add_data_validation(validation)
        validation.add("B2:B1001")
    output = io.BytesIO()
    workbook.save(output)
    output.seek(0)
    return send_file(
        output,
        as_attachment=True,
        download_name=resource + "-template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.post("/api/admin/import/<resource>")
@inventory_or_expense_manager_required
@open_shift_required
def import_admin_resource(resource):
    if resource not in IMPORT_HEADERS:
        return api_error("نوع الاستيراد غير معروف.", 404)
    upload = request.files.get("file")
    if upload is None:
        return api_error("اختر ملفًا للاستيراد.")
    try:
        rows = parse_import_file(upload)
        if not rows:
            raise ValueError("الملف لا يحتوي على صفوف.")
        headers = [clean_import_value(header) for header in rows[0]]
        header_indexes = {header: index for index, header in enumerate(headers)}
        if resource == "drinks" and "التصنيف" not in header_indexes:
            legacy_category_header = "النوع(ساخن/بارد)"
            if legacy_category_header in header_indexes:
                header_indexes["التصنيف"] = header_indexes[legacy_category_header]
        missing_headers = [header for header in IMPORT_HEADERS[resource] if header not in header_indexes]
        if missing_headers:
            raise ValueError("أعمدة القالب غير مكتملة: " + "، ".join(missing_headers) + ".")
        data_rows = rows[1:]
        if len(data_rows) > MAX_IMPORT_ROWS:
            raise ValueError("الحد الأقصى للاستيراد " + str(MAX_IMPORT_ROWS) + " صف.")
        notes = []
        if resource == "books" and any(
            header.strip().lower() in ("حد التنبيه", "reorder_level")
            for header in headers
        ):
            notes.append("تم تجاهل عمود حد التنبيه القديم للكتب.")
        db = get_db()
        material_names = {}
        if resource == "drinks":
            for material in db.execute("SELECT id, name FROM materials"):
                material_names.setdefault(material["name"].strip().casefold(), []).append(dict(material))
        fields = {
            "books": "title, author, publisher, type, cost_price, sell_price, stock_quantity",
            "materials": "name, unit, cost_per_unit, current_stock, reorder_level",
            "drinks": "name, sell_price, recipe_json, category",
            "retail": "name, category, cost_price, sell_price, stock_quantity, unit",
        }[resource]
        imported = 0
        errors = []
        for row_number, row in enumerate(data_rows, start=2):
            if not any(clean_import_value(value) for value in row):
                continue
            try:
                values = import_row_values(resource, header_indexes, row, material_names)
                placeholders = ", ".join("?" for _ in values)
                db.execute(
                    "INSERT INTO " + resource + "(" + fields + ") VALUES (" + placeholders + ")",
                    values,
                )
                db.commit()
                imported += 1
            except (ValueError, TypeError, KeyError, json.JSONDecodeError, sqlite3.IntegrityError) as error:
                db.rollback()
                errors.append({"row": row_number, "reason": str(error)})
        return jsonify({
            "imported": imported,
            "failed": len(errors),
            "errors": errors,
            "notes": notes,
        })
    except ValueError as error:
        return api_error(str(error))


# ==========================================
# SYSTEM PURGE (Batch 3a) — admin-only, typed confirmation, audited
# ==========================================
GLOBAL_PURGE_PHRASE = "تأكيد نهائي"

# Each scope is an ordered list of FK-safe operations. Operations:
#   ("delete", table)              -> DELETE FROM table (counted)
#   ("nullify", (table, column))   -> detach nullable references instead of deleting parents
#   ("purge_materials", None)      -> delete materials and strip them from drink recipes
PURGE_SCOPES = {
    "books": {"label": "الكتب", "ops": [("delete", "books")]},
    "drinks": {"label": "المشروبات", "ops": [("delete", "drinks")]},
    "materials": {"label": "المواد الخام", "ops": [("purge_materials", None)]},
    "retail": {"label": "منتجات جاهزة", "ops": [("delete", "retail")]},
    "orders": {"label": "المبيعات والطلبات", "ops": [("delete", "orders")]},
    "expenses": {"label": "المصروفات", "ops": [("delete", "expenses")]},
    "employees": {"label": "الموظفين", "ops": [
        ("nullify", ("orders", "shift_id")),
        ("nullify", ("expenses", "shift_id")),
        ("nullify", ("purchases", "shift_id")),
        ("nullify", ("cash_entries", "shift_id")),
        ("nullify", ("shifts", "handover_to")),
        ("delete", "payroll_settlements"),
        ("delete", "shifts"),
        ("nullify", ("orders", "employee_id")),
        ("nullify", ("expenses", "employee_id")),
        ("nullify", ("purchases", "employee_id")),
        ("nullify", ("cash_entries", "employee_id")),
        ("delete", "employees"),
    ]},
    "attendance": {"label": "الحضور والورديات", "ops": [
        ("nullify", ("orders", "shift_id")),
        ("nullify", ("orders", "business_day_id")),
        ("nullify", ("expenses", "shift_id")),
        ("nullify", ("expenses", "business_day_id")),
        ("nullify", ("expenses", "purchase_id")),
        ("nullify", ("purchases", "shift_id")),
        ("nullify", ("purchases", "business_day_id")),
        ("nullify", ("cash_entries", "shift_id")),
        ("nullify", ("cash_entries", "business_day_id")),
        ("nullify", ("shifts", "handover_to")),
        ("delete", "shifts"),
        ("delete", "cash_entries"),
        ("delete", "purchases"),
        ("delete", "business_days"),
    ]},
    "payroll_adjustments": {"label": "الرواتب والتسويات", "ops": [("delete", "payroll_settlements")]},
    "categories": {"label": "الأقسام والتصنيفات", "ops": [("delete", "categories")]},
}

# Order matters: children before parents. The users table is intentionally kept
# so the system never ends with zero admins.
GLOBAL_PURGE_OPERATIONS = [
    ("delete", "orders"),
    ("delete", "expenses"),
    ("delete", "cash_entries"),
    ("delete", "purchases"),
    ("delete", "payroll_settlements"),
    ("delete", "shifts"),
    ("delete", "business_days"),
    ("delete", "drinks"),
    ("delete", "retail"),
    ("delete", "books"),
    ("delete", "materials"),
    ("delete", "categories"),
    ("delete", "employees"),
    ("delete", "project_log_notes"),
]


def apply_purge_operations(db, operations):
    """Run an ordered purge plan inside the caller's transaction; return rows deleted."""
    deleted = 0
    for kind, target in operations:
        if kind == "delete":
            deleted += db.execute("DELETE FROM " + target).rowcount
        elif kind == "nullify":
            table, column = target
            db.execute(
                "UPDATE " + table + " SET " + column + " = NULL WHERE " + column + " IS NOT NULL"
            )
        elif kind == "purge_materials":
            deleted += db.execute("DELETE FROM materials").rowcount
            valid_ids = {row["id"] for row in db.execute("SELECT id FROM materials").fetchall()}
            for drink in db.execute("SELECT id, recipe_json FROM drinks").fetchall():
                try:
                    recipe = json.loads(drink["recipe_json"] or "[]")
                except (TypeError, ValueError):
                    continue
                if not isinstance(recipe, list):
                    continue
                kept = [
                    item for item in recipe
                    if isinstance(item, dict) and item.get("material_id") in valid_ids
                ]
                if len(kept) != len(recipe):
                    db.execute(
                        "UPDATE drinks SET recipe_json = ? WHERE id = ?",
                        (json.dumps(kept, ensure_ascii=False), drink["id"]),
                    )
    return deleted


def reseed_core_settings(db):
    """Restore default shop settings after a global purge (never leave them blank)."""
    db.execute("DELETE FROM settings WHERE key IN ('shop_name', 'shop_address', 'shift_hours')")
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('shop_name', ?)", (DEFAULT_SHOP_NAME,))
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('shop_address', '')")
    db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('shift_hours', '8')")


def purge_operations_for(scope):
    if scope == "all":
        return GLOBAL_PURGE_OPERATIONS, "كل بيانات النظام"
    entry = PURGE_SCOPES.get(scope)
    if entry is None:
        return None, None
    return entry["ops"], entry["label"]


@app.get("/api/admin/purge/scopes")
@admin_required
def purge_scope_catalog():
    return jsonify({
        "global_phrase": GLOBAL_PURGE_PHRASE,
        "scopes": [{"key": key, "label": value["label"]} for key, value in PURGE_SCOPES.items()],
    })


@app.delete("/api/admin/purge/<scope>")
@admin_required
@open_shift_required
def purge_system_scope(scope):
    operations, label = purge_operations_for(scope)
    if operations is None:
        return api_error("نطاق التفريغ غير معروف.", 404)
    payload = request.get_json(silent=True) or {}
    confirm = str(payload.get("confirm", "")).strip()
    expected = GLOBAL_PURGE_PHRASE if scope == "all" else label
    if confirm != expected:
        return api_error("نص التأكيد غير مطابق. اكتب «" + expected + "» لتنفيذ التفريغ.", 400)
    db = get_db()
    try:
        deleted = apply_purge_operations(db, operations)
        if scope == "all":
            reseed_core_settings(db)
        admin_count = db.execute(
            "SELECT COUNT(*) AS total FROM users WHERE role = 'admin'"
        ).fetchone()["total"]
        if admin_count < 1:
            db.rollback()
            return api_error("لا يمكن إتمام التفريغ لأنه سيترك النظام بدون حساب مدير.", 409)
        performed_by, performed_by_name, performed_by_role = current_actor_identity(db)
        performed_at = datetime.now().astimezone().isoformat(timespec="seconds")
        db.execute(
            "INSERT INTO purge_logs(scope, scope_label, deleted_count, performed_by, "
            "performed_by_name, performed_by_role, performed_at, details) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (scope, label, deleted, performed_by, performed_by_name, performed_by_role,
             performed_at, "حذف " + str(deleted) + " صفًا"),
        )
        db.commit()
    except sqlite3.Error as error:
        db.rollback()
        return api_error("تعذر تنفيذ التفريغ: " + str(error), 500)
    return jsonify({
        "ok": True,
        "scope": scope,
        "label": label,
        "deleted": deleted,
        "message": "تم تفريغ «" + label + "» وحذف " + str(deleted) + " صفًا من البيانات.",
    })


# ==========================================
# EXCEL EXPORT (Batch 3b) — round-trip with the import format
# ==========================================
CATEGORY_EXPORT_HEADERS = ["label_ar", "scope", "sort_order", "is_active"]
EXPORT_SHEET_TITLES = {
    "books": "الكتب",
    "drinks": "المشروبات",
    "materials": "المواد",
    "retail": "منتجات جاهزة",
    "categories": "التصنيفات",
}


def format_export_quantity(value):
    """Format recipe quantities the same way the importer parses them back."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "0"
    if number.is_integer():
        return str(int(number))
    return ("%.6f" % number).rstrip("0").rstrip(".")


def export_recipe_text(recipe_json, material_names):
    try:
        recipe = json.loads(recipe_json or "[]")
    except (TypeError, ValueError):
        return ""
    if not isinstance(recipe, list):
        return ""
    parts = []
    for item in recipe:
        if not isinstance(item, dict):
            continue
        name = material_names.get(item.get("material_id"))
        if not name:
            continue
        parts.append(str(name) + "=" + format_export_quantity(item.get("qty", 0)))
    return "; ".join(parts)


def export_resource_rows(resource, db):
    """Return export rows (values) in the exact IMPORT_HEADERS column order."""
    category_labels = {
        row["slug"]: row["label_ar"] for row in db.execute("SELECT slug, label_ar FROM categories")
    }
    if resource == "books":
        rows = db.execute(
            "SELECT title, author, type, publisher, cost_price, sell_price, stock_quantity "
            "FROM books ORDER BY id"
        ).fetchall()
        return [[r["title"], r["author"], r["type"], r["publisher"],
                 r["cost_price"], r["sell_price"], r["stock_quantity"]] for r in rows]
    if resource == "materials":
        rows = db.execute(
            "SELECT name, unit, cost_per_unit, current_stock, reorder_level FROM materials ORDER BY id"
        ).fetchall()
        return [[r["name"], material_unit_label(r["unit"]), r["cost_per_unit"],
                 r["current_stock"], r["reorder_level"]] for r in rows]
    if resource == "retail":
        rows = db.execute(
            "SELECT name, category, cost_price, sell_price, stock_quantity FROM retail ORDER BY id"
        ).fetchall()
        return [[r["name"], category_labels.get(r["category"], r["category"]),
                 r["cost_price"], r["sell_price"], r["stock_quantity"]] for r in rows]
    if resource == "drinks":
        material_names = {
            row["id"]: row["name"] for row in db.execute("SELECT id, name FROM materials")
        }
        rows = db.execute(
            "SELECT name, category, sell_price, recipe_json FROM drinks ORDER BY id"
        ).fetchall()
        result = []
        for r in rows:
            category = "iced" if r["category"] == "cold" else r["category"]
            result.append([
                r["name"],
                category_labels.get(category, category),
                r["sell_price"],
                export_recipe_text(r["recipe_json"], material_names),
            ])
        return result
    if resource == "categories":
        rows = db.execute(
            "SELECT label_ar, scope, sort_order, is_active FROM categories "
            "ORDER BY scope, sort_order, id"
        ).fetchall()
        return [[r["label_ar"], r["scope"], r["sort_order"], r["is_active"]] for r in rows]
    return []


@app.get("/api/admin/export/<resource>")
@inventory_or_expense_manager_required
def export_admin_resource(resource):
    if resource != "categories" and resource not in IMPORT_HEADERS:
        return api_error("نوع التصدير غير معروف.", 404)
    if resource == "categories" and not session.get("admin_id"):
        return api_error("تصدير التصنيفات متاح للمدير فقط.", 403)
    try:
        from openpyxl import Workbook
    except ImportError:
        return api_error("تصدير XLSX يتطلب تثبيت متطلبات التطبيق.", 500)
    db = get_db()
    headers = CATEGORY_EXPORT_HEADERS if resource == "categories" else IMPORT_HEADERS[resource]
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = EXPORT_SHEET_TITLES[resource]
    worksheet.sheet_view.rightToLeft = True
    worksheet.append(headers)
    for row in export_resource_rows(resource, db):
        worksheet.append(row)
    worksheet.freeze_panes = "A2"
    for column in worksheet.columns:
        worksheet.column_dimensions[column[0].column_letter].width = max(
            16, min(40, max(len(str(cell.value or "")) for cell in column) + 4)
        )
    output = io.BytesIO()
    workbook.save(output)
    output.seek(0)
    filename = "bookmart_" + resource + "_" + date.today().strftime("%Y%m%d") + ".xlsx"
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.get("/api/admin/reports")
@admin_required
def monthly_report():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    try:
        parsed = datetime.strptime(month, "%Y-%m")
    except ValueError:
        return api_error("يجب إدخال الشهر بالصيغة سنة-شهر.")
    prefix = parsed.strftime("%Y-%m")
    orders = get_db().execute(
        "SELECT total_amount, items_json FROM orders WHERE substr(timestamp, 1, 7) = ? AND status = 'completed'",
        (prefix,),
    ).fetchall()
    revenue = sum(row["total_amount"] for row in orders)
    cogs = sum(
        item["unit_cost"] * item["quantity"]
        for row in orders
        for item in json.loads(row["items_json"])
    )
    expenses = get_db().execute(
        "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE substr(date, 1, 7) = ?",
        (prefix,),
    ).fetchone()["total"]
    return jsonify({
        "month": prefix,
        "revenue": round(revenue, 2),
        "cogs": round(cogs, 2),
        "expenses": round(expenses, 2),
        "profit": round(revenue - cogs - expenses, 2),
        "orders": len(orders),
    })

def write_setting(db, key, value):
    """Store a setting whether or not the row already exists."""
    db.execute(
        "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", (key, str(value))
    )


@app.get("/api/admin/settings")
@admin_required
def get_settings():
    db = get_db()
    rows = db.execute(
        "SELECT key, value FROM settings WHERE key IN ('shop_name', 'shop_address', 'shift_hours')"
    )
    values = dict(rows)
    values["shop_name"] = values.get("shop_name") or DEFAULT_SHOP_NAME
    values["shift_hours"] = float(values.get("shift_hours") or 8)
    values["receipt"] = receipt_settings(db)
    logo = current_logo_path(db)
    values["logo_available"] = logo is not None
    values["logo_uploaded"] = bool(logo_file_name(
        (db.execute("SELECT value FROM settings WHERE key = ?", (LOGO_SETTINGS_KEY,)).fetchone() or {"value": ""})["value"]
    ))
    return jsonify(values)


@app.post("/api/admin/logo")
@admin_required
def upload_logo():
    """Replace the image printed above the shop name on every receipt."""
    upload = request.files.get("logo")
    if upload is None or not upload.filename:
        return api_error("اختر صورة لرفعها.")
    suffix = Path(upload.filename).suffix.lower()
    if suffix not in LOGO_SUFFIXES:
        return api_error("الصورة يجب أن تكون من نوع PNG أو JPG أو GIF أو WEBP.")
    blob = upload.read(MAX_LOGO_BYTES + 1)
    if len(blob) > MAX_LOGO_BYTES:
        return api_error("حجم الصورة يتجاوز 2 ميجابايت.")
    if not blob:
        return api_error("الصورة فارغة.")
    name = "receipt_logo_" + secrets.token_hex(8) + suffix
    db = get_db()
    previous = logo_file_name(
        (db.execute("SELECT value FROM settings WHERE key = ?", (LOGO_SETTINGS_KEY,)).fetchone() or {"value": ""})["value"]
    )
    (DATA_DIR / name).write_bytes(blob)
    write_setting(db, LOGO_SETTINGS_KEY, name)
    db.commit()
    if previous and previous != name:
        try:
            (DATA_DIR / previous).unlink()
        except OSError:
            pass
    return jsonify({"ok": True, "logo_url": "/branding/logo?v=" + secrets.token_hex(4)})


@app.delete("/api/admin/logo")
@admin_required
def delete_logo():
    """Fall back to the bundled logo shipped with the program."""
    db = get_db()
    previous = logo_file_name(
        (db.execute("SELECT value FROM settings WHERE key = ?", (LOGO_SETTINGS_KEY,)).fetchone() or {"value": ""})["value"]
    )
    if previous:
        try:
            (DATA_DIR / previous).unlink()
        except OSError:
            pass
        write_setting(db, LOGO_SETTINGS_KEY, "")
        db.commit()
    return jsonify({"ok": True, "logo_available": current_logo_path(db) is not None})


@app.put("/api/admin/settings")
@admin_required
@open_shift_required
def update_settings():
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return api_error("بيانات الإعدادات غير صالحة.")
    name = str(data.get("shop_name", "")).strip()
    address = str(data.get("shop_address", "")).strip()
    db = get_db()
    current_hours = db.execute(
        "SELECT value FROM settings WHERE key = 'shift_hours'"
    ).fetchone()
    try:
        shift_hours = positive_number(
            data.get("shift_hours", current_hours["value"] if current_hours else 8),
            "عدد ساعات الوردية",
            False,
        )
    except ValueError as error:
        return api_error(str(error))
    if shift_hours > 24:
        return api_error("عدد ساعات الوردية يجب ألا يتجاوز 24 ساعة.")

    # Receipt wording arrives flattened or nested; both come from the same form.
    supplied = dict(data.get("receipt") or {}) if isinstance(data.get("receipt"), dict) else {}
    for key in RECEIPT_SETTING_KEYS:
        if key in data:
            supplied[key] = data[key]
    cleaned = {}
    for key, value in supplied.items():
        if key not in RECEIPT_SETTING_KEYS:
            continue
        if key in RECEIPT_FLAG_KEYS:
            cleaned[key] = "1" if str(value).strip() in ("1", "true", "on", "yes") else "0"
        elif key == "receipt_paper_width":
            width = str(value).strip()
            if width not in RECEIPT_PAPER_WIDTHS:
                return api_error("عرض الورق غير مدعوم؛ اختر 58 أو 72 أو 80 مم.")
            cleaned[key] = width
        elif key == "receipt_qr_mode":
            mode = str(value).strip() or "none"
            if mode not in RECEIPT_QR_MODES:
                return api_error("نوع الكيو ار كود غير معروف.")
            cleaned[key] = mode
        else:
            cleaned[key] = str(value if value is not None else "").strip()
            if len(cleaned[key]) > 120:
                return api_error("نص الفاتورة طويل جدًا: " + RECEIPT_SETTING_DEFAULTS.get(key, key) + ".")
    effective_qr_value = str(
        cleaned.get("receipt_qr_value", receipt_settings(db)["receipt_qr_value"])
    ).strip()
    if cleaned.get("receipt_qr_mode") in ("text", "url") and not effective_qr_value:
        # Phone, WhatsApp and email codes are derived from the printed contact
        # lines, so only the free text and link modes demand their own payload.
        return api_error("اكتب النص أو الرابط الذي تريد وضعه داخل الكيو ار كود.")
    db.execute("UPDATE settings SET value = ? WHERE key = 'shop_name'", (name,))
    db.execute("UPDATE settings SET value = ? WHERE key = 'shop_address'", (address,))
    db.execute("UPDATE settings SET value = ? WHERE key = 'shift_hours'", (str(shift_hours),))
    for key, value in cleaned.items():
        write_setting(db, key, value)
    db.commit()
    return jsonify({"ok": True, "shop_name": current_shop_name(), "receipt": receipt_settings(db)})

@app.put("/api/admin/password")
@admin_required
@open_shift_required
def change_password():
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return api_error("بيانات كلمة المرور غير صالحة.")
    
    new_password = data.get("new_password", "")
    
    # Validation: Only check length and existence of new password
    if not isinstance(new_password, str) or len(new_password) < 6:
        return api_error("يجب ألا تقل كلمة المرور الجديدة عن 6 أحرف.")
    
    db = get_db()
    # Update directly without checking old password since session is already validated by @admin_required
    db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_password), session["admin_id"]),
    )
    db.commit()
    return jsonify({"ok": True})


def run_desktop():
    from werkzeug.serving import make_server

    server = make_server("127.0.0.1", 0, app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    address = "http://127.0.0.1:" + str(server.server_port)
    try:
        import webview

        with app.app_context():
            window_title = current_shop_name()
        webview.create_window(window_title, address, width=1100, height=720, min_size=(760, 540))
        webview.start()
    except ImportError:
        app.logger.warning("pywebview is unavailable; opening the local app in the default browser.")
        webbrowser.open(address)
        thread.join()
    finally:
        server.shutdown()


if __name__ == "__main__":
    initialize_database()
    if "--web" in sys.argv:
        app.run(host="127.0.0.1", port=5000, threaded=True)
    else:
        run_desktop()
else:
    initialize_database()